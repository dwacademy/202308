package kr.human.app.service;

import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import kr.human.app.dao.TestDAO;
import kr.human.app.vo.TestVO;

@Service("testService")
public class TestServiceImpl implements TestService {

	@Autowired
	private TestDAO testDAO;

	@Override
	public String selectToday() {
		String today="";
		try {
			today = testDAO.selectToday();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return today;
	}

	@Override
	public TestVO selectVO(int num1, int num2) {
		TestVO testVO = null;
		try {
			HashMap<String, Integer> map = new HashMap<>();
			map.put("num1", num1);
			map.put("num2", num2);
			testVO = testDAO.selectVO(map);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return testVO;
	}
	
}
