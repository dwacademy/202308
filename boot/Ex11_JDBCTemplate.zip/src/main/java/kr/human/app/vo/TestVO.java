package kr.human.app.vo;

import java.util.Date;
import lombok.Data;

@Data
public class TestVO {
	private Date today;
	private int num1;
	private int num2;
	private int add;
	private int mul;
}
