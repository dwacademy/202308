package kr.human.app.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import kr.human.app.vo.TestVO;

// ResultSet을 받아 1개의 행을 VO로 리턴해주는 클래스 
public class TestVOMapper  implements RowMapper<TestVO>{

	@Override
	public TestVO mapRow(ResultSet rs, int rowNum) throws SQLException {
		TestVO testVO = new TestVO();
		testVO.setToday(rs.getTimestamp(1));
		testVO.setNum1(rs.getInt(2));
		testVO.setNum2(rs.getInt(3));
		testVO.setAdd(rs.getInt(4));
		testVO.setMul(rs.getInt(5));
		return testVO;
	}

}
