package kr.human.app.dao;

import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import kr.human.app.vo.TestVO;

@Repository("testDAO")
public class TestDAOImpl implements TestDAO {

	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	
	@SuppressWarnings("deprecation")
	@Override
	public String selectToday() throws Exception {
		// 첫번째 인수 : SQL명령
		// 두번째 인수 : ?에 매칭될 데이터 배열(Object 타입)
		// 세번째 인수 : 리턴자료형(RowMapper를 구현한 객체)
		return jdbcTemplate.queryForObject("select sysdate from dual", null, String.class);
	}

	@SuppressWarnings("deprecation")
	@Override
	public TestVO selectVO(HashMap<String, Integer> map) throws Exception {
		return jdbcTemplate.queryForObject(
					"select sysdate, ?,?,?+?,?*? from dual", 
					new Object[] {map.get("num1"), map.get("num2"),map.get("num1"), map.get("num2"),map.get("num1"), map.get("num2")}, 
					new TestVOMapper());
	}

	
}
