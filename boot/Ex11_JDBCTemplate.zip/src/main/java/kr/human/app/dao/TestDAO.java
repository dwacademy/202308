package kr.human.app.dao;

import java.util.HashMap;

import kr.human.app.vo.TestVO;

public interface TestDAO {
	String selectToday() throws Exception;
	TestVO selectVO(HashMap<String, Integer> map) throws Exception;
}
