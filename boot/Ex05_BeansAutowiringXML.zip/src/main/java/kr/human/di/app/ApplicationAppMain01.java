package kr.human.di.app;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import kr.human.di.vo.Application;

public class ApplicationAppMain01 {
	public static void main(String[] args) {
		AbstractApplicationContext context = new ClassPathXmlApplicationContext("AppConfig1.xml");
		System.out.println(context.getBean("application1", Application.class));
		System.out.println(context.getBean("application2", Application.class));
		System.out.println(context.getBean("application3", Application.class));
		System.out.println(context.getBean("application4", Application.class));
		System.out.println(context.getBean("application5", Application.class));
		context.close();
	}
}
