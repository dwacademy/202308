package kr.human.mvc.controller;

import java.io.File;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.ModelAndView;

import lombok.extern.log4j.Log4j2;

@Controller
@Log4j2
public class MyController {
	
	@RequestMapping(value = {"/"})
	public String home(@RequestParam(required = false, defaultValue = "1") int pageNo, 
			           @RequestParam(required = false, defaultValue = "10") int numOfRows, 
			           Model model) {
		model.addAttribute("today",
				LocalDateTime.now().format(DateTimeFormatter.ofPattern("yy년 MM월 dd일(E) hh:mm:ss.S")));
		return "index";
	}

	@RequestMapping("/form1")
	public String form1() {
		return "form1";
	}
	
	@PostMapping(value = "/uploadOk1")
	public String uploadOk1(HttpServletRequest request, MultipartFile file, Model model) {
		log.info("uploadOk1호출!!!!");
		// 여기에서 실제 업로드 처리를 해줘야 한다.
		// 실제 업로드 경로를 구한다.
		@SuppressWarnings("deprecation")
		String path = request.getRealPath("upload");
		
		// 파일 이외의 값을 받자!!
		String content = request.getParameter("content");
		
		// 파일을 받자
		if(file!=null && file.getSize()>0) {
			// 이름 중복을 피하기 위하여 UUID클래스를 이용 중복되지 않는 값을 생성하고 뒤에 원본이름을 붙임
			String saveFileName = UUID.randomUUID() + "_" + file.getOriginalFilename(); // 저장파일명
			
			// 파일 객체 만들기
			File saveFile = new File(path, saveFileName);
			
			try {
				// 파일 복사
				FileCopyUtils.copy(file.getBytes(), saveFile);
				
				// 저장 내용을 모델에 저장하고 표시할 JSP로 간다.
				model.addAttribute("saveFileName", saveFileName);
				model.addAttribute("originalFileName", file.getOriginalFilename());
				model.addAttribute("contentType", file.getContentType());
				model.addAttribute("fileSize", file.getSize());
				model.addAttribute("uploadPath", path);
				model.addAttribute("content", content);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return "uploadOk1";
	}

	@RequestMapping("/form2")
	public String form2() {
		return "form2";
	}
	

	@PostMapping(value = "/uploadOk2")
	public String uploadOk2(MultipartHttpServletRequest request, Model model) {
		log.info("uploadOk2호출!!!!");
		// 여기에서 실제 업로드 처리를 해줘야 한다.
		// 실제 업로드 경로를 구한다.
		@SuppressWarnings("deprecation")
		String path = request.getRealPath("upload");
		
		// 파일 이외의 값을 받자!!
		String content = request.getParameter("content");
		model.addAttribute("content", content);
		
		// 여러개 바일을 받자
		List<MultipartFile> list = request.getFiles("files");
		if(list!=null && list.size()>0) {
			StringBuffer sb = new StringBuffer();
			for(MultipartFile file : list) {
				if(file!=null && file.getSize()>0) {
					// 이름 중복을 피하기 위하여 UUID클래스를 이용 중복되지 않는 값을 생성하고 뒤에 원본이름을 붙임
					String saveFileName = UUID.randomUUID() + "_" + file.getOriginalFilename(); // 저장파일명
					
					// 파일 객체 만들기
					File saveFile = new File(path, saveFileName);
					
					try {
						// 파일 복사
						FileCopyUtils.copy(file.getBytes(), saveFile);
						
						// 저장 내용을 모델에 저장하고 표시할 JSP로 간다.
						sb.append("saveFileName : " + saveFileName + "<br>");
						sb.append("originalFileName : " + file.getOriginalFilename()  + "<br>");
						sb.append("contentType : " + file.getContentType()  + "<br>");
						sb.append("fileSize : " + file.getSize()  + "<br>");
						sb.append("uploadPath : " +  path  + "<br>");
						sb.append("<button onclick=\"fileDown('" + file.getOriginalFilename() + "','" + saveFileName + "');\">"
						          + file.getOriginalFilename() + "</button><br>");
						sb.append("<hr>");
						
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
			}
			model.addAttribute("result", sb.toString());
		}
		return "uploadOk2";
	}
	
	// 다운로드를 담당할 주소
	@RequestMapping(value = "/download")
	public ModelAndView download(@RequestParam HashMap<String, Object> params, ModelAndView mv) {
		log.debug("download 호출!!!!!");
		String oFileName = (String) params.get("of");
		String sFileName = (String) params.get("sf");
		mv.setViewName("fileDownloadView");
		mv.addObject("of", oFileName);
		mv.addObject("sf", sFileName);
		return mv;
	}
}
