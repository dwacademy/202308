package kr.human.mvc.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import kr.human.mvc.service.MemoService;
import kr.human.mvc.vo.CommVO;
import kr.human.mvc.vo.MemoVO;
import kr.human.mvc.vo.PagingVO;

@Controller
public class MemoController {

	@Autowired
	private MemoService memoService;
	
	@RequestMapping(value = "/memo/list")
	public String list(@ModelAttribute CommVO commVO, Model model) {
		PagingVO<MemoVO> pagingVO =
				memoService.selectList(commVO.getCurrentPage(), commVO.getSizeOfPage(), commVO.getSizeOfBlock());
		model.addAttribute("cv", commVO);
		model.addAttribute("pv", pagingVO);
		model.addAttribute("newLine", "\n");
		model.addAttribute("br", "<br>");
		return "list";
	}
	@RequestMapping(value = "/memo/updateOk")
	public String update(@ModelAttribute CommVO commVO,@ModelAttribute MemoVO memoVO, Model model) {
		switch (commVO.getMode()) {
		case "insert":
			if(memoVO!=null) memoService.insert(memoVO);
			break;
		case "update":
			if(memoVO!=null) memoService.update(memoVO);
			break;
		case "delete":
			if(memoVO!=null) memoService.delete(memoVO);
			break;
		}
		return "redirect:/memo/list";
	}
}
