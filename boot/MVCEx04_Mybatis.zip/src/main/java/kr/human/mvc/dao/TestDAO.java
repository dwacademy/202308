package kr.human.mvc.dao;

import java.util.HashMap;

import kr.human.mvc.vo.TestVO;

public interface TestDAO {
	String selectToday();
	TestVO selectVO(HashMap<String,Integer> map);
	HashMap<String, Object> selectMap(HashMap<String,Integer> map);
}
