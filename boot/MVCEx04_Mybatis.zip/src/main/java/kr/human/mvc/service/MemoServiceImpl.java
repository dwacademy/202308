package kr.human.mvc.service;

import java.sql.SQLException;
import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import kr.human.mvc.dao.MemoDAO;
import kr.human.mvc.vo.MemoVO;
import kr.human.mvc.vo.PagingVO;
import lombok.extern.log4j.Log4j2;

@Service("memoService")
@Log4j2
public class MemoServiceImpl implements MemoService{

	@Autowired
	private MemoDAO memoDAO;

	// 목록 얻기
	@Override
	public PagingVO<MemoVO> selectList(int currentPage, int sizeOfPage, int sizeOfBlock) {
		log.info("selectList 인수 : {},{},{}",currentPage, sizeOfPage, sizeOfBlock);
		PagingVO<MemoVO> pagingVO = null;
		try {
			int totalCount = memoDAO.selectCount();
			pagingVO = new PagingVO<>(totalCount, currentPage, sizeOfPage, sizeOfBlock);
			if(pagingVO!=null) {
				HashMap<String, Integer> map = new HashMap<>();
				map.put("startNo", pagingVO.getStartNo());
				map.put("endNo", pagingVO.getEndNo());
				pagingVO.setList(memoDAO.selectList(map));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		log.info("selectList 결과 : {}", pagingVO);
		return pagingVO;
	}
	// 1개 얻기 : 수정/삭제시 시용
	@Override
	public MemoVO selectByIdx(int idx) {
		log.info("selectByIdx 인수 : {}", idx);
		MemoVO memoVO = null;
		try {
			memoVO = memoDAO.selectByIdx(idx);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		log.info("selectByIdx 결과 : {}", memoVO);
		return memoVO;
	}

	@Override
	public void insert(MemoVO memoVO) {
		log.info("insert 인수 : {}", memoVO);
		try {
			if(memoVO!=null) memoDAO.insert(memoVO);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void update(MemoVO memoVO) {
		log.info("update 인수 : {}", memoVO);
		try {
			if(memoVO!=null) {
				// DB에서 해당 글번호의 글을 가져온다. 
				MemoVO dbVO = memoDAO.selectByIdx(memoVO.getIdx()); 
				if(dbVO!=null) { // 해당 글번호의 글이 존재한다면
					// 비번을 비교해서 비번이 같으면 수정한다/
					if(dbVO.getPassword().equals(memoVO.getPassword())) {
						memoDAO.update(memoVO);
					}
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void delete(MemoVO memoVO) {
		log.info("delete 인수 : {}", memoVO);
		try {
			if(memoVO!=null) {
				// DB에서 해당 글번호의 글을 가져온다. 
				MemoVO dbVO = memoDAO.selectByIdx(memoVO.getIdx()); 
				if(dbVO!=null) { // 해당 글번호의 글이 존재한다면
					// 비번을 비교해서 비번이 같으면 수정한다/
					if(dbVO.getPassword().equals(memoVO.getPassword())) {
						memoDAO.delete(memoVO.getIdx());
					}
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	
}
