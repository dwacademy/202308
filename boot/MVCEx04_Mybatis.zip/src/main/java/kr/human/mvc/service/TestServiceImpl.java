package kr.human.mvc.service;

import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import kr.human.mvc.dao.TestDAO;
import kr.human.mvc.vo.TestVO;

@Service("testService")
public class TestServiceImpl implements TestService {
	@Autowired
	private TestDAO testDAO;

	@Override
	public String selectToday() {
		return testDAO.selectToday();
	}

	@Override
	public TestVO selectVO(int num1, int num2) {
		HashMap<String, Integer> map = new HashMap<>();
		map.put("num1", num1);
		map.put("num2", num2);
		return testDAO.selectVO(map);
	}

	@Override
	public HashMap<String, Object> selectMap(int num1, int num2) {
		HashMap<String, Integer> map = new HashMap<>();
		map.put("num1", num1);
		map.put("num2", num2);
		return testDAO.selectMap(map);
	}
}
