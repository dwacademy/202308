package kr.human.app.service;

import java.time.LocalDate;

public interface DateService {
    LocalDate getNextAssessmentDate();
}
