package kr.human.app.service;

import kr.human.app.vo.EmployeeVO;

public interface EmployeeService {
    void registerEmployee(EmployeeVO employeeVO);
}
