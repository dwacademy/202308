package kr.human.app.service;

public interface MailService {
	void sendMail();
	void sendMail(String toAddress, String subject, String content);
}
