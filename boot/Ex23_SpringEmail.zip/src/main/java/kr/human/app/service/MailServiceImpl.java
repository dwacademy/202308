package kr.human.app.service;

import javax.mail.Message;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessagePreparator;
import org.springframework.stereotype.Service;

@Service("mailService")
public class MailServiceImpl implements MailService {

	@Autowired
	private JavaMailSender mailSender;

	@Override
	public void sendMail() {
		MimeMessagePreparator preparator = new MimeMessagePreparator() {

			@Override
			public void prepare(MimeMessage mimeMessage) throws Exception {
				mimeMessage.setFrom("ithuman202303@gmail.com"); // xml에 등록한 계정과 반드시 일치해야 한다.
				mimeMessage.setRecipient(Message.RecipientType.TO, new InternetAddress("ithuman202303@gmail.com"));
				mimeMessage.setSubject("나는 제목입니다.");
				mimeMessage.setText("아마도 나는 내용일걸~~ <h1>태그가 먹힐까?</h1>"); // Text로 전송
			}
		};
		try {
			mailSender.send(preparator);
			System.out.println("메일 발송 성공!!!!");
		} catch (Exception e) {
			System.out.println("메일 발송 실패!!!");
			e.printStackTrace();
		}

	}

	@Override
	public void sendMail(String toAddress, String subject, String content) {
		MimeMessagePreparator preparator = new MimeMessagePreparator() {

			@Override
			public void prepare(MimeMessage mimeMessage) throws Exception {
				mimeMessage.setFrom("ithuman202303@gmail.com"); // xml에 등록한 계정과 반드시 일치해야 한다.
				mimeMessage.setRecipient(Message.RecipientType.TO, new InternetAddress(toAddress));
				mimeMessage.setSubject(subject);
				mimeMessage.setContent(content, "text/html;charset=UTF-8"); // HTML로 전송
			}
		};
		try {
			mailSender.send(preparator);
			System.out.println("메일 발송 성공!!!!");
		} catch (Exception e) {
			System.out.println("메일 발송 실패!!!");
			e.printStackTrace();
		}
	}

}
