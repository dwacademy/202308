package kr.human.app.main;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import kr.human.app.service.MailService;

public class AppMain {
	public static void main(String[] args) {
		AbstractApplicationContext context = 
			new ClassPathXmlApplicationContext("appConfig.xml");
		
		MailService mailService = context.getBean("mailService", MailService.class);

		mailService.sendMail();
		
		mailService.sendMail("ithuman202303@gmail.com", "갈까요?", "<h1>꽝!!!!</h1> 태그가 먹을까?");
				
				
		context.close();
	}
}
