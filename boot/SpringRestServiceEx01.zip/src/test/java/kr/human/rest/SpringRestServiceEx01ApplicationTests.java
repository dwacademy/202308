package kr.human.rest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringRestServiceEx01ApplicationTests {

	@Test
	void contextLoads() {
	}

}
