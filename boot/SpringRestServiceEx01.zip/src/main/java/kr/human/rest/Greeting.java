package kr.human.rest;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class Greeting {
	private long id;
	private String content;
}

// JDK 14에 추가됨
// public record Greeting(long id, String content) { }
