package kr.human.rest;

import java.util.concurrent.atomic.AtomicLong;

/*
AtomicLong은 Long 자료형을 갖고 있는 Wrapping 클래스입니다.
Thread-safe로 구현되어 멀티쓰레드에서 synchronized 없이 사용할 수 있습니다. 
또한 synchronized 보다 적은 비용으로 동시성을 보장할 수 있습니다.
*/
public class AtomicLongEx02 {
	public static void main(String[] args) {
		// AtomicLong() : 초기값이 0인 AtomicLong을 생성합니다.
		AtomicLong atomic = new AtomicLong();
		
		// get(), set(), getAndSet()
		// AtomicLong의 값을 변경하려면 set(newValue) 메소드를, 
		// 값을 읽으려면 get() 메소드를 사용해야 합니다. 
		// getAndSet(newValue)는 현재 설정된 값을 리턴하고 새로운 값으로 업데이트합니다.
		atomic.set(100);
		System.out.println("get() : " + atomic.get());

		System.out.println("getAndSet(200) : " + atomic.getAndSet(200));
		System.out.println("get() : " + atomic.get());
		
		/* 결과
		 * get() : 100
		 * getAndSet(200) : 100
		 * get() : 200
		 */
	}
}
