package kr.human.rest;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class SpringRestServiceEx01Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringRestServiceEx01Application.class, args);
	}

    @Bean
    CommandLineRunner getCommandLineRunner() {
		return (args)->{
			System.out.println("-".repeat(80));
			System.out.println("http://localhost:8080/greeting");
			System.out.println("http://localhost:8080/greeting?name=User");
			System.out.println("위의 두개의 주소로 접속해보세요!!!");
			System.out.println("-".repeat(80));
		};
	}
}
