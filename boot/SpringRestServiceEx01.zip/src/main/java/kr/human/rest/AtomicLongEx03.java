package kr.human.rest;

import java.util.concurrent.atomic.AtomicLong;
import java.util.function.LongUnaryOperator;

/*
AtomicLong은 Long 자료형을 갖고 있는 Wrapping 클래스입니다.
Thread-safe로 구현되어 멀티쓰레드에서 synchronized 없이 사용할 수 있습니다. 
또한 synchronized 보다 적은 비용으로 동시성을 보장할 수 있습니다.
*/
public class AtomicLongEx03 {
	public static void main(String[] args) {
		// getAndUpdate(), updateAndGet()
		// getAndUpdate(LongUnaryOperator)는 getAndSet()와 조금 다릅니다. 
		// 두번째 인자에 람다식을 전달할 수 있어서, 함수로 값을 변경할 수 있습니다.
		// updateAndGet(LongUnaryOperator)는 업데이트 후 설정된 값을 리턴합니다.
		AtomicLong atomic = new AtomicLong(10);
		LongUnaryOperator square = (n) -> n * n;
		System.out.println("getAndUpdate(square) : " + atomic.getAndUpdate(square));
		System.out.println("get() : " + atomic.get());

		AtomicLong atomic2 = new AtomicLong(5);
		System.out.println("updateAndGet(square) : " + atomic2.updateAndGet(square));
		System.out.println("get() : " + atomic2.get());
		
		/* 결과
		 * getAndUpdate(square) : 10
		 * get() : 100
		 * updateAndGet(square) : 25
		 * get() : 25
		 */
	}
}
