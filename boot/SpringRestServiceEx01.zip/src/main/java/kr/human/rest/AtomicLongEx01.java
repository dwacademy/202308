package kr.human.rest;

import java.util.concurrent.atomic.AtomicLong;

/*
https://codechacha.com/ko/category/java/concurrency/ 참조!!!!
 * 
AtomicLong은 Long 자료형을 갖고 있는 Wrapping 클래스입니다.
Thread-safe로 구현되어 멀티쓰레드에서 synchronized 없이 사용할 수 있습니다. 
또한 synchronized 보다 적은 비용으로 동시성을 보장할 수 있습니다.
*/
public class AtomicLongEx01 {
	public static void main(String[] args) {
		// AtomicLong() : 초기값이 0인 AtomicLong을 생성합니다.
		AtomicLong atomic = new AtomicLong();
		System.out.println("AtomicLong() : " + atomic.get());

		// AtomicLong(longVal) : 인자의 값으로 초기화된 AtomicLong을 생성합니다.
		AtomicLong atomic2 = new AtomicLong(10);
		System.out.println("AtomicLong(10) : " + atomic2.get());
		
		/* 결과
		 * AtomicLong() : 0
		 * AtomicLong(10) : 10
		 */
	}
}
