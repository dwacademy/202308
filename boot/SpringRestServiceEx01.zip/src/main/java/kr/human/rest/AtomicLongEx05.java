package kr.human.rest;

import java.util.concurrent.atomic.AtomicLong;

/*
AtomicLong은 Long 자료형을 갖고 있는 Wrapping 클래스입니다.
Thread-safe로 구현되어 멀티쓰레드에서 synchronized 없이 사용할 수 있습니다. 
또한 synchronized 보다 적은 비용으로 동시성을 보장할 수 있습니다.
*/
public class AtomicLongEx05 {
	public static void main(String[] args) {
		// compareAndSet()
		// compareAndSet(expect, update)는 현재 값이 예상하는 값(expect)과 동일하다면 
		// update 값으로 변경해주고 true를 리턴해 줍니다. 
		// 그렇지 않다면 데이터 변경은 없고 false를 리턴합니다.
		
		// public final boolean compareAndSet(long expect, long update)
		
		
		AtomicLong atomic = new AtomicLong(100);

		int expected = 10;
		int update = 1000;

		System.out.println("success ? " + atomic.compareAndSet(expected, update));
		System.out.println("get() : " + atomic.get());

		expected = 100;
		System.out.println("success ? " + atomic.compareAndSet(expected, update));
		System.out.println("get() : " + atomic.get());
		
		/* 결과
		 * success ? false
		 * get() : 100
		 * success ? true
		 * get() : 1000
		 */
	}
}
