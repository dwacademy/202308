package kr.human.rest;

import java.util.concurrent.atomic.AtomicLong;

/*
AtomicLong은 Long 자료형을 갖고 있는 Wrapping 클래스입니다.
Thread-safe로 구현되어 멀티쓰레드에서 synchronized 없이 사용할 수 있습니다. 
또한 synchronized 보다 적은 비용으로 동시성을 보장할 수 있습니다.
*/
public class AtomicLongEx04 {
	public static void main(String[] args) {
		// getAndIncrement(), getAndAdd()
		// getAndIncrement() : 현재 값 리턴하고 +1 증가
		// incrementAndGet() : +1 증가시키고 변경된 값 리턴
		// getAndDecrement() : 현재 값 리턴하고 -1 감소
		// decrementAndGet() : -1 감소시키고 변경된 값 리턴
		// getAndAdd(newValue) : 현재 값 리턴하고, 현재 값에 newValue를 더하기
		// addAndGet(newValue) : 현재 값에 newValue를 더하고, 그 결과를 리턴
		AtomicLong atomic = new AtomicLong(100);

		System.out.println("getAndIncrement() : " + atomic.getAndIncrement());
		System.out.println("get() : " + atomic.get());

		System.out.println("incrementAndGet() : " + atomic.incrementAndGet());

		System.out.println("decrementAndGet() : " + atomic.decrementAndGet());

		System.out.println("getAndDecrement() : " + atomic.getAndDecrement());
		System.out.println("get() : " + atomic.get());

		System.out.println("addAndGet(300) : " + atomic.addAndGet(300));

		System.out.println("getAndAdd(400) : " + atomic.getAndAdd(400));
		System.out.println("get() : " + atomic.get());
		
		/* 결과
		 * getAndIncrement() : 100
		 * get() : 101
		 * incrementAndGet() : 102
		 * decrementAndGet() : 101
		 * getAndDecrement() : 101
		 * get() : 100
		 * addAndGet(300) : 400
		 * getAndAdd(400) : 400
		 * get() : 800
		 */
	}
}
