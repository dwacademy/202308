package kr.human.app.dao;

import java.sql.SQLException;

import kr.human.app.vo.TestVO;

public interface TestDAO {
	String selectToday() throws SQLException;
	TestVO selectTestVO(TestVO testVO) throws SQLException;
}
