package kr.human.app.service;

import java.util.List;

import kr.human.app.vo.PeopleVO;

public interface PeopleService {
	List<PeopleVO> selectList();
	void insert(PeopleVO peopleVO);
	void update(PeopleVO peopleVO);
	void delete(PeopleVO peopleVO);
	PeopleVO selectByIdx(int idx);
}
