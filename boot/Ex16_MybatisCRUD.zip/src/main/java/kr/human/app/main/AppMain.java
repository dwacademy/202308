package kr.human.app.main;

import java.util.List;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import kr.human.app.service.PeopleService;
import kr.human.app.vo.PeopleVO;
import kr.human.app.vo.TestVO;

public class AppMain {
	public static void main(String[] args) {
		AbstractApplicationContext context = new ClassPathXmlApplicationContext("AppConfig.xml");
		
		PeopleService peopleService = 
				context.getBean("peopleService", PeopleService.class);
		
		PeopleVO peopleVO = new PeopleVO();
		peopleVO.setName("이연성");
		peopleVO.setAge(32);
		peopleService.insert(peopleVO);
		
		peopleVO.setIdx(8);
		peopleVO.setAge(45);
		peopleVO.setName("이하나");
		peopleService.update(peopleVO);
		
		peopleVO.setIdx(7);
		peopleService.delete(peopleVO);

		peopleVO.setIdx(3);
		peopleService.delete(peopleVO);
		
		List<PeopleVO> list = peopleService.selectList();
		System.out.println("-".repeat(50));
		System.out.println(list.size() + "명이 있어요!!!");
		for(PeopleVO vo : list) {
			System.out.println(vo);
		}
		System.out.println("-".repeat(50));
		
		peopleVO = peopleService.selectByIdx(3);
		if(peopleVO!=null)
			System.out.println("읽은 값 : " + peopleVO);
		else
			System.out.println("3번 없다~~~");
		
		context.close();
	}
}
