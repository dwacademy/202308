package kr.human.app.dao;

import java.sql.SQLException;
import java.util.List;

import kr.human.app.vo.PeopleVO;

public interface PeopleDAO {
	List<PeopleVO> selectList() throws SQLException;
	void insert(PeopleVO peopleVO) throws SQLException;
	void update(PeopleVO peopleVO) throws SQLException;
	void delete(int idx) throws SQLException;
	PeopleVO selectByIdx(int idx) throws SQLException;
}
