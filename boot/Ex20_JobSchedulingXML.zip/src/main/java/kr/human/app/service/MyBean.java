package kr.human.app.service;

import org.springframework.stereotype.Component;

@Component("myBean")
public class MyBean {
	public void printMessage1() {
		System.out.println("나는 스프링의 스케쥴러에 의해서 자동으로 불려질 겁니다~~~~~");
	}
	public void printMessage2() {
		System.out.println("나는 스프링의 스케쥴러에 의해서 자동으로 불려질 겁니다!!!!!!!!!!!!");
	}
	public void printMessage3() {
		System.out.println("나는 스프링의 스케쥴러에 의해서 자동으로 불려질 겁니다^^^^^^^^^^^^^^^^^^^");
	}
}
