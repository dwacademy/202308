package kr.human.app.service;

import java.util.HashMap;
import java.util.Map;

import javax.mail.internet.MimeMessage;

import org.apache.velocity.app.VelocityEngine;
import org.apache.velocity.spring.VelocityEngineUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.mail.javamail.MimeMessagePreparator;
import org.springframework.stereotype.Service;
import org.springframework.ui.freemarker.FreeMarkerTemplateUtils;

import freemarker.template.Configuration;

@Service("mailService")
public class MailServiceImpl implements MailService {

	@Autowired
	private JavaMailSender mailSender;
	
	@Autowired
	private VelocityEngine velocityEngine;
	
	@Autowired
	private Configuration freeMarkerConfiguration;

	@Override
	public void sendMail() {
		MimeMessagePreparator preparator = new MimeMessagePreparator() {

			@Override
			public void prepare(MimeMessage mimeMessage) throws Exception {
				MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, true, "UTF-8"); // Helper클래스를 이용한다.
				// 보낼 내용을 만든다.
				helper.setFrom("ithuman202303@gmail.com"); // 이놈은 반드시 XML에 지정한 인증 메일과 일치해야 한다.
				helper.setTo("ithuman202303@gmail.com");
				helper.setSubject("제목이야!!!! 프리마커 이용!!!!");
				
				Map<String, Object> map = new HashMap<>();
				map.put("from", "한사람");
				map.put("nick", "투덜이");
				map.put("age", "31");
				// 프리마커 템플릿을 이용하여 보낼 메일의 내용을 만들어 넣어준다.
				helper.setText(getFreeMarkerTemplateContent(map), true);
			}
		};
		try {
			mailSender.send(preparator);
			System.out.println("메일 발송 성공!!!!");
		} catch (Exception e) {
			System.out.println("메일 발송 실패!!!");
			e.printStackTrace();
		}
	}

	@Override
	public void sendMail(String toAddress, String subject, String content) {
		MimeMessagePreparator preparator = new MimeMessagePreparator() {

			@Override
			public void prepare(MimeMessage mimeMessage) throws Exception {
				MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, true, "UTF-8"); // Helper클래스를 이용한다.
				// 보낼 내용을 만든다.
				helper.setFrom("ithuman202303@gmail.com"); // 이놈은 반드시 XML에 지정한 인증 메일과 일치해야 한다.
				helper.setTo(toAddress);
				helper.setSubject(subject);
				
				Map<String, Object> map = new HashMap<>();
				map.put("from", "한사람");
				map.put("nick", "투덜이");
				map.put("age", "31");
				
				// 벨로시티 템플릿을 이용하여 보낼 메일의 내용을 만들어 넣어준다.
				helper.setText(getVelocityTemplateContent(map), true);
			}
		};
		try {
			mailSender.send(preparator);
			System.out.println("메일 발송 성공!!!!");
		} catch (Exception e) {
			System.out.println("메일 발송 실패!!!");
			e.printStackTrace();
		}
	}

	// 벨로시티 템플릿을 읽어서 모양을 리턴하는 메서드
	public String getVelocityTemplateContent(Map<String, Object> model){
        StringBuffer content = new StringBuffer();
        try{
            content.append(VelocityEngineUtils.mergeTemplateIntoString(velocityEngine, "/vctemplates/vc_mailTemplate.html","UTF-8", model));
            System.out.println("-".repeat(80));
            System.out.println(content.toString());
            System.out.println("-".repeat(80));
            return content.toString();
        }catch(Exception e){
            System.out.println("Exception occured while processing velocity template:"+e.getMessage());
        }
          return "";
    }
 
	// 프리마커 템플릿을 읽어서 모양을 리턴하는 메서드
    public String getFreeMarkerTemplateContent(Map<String, Object> model){
        StringBuffer content = new StringBuffer();
        try{
         content.append(FreeMarkerTemplateUtils.processTemplateIntoString( 
                 freeMarkerConfiguration.getTemplate("fm_mailTemplate.html"),model));
         System.out.println("-".repeat(80));
         System.out.println(content.toString());
         System.out.println("-".repeat(80));
         return content.toString();
        }catch(Exception e){
            System.out.println("Exception occured while processing fmtemplate:"+e.getMessage());
        }
        return "";
    }
}
