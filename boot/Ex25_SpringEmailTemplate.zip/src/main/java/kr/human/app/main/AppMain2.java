package kr.human.app.main;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;

import kr.human.app.config.AppConfig;
import kr.human.app.service.MailService;

public class AppMain2 {
	public static void main(String[] args) {
		AbstractApplicationContext context = 
			new AnnotationConfigApplicationContext(AppConfig.class);
		
		MailService mailService = context.getBean("mailService", MailService.class);

		mailService.sendMail();
		
		mailService.sendMail("ithuman202303@gmail.com", "갈까요?@@@@@@@@@", "<h1>꽝!!!!</h1> 태그가 먹을까?");
				
				
		context.close();
	}
}
