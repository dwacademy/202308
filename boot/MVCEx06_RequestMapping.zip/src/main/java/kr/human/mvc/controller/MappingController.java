package kr.human.mvc.controller;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import kr.human.mvc.vo.DataVO;
import lombok.extern.log4j.Log4j2;

@Controller
@Log4j2 // log변수를 자동으로 만들어 준다.
public class MappingController {
	// @Controller는 JSP파일이름을 리턴하도록 만들어 준다
	// @RequestMapping(주소) : 인터넷 상에 웹 주소 1개를 생성해 준다.
	// @RequestMapping(value="주소", method=RequestMethod.전송방식) : 주소와 전송방식을 지정한다. 
	// 전송방식 생략시 모든 요청()GET, POST, PUT, DELETE ...)을 받아준다.
	// @GetMapping(주소)
	// @PostMapping(주소)
	// @PutMapping(주소) 등을 사용할 수 도 있다.
	@RequestMapping("/m01")
	public String m01() {
		log.info("/m01호출");
		return "m01"; // JSP 파일의 이름만 리턴한다. ?WEB-INF/views/리턴값.jsp 로 포워딩 된다.
	}
	
	//@GetMapping("/m02") // Get방식의 요청일때
	@RequestMapping(value = "/m02", method = RequestMethod.GET) // 윗줄과 같은 역할
	public String m02Get() {
		log.info("/m02 Get 호출 : 장난치면 죽는다");
		return "redirect:/m01"; // response.sendRedirect와 같은 역할을 한다.
	}
	
	// @PostMapping("/m02") // Post방식의 요청일때
	@RequestMapping(value = "/m02", method = RequestMethod.POST) // 윗줄과 같은 역할
	public String m02Post(@ModelAttribute DataVO dataVO, Model model) {
		// @ModelAttribute는 VO로 넘어오는 값을 받아준다. 
		// 반드시 name속성의 이름과 클래스의 변수명이 같아야 한다.
		log.info("/m02 Post 호출 : {}", dataVO);
		model.addAttribute("dataVO", dataVO);
		return "m02"; 
	}
	
	@RequestMapping(value = "/m03")
	// public String m03(@RequestParam int n1,@RequestParam int n2, Model model) {
	// public String m03(@RequestParam(required = false) int n1, @RequestParam(required = false) int n2, Model model) {
	// public String m03(@RequestParam(required = false, defaultValue = "22") int n1, @RequestParam(required = false, defaultValue = "11") int n2, Model model) {
	public String m03(@RequestParam(name = "n", required = false, defaultValue = "22") int n1, @RequestParam(name="m", required = false, defaultValue = "11") int n2, Model model) {
		// @RequestParam 은 요청값을 받아 변수에 저장해준다.
		// @RequestParam 은 값을 넘기지 않으면 (HTTP 상태 400 – 잘못된 요청) 에러가 발생한다.
		// required = false를 쓰면 넘기지 않아도 에러가 발생하지 않는다. 500에러가 나온다.
		// defaultValue = "11"는 넘어오지 않았을때 기본값을 줄 수 있다.
		// 요청값의 변수와 받는 변수가 일치 해야만 받을 수 있다.
		// 변수명이 다를 경우에는 name = "요청변수명"을 쓰면 된다.
		model.addAttribute("n1", n1);
		model.addAttribute("n2", n2);
		return "m03";
	}
	
	// JSP(View)를 이용하지 않고 직접 출력하려면?
	// @RequestMapping(value = "/m04") // 이렇게쓰면 한글이 깨진다.
	@RequestMapping(value = "/m04", produces = "text/plain;charset=UTF-8") // 이렇게쓰면 한글이 안깨진다.
	@ResponseBody
	public String m04() {
		log.info("/m04 호출 !!!!");
		return "Hello Spring 안녕 스프링 1234!@#$";
	}
	
	// path를 이용하여 주소를 만들어 보자!!!
	@RequestMapping(value = "/m05/{id}", produces = "text/html;charset=UTF-8") // {}부분의 경로값을 @PathVariable이 받아준다.
	@ResponseBody
	public String path01(@PathVariable int id) {
		return "<h1>Path를 이용하여 받은 값 : " + id + "</h1>";
	}
	
	@RequestMapping(value = "/m05/{name}/{age}", produces = "text/html;charset=UTF-8") // {}부분의 경로값을 @PathVariable이 받아준다.
	@ResponseBody
	public String path02(@PathVariable String name, @PathVariable int age) {
		return "<h1>Path를 이용하여 받은 값 : " + name + "씨 " + age  + "살이네 행님이라 불러라</h1>";
	}
	
	@RequestMapping(value = "/list/{idx}/{p}/{s}/{b}", produces = "text/html;charset=UTF-8") // {}부분의 경로값을 @PathVariable이 받아준다.
	@ResponseBody
	public String path03(@PathVariable int idx,@PathVariable int p, @PathVariable int s, @PathVariable int b) {
		return "<h1>"+idx + "번 :  " + p + ", " + s + ", " + b + "</h1>";
	}
	
	// request로 받아보자
	@RequestMapping(value = "/get1", produces = "text/html;charset=UTF-8")
	@ResponseBody
	public String get1(HttpServletRequest request) {
		String name = request.getParameter("name"); 
		String age = request.getParameter("age"); 
		return "<h1>HttpServletRequest를 이용하여 받은 값 : " + name + "씨 " + age  + "살이네 행님이라 불러라</h1>";
	}
	// Map으로도 받아보자
	@RequestMapping(value = "/get2", produces = "text/html;charset=UTF-8")
	@ResponseBody
	public String get2(@RequestParam Map<String, String> map) {
		String name = map.get("name"); 
		String age = map.get("age"); 
		return "<h1>Map를 이용하여 받은 값 : " + name + "씨 " + age  + "살이네 행님이라 불러라</h1>";
	}
	
	// Map으로도 받아보자
	@RequestMapping(value = "/get3", produces = "text/html;charset=UTF-8")
	@ResponseBody
	// public String get3(@RequestBody Map<String, String> map) {
	public String get3(@RequestBody DataVO dataVO) {
		String name = dataVO.getName();
		int age = dataVO.getAge(); 
		return "<h1>Map를 이용하여 받은 값 : " + name + "씨 " + age  + "살이네 행님이라 불러라</h1>";
	}
	
	
}
