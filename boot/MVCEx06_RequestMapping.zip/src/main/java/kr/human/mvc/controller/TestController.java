package kr.human.mvc.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import kr.human.mvc.service.TestService;
import kr.human.mvc.vo.TestVO;

@Controller
public class TestController {
	
	@Autowired
	private TestService testService;
	
	@RequestMapping(value = "/test")
	public String test(
			@RequestParam(required = false, defaultValue = "0") int num1,
			@RequestParam(required = false, defaultValue = "0") int num2,
			Model model) {
		String today = testService.selectToday();
		TestVO testVO = testService.selectVO(num1, num2);
		Map<String, Object> map = testService.selectMap(num1, num2);
		
		model.addAttribute("today", today);
		model.addAttribute("testVO", testVO);
		model.addAttribute("testMap", map);
		
		return "testMybatis";
	}
}
