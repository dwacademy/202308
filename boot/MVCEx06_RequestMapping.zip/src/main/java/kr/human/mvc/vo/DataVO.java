package kr.human.mvc.vo;

import lombok.Data;

@Data
public class DataVO {
	private String name;
	private String password;
	private int age;
	private boolean gender;
}
