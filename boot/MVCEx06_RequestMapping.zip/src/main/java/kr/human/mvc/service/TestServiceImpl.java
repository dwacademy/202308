package kr.human.mvc.service;

import java.sql.SQLException;
import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import kr.human.mvc.dao.TestDAO;
import kr.human.mvc.vo.TestVO;
import lombok.extern.log4j.Log4j2;

@Service("testService")
@Log4j2
public class TestServiceImpl implements TestService {

	@Autowired
	private TestDAO testDAO;

	@Override
	public String selectToday() {
		log.info("selectToday  호출!!!!") ;
		String today = null;
		try {
			today = testDAO.selectToday();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		log.info("selectToday  리턴 : {}", today) ;
		return today;
	}

	@Override
	public TestVO selectVO(int num1, int num2) {
		log.info("selectVO  호출 : {}, {}", num1, num2) ;
		TestVO testVO = null;
		try {
			HashMap<String, Integer> map = new HashMap<>();
			map.put("num1", num1);
			map.put("num2", num2);
			testVO = testDAO.selectVO(map);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		log.info("selectVO  리턴 : {}", testVO) ;
		return testVO;
	}

	@Override
	public HashMap<String, Object> selectMap(int num1, int num2) {
		log.info("selectMap  호출 : {}, {}", num1, num2) ;
		HashMap<String, Object> resultMap = null;
		try {
			HashMap<String, Integer> map = new HashMap<>();
			map.put("num1", num1);
			map.put("num2", num2);
			resultMap = testDAO.selectMap(map);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		log.info("selectMap  리턴 : {}", resultMap) ;
		return resultMap;
	}
}
