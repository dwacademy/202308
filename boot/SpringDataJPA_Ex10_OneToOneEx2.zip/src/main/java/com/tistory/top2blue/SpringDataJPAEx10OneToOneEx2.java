package com.tistory.top2blue;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringDataJPAEx10OneToOneEx2 {

	public static void main(String[] args) {
		SpringApplication.run(SpringDataJPAEx10OneToOneEx2.class, args);
	}
	
	
}
