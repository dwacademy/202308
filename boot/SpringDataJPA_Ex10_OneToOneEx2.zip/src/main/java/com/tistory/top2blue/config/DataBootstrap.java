package com.tistory.top2blue.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.tistory.top2blue.repository.AddressRepository;
import com.tistory.top2blue.repository.MemberRepository;
import com.tistory.top2blue.vo.Address;
import com.tistory.top2blue.vo.Member;

import jakarta.transaction.Transactional;

@Component
public class DataBootstrap implements CommandLineRunner {

	
	@Autowired
    private MemberRepository memberRepository;
	@Autowired
    private AddressRepository addressRepository;

     @Transactional
     public void run(String... args) throws Exception {
        Member member = Member.builder()
                .name("한사람")
                .age(22)
                .build();

        Address address = Address.builder()
                .city("서울")
                .build();

        address.setMember(member);
        member.setAddress(address);
        addressRepository.save(address);
        memberRepository.save(member);

        Member member2 = Member.builder()
        		.name("두사람")
        		.age(31)
        		.build();
        
        Address address2 = Address.builder()
        		.city("인천")
        		.build();
        
        address2.setMember(member2);
        member2.setAddress(address2);
        addressRepository.save(address2);
        memberRepository.save(member2);
        
        Member member3 = Member.builder()
        		.name("세사람")
        		.age(34)
        		.build();
        
        Address address3 = Address.builder()
        		.city("인천")
        		.build();
        
        /*
         * 다음과 같이하면 Address에 저장이 되지 않으므로 1:1 에서 대응되는 값이 없어 
         * SpEL에서 데이터를 못 가져와서 에러가 발생한다.
        address2.setMember(member3);
        member3.setAddress(address2);
        */
        
        address3.setMember(member3);
        member3.setAddress(address3);
        addressRepository.save(address3);
        memberRepository.save(member3);
      
    }
}