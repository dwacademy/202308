package com.tistory.top2blue.controller;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.tistory.top2blue.repository.AddressRepository;
import com.tistory.top2blue.repository.MemberRepository;
import com.tistory.top2blue.service.MemberService;
import com.tistory.top2blue.vo.Member;

import lombok.extern.slf4j.Slf4j;

@Controller
@Slf4j
public class HomeController {

	/* 1:1 양방향 */
	
	@Autowired
	MemberRepository memberRepository;
	@Autowired
	AddressRepository addressRepository;
	
	@Autowired
	MemberService memberService;
	
	@GetMapping(value = "/")
	public String home(Model model) {
		String serverTime = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy년 MM월 dd일(EEE) HH:mm:ss"));
		log.info("서버시간 : {}", serverTime);
		model.addAttribute("serverTime", serverTime);
		return "index";
	}
	
	@GetMapping("/test")
	public String test(Model model) {
		model.addAttribute("count1",memberRepository.count() );
		model.addAttribute("count2",addressRepository.count() );
		Optional<Member> optional = memberRepository.findById(1L);
		if(optional.isPresent()) {
			model.addAttribute("vo", optional.get() );
			log.info("vo : {}", optional.get());
		}
		model.addAttribute("list",memberService.findAll());
		return "test";
	}
}
