package com.tistory.top2blue.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tistory.top2blue.repository.AddressRepository;
import com.tistory.top2blue.repository.MemberRepository;
import com.tistory.top2blue.vo.Member;

@Service("memberService")
public class MemberServiceImpl implements MemberService {

	@Autowired
	MemberRepository memberRepository;
	@Autowired
	AddressRepository addressRepository;
	
	@Override
	public List<Member> findAll() {
		List<Member> list = new ArrayList<>();
		memberRepository.findAll().forEach(list::add);
		return list;
	}

}
