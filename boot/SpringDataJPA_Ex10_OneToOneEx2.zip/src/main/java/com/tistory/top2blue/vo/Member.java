package com.tistory.top2blue.vo;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.xml.bind.annotation.XmlRootElement;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@XmlRootElement
@Entity
@Builder
@ToString
public class Member {
	@Id
	@GeneratedValue
	private Long id;
	private String name;
	private int age;

	@OneToOne
	@JoinColumn(name = "id")
	private Address address;

	public Member(String name, int age) {
		this.name = name;
		this.age = age;
	}
}