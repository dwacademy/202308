package com.tistory.top2blue.repository;

import org.springframework.data.repository.CrudRepository;

import com.tistory.top2blue.vo.Member;

public interface MemberRepository extends CrudRepository<Member, Long> {

}
