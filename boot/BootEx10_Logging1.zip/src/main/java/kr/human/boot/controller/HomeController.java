package kr.human.boot.controller;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import lombok.extern.slf4j.Slf4j;

@Controller
@Slf4j // 로그를 출력하기 위한 log변수 자동 선언
public class HomeController {
	
	@GetMapping(value = "/")
	public String index(Model model) {
		model.addAttribute("serverTime", 
				LocalDateTime.now().format(DateTimeFormatter.ofPattern("yy년 MM월 dd일(E) hh:mm:ss")));
		log.info("서버시간 : {}",
				LocalDateTime.now().format(DateTimeFormatter.ofPattern("yy년 MM월 dd일(E) hh:mm:ss")));
		return "index";
	}
}
