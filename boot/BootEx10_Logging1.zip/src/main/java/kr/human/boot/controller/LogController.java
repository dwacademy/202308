package kr.human.boot.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
public class LogController {

	@GetMapping(value = "/logTest")
	public String logTest() {
		String msg = "Spring Boot3 로그 테스트!!!!";
		log.trace("trace Log : {}", msg);
		log.debug("debug Log : {}", msg);
		log.info("info Log : {}", msg);
		log.warn("warn Log : {}", msg);
		log.error("error Log : {}", msg);
		return "ok<br><a href='/'>Home</a>";
	}
}
