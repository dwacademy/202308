package kr.human.app.main;

import java.util.Date;
import java.util.List;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;

import kr.human.app.config.AppConfig;
import kr.human.app.service.EmployeeService;
import kr.human.app.vo.Employee;

public class AppMain {
	 
    public static void main(String args[]) {
        AbstractApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
 
        EmployeeService service = (EmployeeService) context.getBean("employeeService");
 
        /*
         * Create Employee1
         */
        Employee employee1 = new Employee();
        employee1.setName("Han Yenn");
        employee1.setJoiningDate(new Date(110, 10, 10));
        employee1.setSalary(10000);
        employee1.setSsn("ssn00000007");
 
        /*
         * Create Employee2
         */
        Employee employee2 = new Employee();
        employee2.setName("Dan Thomas");
        employee2.setJoiningDate(new Date(120, 11, 11));
        employee2.setSalary(20000);
        employee2.setSsn("ssn00000008");
 
        /*
         * Persist both Employees : 데이터 2개 저장
         */
        service.saveEmployee(employee1);
        service.saveEmployee(employee2);
 
        /*
         * Get all employees list from database : 모두 얻어서 출력
         */
        List<Employee> employees = service.findAllEmployees();
        for (Employee emp : employees) {
            System.out.println(emp);
        }
 
        /*
         * delete an employee : 2번 삭제
         */
        service.deleteEmployeeBySsn("ssn00000004");
 
        /*
         * update an employee : 1번 수정
         */
 
        Employee employee = service.findBySsn("ssn00000001");
        employee.setSalary(5000);
        service.updateEmployee(employee);
 
        /*
         * Get all employees list from database : 출력
         */
        List<Employee> employeeList = service.findAllEmployees();
        for (Employee emp : employeeList) {
            System.out.println(emp);
        }
 
        context.close();
    }
}