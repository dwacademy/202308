package kr.human.app.vo;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Table(name="EMPLOYEE")
@Data
public class Employee {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
 
    @Column(name = "NAME", nullable = false)
    private String name;
 
    @Column(name = "JOINING_DATE", nullable = false)
    private Date joiningDate;
 
    @Column(name = "SALARY", nullable = false)
    private int salary;
     
    @Column(name = "SSN", unique=true, nullable = false)
    private String ssn;
}