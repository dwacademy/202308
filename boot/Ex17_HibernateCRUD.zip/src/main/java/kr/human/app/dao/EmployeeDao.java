package kr.human.app.dao;

import java.util.List;

import kr.human.app.vo.Employee;

public interface EmployeeDao {
	// 저장
    void saveEmployee(Employee employee);
    // 모두 얻기
    List<Employee> findAllEmployees();
    // 삭제
    void deleteEmployeeBySsn(String ssn);
    // ssn으로 1개 얻기
    Employee findBySsn(String ssn);
    // 수정
    void updateEmployee(Employee employee);
}