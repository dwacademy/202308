package kr.human.app.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import kr.human.app.vo.Employee;

@Repository("employeeDao")
@SuppressWarnings("unchecked")
public class EmployeeDaoImpl extends AbstractDao implements EmployeeDao{
 
	// 저장하기
    public void saveEmployee(Employee employee) {
        persist(employee);
    }
    // 모두 얻기
    public List<Employee> findAllEmployees() {
        Criteria criteria = sessionFactory.getCurrentSession().createCriteria(Employee.class);
        return (List<Employee>) criteria.list();
    }
    // 삭제하기
    public void deleteEmployeeBySsn(String ssn) {
        Query query = sessionFactory.getCurrentSession().createSQLQuery("delete from Employee where ssn = :ssn");
        query.setString("ssn", ssn);
        query.executeUpdate();
    }
    // ssn 검색하기
    public Employee findBySsn(String ssn){
        Criteria criteria = sessionFactory.getCurrentSession().createCriteria(Employee.class);
        criteria.add(Restrictions.eq("ssn",ssn));
        return (Employee) criteria.uniqueResult();
    }
    // 수정하기 
    public void updateEmployee(Employee employee){
    	sessionFactory.getCurrentSession().update(employee);
    }
}