package kr.human.app.dao;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;

public abstract class AbstractDao {
	 
    @Autowired // 객체 자동 주입
    protected SessionFactory sessionFactory;
 
    public void persist(Object entity) { // 저장하기
    	sessionFactory.getCurrentSession().persist(entity);
    }
 
    public void delete(Object entity) { // 삭제하기
    	sessionFactory.getCurrentSession().delete(entity);
    }
}