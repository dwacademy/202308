package kr.human.app.service;

import java.util.List;
import kr.human.app.vo.Employee;

public interface EmployeeService {
	// 저장
    void saveEmployee(Employee employee);
    // 모두 얻기
    List<Employee> findAllEmployees();
    // ssn으로 삭제하기
    void deleteEmployeeBySsn(String ssn);
    // ssn으로 찾기
    Employee findBySsn(String ssn);
    // 수정
    void updateEmployee(Employee employee);
}