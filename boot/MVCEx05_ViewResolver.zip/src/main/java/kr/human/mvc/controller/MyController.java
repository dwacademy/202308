package kr.human.mvc.controller;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class MyController {
	
	@RequestMapping(value = "/")
	public String home(@RequestParam(required = false, defaultValue = "1") int pageNo, 
			           @RequestParam(required = false, defaultValue = "10") int numOfRows, 
			           Model model) {
		model.addAttribute("today",
				LocalDateTime.now().format(DateTimeFormatter.ofPattern("yy년 MM월 dd일(E) hh:mm:ss.S")));
		return "index";
	}
}
