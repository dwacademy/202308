package kr.human.mvc.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import kr.human.mvc.service.RssService;
import kr.human.mvc.vo.Pizza;
import kr.human.mvc.vo.Rss;
import kr.human.mvc.vo.Rss2;

@Controller
public class HomeController {

	// JSP로 출력하겠다.
	@GetMapping(value = "/msg") // Get방식으로 msg라는 주소를 1개 생성
	public String getMessage(Model model) {
		model.addAttribute("message", "Hello JSP!!!");
		return "msg/message"; // WEB-INF/views/msg/message.jsp를 통해서 보여줘라.
	}
	
	// 하나의 메서드로 주소를 여러개 생성(배열로 지정가능) 
	// method로 요청 타입을 지정했다. 지정하지 않으면 모든 요청을 받는다. 
	@RequestMapping(value = {"/pizza","/pizzas/pizza","/pizza.it"}, method = RequestMethod.GET)
	public String getPizza(Model model) {
		model.addAttribute("pizza", new Pizza("불고기"));
		return "pizza"; // WEB-INF/views/pizza.jsp를 통해서 보여줘라.
	}
	
	// JSP를 통과하지 않고 출력하려면 어떻게 해야 할까요?
	// @ResponseBody를 사용합니다.
	@RequestMapping(value = {"/pizza2"}, method = RequestMethod.GET)
	@ResponseBody // JSP를 통과하지 않고 출력
	public Pizza getPizza2() {
		return new Pizza("불고기"); // 객체를 출력
	}

	@RequestMapping(value = {"/pizza.xml"}, method = RequestMethod.GET)
	@ResponseBody // JSP를 통과하지 않고 출력
	public Pizza getPizza3() {
		return new Pizza("한우불고기"); // 객체를 출력
	}
	// produces를 이용하여 출력되는 자료형을 지정할 수 있다.
	@RequestMapping(value = {"/pizza2.xml"}, produces = {MediaType.APPLICATION_XML_VALUE})
	@ResponseBody // JSP를 통과하지 않고 출력
	public Pizza getPizza4() {
		return new Pizza("콜라비"); // 객체를 출력
	}

	@RequestMapping(value = {"/pizza.json"}, produces = {MediaType.APPLICATION_JSON_VALUE})
	@ResponseBody // JSP를 통과하지 않고 출력
	public Pizza getPizza5() {
		return new Pizza("콜라비"); // 객체를 출력
	}
	
	// 뉴스를 읽어서 출력해보자!!!!
	@Autowired
	private RssService rssService;
	
	@GetMapping(value = "/rss")
	public String getRss(@RequestParam(required = false, defaultValue = "03") String no, Model model) {
		String urlAddress="https://rss.etnews.com/" + no + ".xml";
		Rss rss = rssService.readRss(urlAddress);
		model.addAttribute("rss", rss);
		return "rss";
	}
	
	@GetMapping(value = "/rss2")
	public String getRss2(@RequestParam(required = false, defaultValue = "it") String sec, Model model) {
		String urlAddress="https://rss.hankyung.com/feed/" + sec + ".xml";
		Rss2 rss = rssService.readRss2(urlAddress);
		model.addAttribute("rss", rss);
		return "rss2";
	}
	
	
}
