package kr.human.mvc.vo;

import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;

import lombok.Data;

@Data
@XmlRootElement
public class Rss {
	private Channel channel;
	
	@Data
	@XmlRootElement
	public static class Channel{
		private String title; // 언론사 제목
		private String link; // 언론사 대표 주소
		private String description; // 언론사 설명
		private Image  image; // 언론사 이미지
		private List<Item>  item; // 기사 목록
	}

	@Data
	@XmlRootElement
	public static class Image{
		private String title; // 언론사 이미지 제목
		private String url; // 이미지 주소
		private String link; // 이미지 클릭시 이동할 주소
	}
	
	@Data
	@XmlRootElement
	public static class Item{
		private String title; // 기사 제목
		private String link; // 기사 URL		
		private String description; // 기사 간략 설명
		private String author; // 기가 작성자
		private String pubDate; // 기사 날짜
	}
}
