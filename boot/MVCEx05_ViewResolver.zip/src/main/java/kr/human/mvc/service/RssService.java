package kr.human.mvc.service;

import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.springframework.stereotype.Service;

import kr.human.mvc.vo.Rss;
import kr.human.mvc.vo.Rss2;

@Service
public class RssService {
	
	// 기사를 읽어서 리턴해주는 메서드 작성
	public Rss readRss(String urlAddress) {
		Rss rss = null;
		// 읽기
		try {
			JAXBContext context = JAXBContext.newInstance(Rss.class);
			URL url = new URL(urlAddress);
			Unmarshaller unmarshaller = context.createUnmarshaller();
			rss = (Rss) unmarshaller.unmarshal(new InputStreamReader(url.openStream(),"UTF-8"));
		} catch (JAXBException e) {
			e.printStackTrace();
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return rss;
	}
	// 기사를 읽어서 리턴해주는 메서드 작성
	public Rss2 readRss2(String urlAddress) {
		Rss2 rss = null;
		// 읽기
		try {
			JAXBContext context = JAXBContext.newInstance(Rss2.class);
			URL url = new URL(urlAddress);
			Unmarshaller unmarshaller = context.createUnmarshaller();
			rss = (Rss2) unmarshaller.unmarshal(new InputStreamReader(url.openStream(),"UTF-8"));
		} catch (JAXBException e) {
			e.printStackTrace();
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return rss;
	}
}
