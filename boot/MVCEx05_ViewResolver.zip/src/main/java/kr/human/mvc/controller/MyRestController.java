package kr.human.mvc.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import kr.human.mvc.service.RssService;
import kr.human.mvc.vo.PersonVO;
import kr.human.mvc.vo.Pizza;
import kr.human.mvc.vo.Rss;
import kr.human.mvc.vo.Rss2;

@RestController // 직접출력해라. @ResponseBody가 모두 적용된다.
@RequestMapping("/api") // 아래의 모든 주소를 /api밑으로 만들어라
public class MyRestController {

	@RequestMapping(value = {"/pizza"}, method = RequestMethod.GET)
	public Pizza getPizza2() {
		return new Pizza("불고기"); // 객체를 출력
	}

	@RequestMapping(value = {"/pizza.xml"}, method = RequestMethod.GET)
	public Pizza getPizza3() {
		return new Pizza("한우불고기"); // 객체를 출력
	}
	// produces를 이용하여 출력되는 자료형을 지정할 수 있다.
	@RequestMapping(value = {"/pizza2.xml"}, produces = {MediaType.APPLICATION_XML_VALUE})
	public Pizza getPizza4() {
		return new Pizza("콜라비"); // 객체를 출력
	}

	@RequestMapping(value = {"/pizza.json"}, produces = {MediaType.APPLICATION_JSON_VALUE})
	public Pizza getPizza5() {
		return new Pizza("콜라비"); // 객체를 출력
	}

	@RequestMapping(value = {"/person"}, method = RequestMethod.GET)
	public PersonVO getPersonVO1() {
		return new PersonVO("한사람", 22, true); // 객체를 출력
	}
	// produces를 이용하여 출력되는 자료형을 지정할 수 있다.
	@RequestMapping(value = {"/person.xml"}, produces = {MediaType.APPLICATION_XML_VALUE})
	public PersonVO getPersonVO2(){
		return new PersonVO("한사람", 22, true); // 객체를 출력
	}
	
	@RequestMapping(value = {"/person.json"}, produces = {MediaType.APPLICATION_JSON_VALUE})
	public PersonVO getPersonVO3() {
		return new PersonVO("한사람", 22, true); // 객체를 출력
	}

	// 뉴스를 읽어서 출력해보자!!!!
	@Autowired
	private RssService rssService;
	
	@GetMapping(value = "/rss.json", produces = {MediaType.APPLICATION_JSON_VALUE})
	public Rss getRss(@RequestParam(required = false, defaultValue = "03") String no) {
		String urlAddress="https://rss.etnews.com/" + no + ".xml";
		Rss rss = rssService.readRss(urlAddress);
		return rss;
	}

	@GetMapping(value = "/rss2.json", produces = {MediaType.APPLICATION_JSON_VALUE})
	public Rss2 getRss2(@RequestParam(required = false, defaultValue = "it") String sec) {
		String urlAddress="https://rss.hankyung.com/feed/" + sec + ".xml";
		Rss2 rss = rssService.readRss2(urlAddress);
		return rss;
	}

}
