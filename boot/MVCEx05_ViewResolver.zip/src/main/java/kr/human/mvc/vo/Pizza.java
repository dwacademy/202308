package kr.human.mvc.vo;

import java.util.Arrays;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@XmlRootElement // 클래스이름을 루트 태그로 사용하겠다.
@XmlAccessorType(XmlAccessType.FIELD) // 속성으로쓸건지 태그로 쓸건지를 필드에 기술하겠다.
@XmlType(propOrder = {"name","flavor","toppings"}) // XML로 출력시 나타날 순서 지정
public class Pizza {
	@XmlElement // 태그로 쓰겠다. 이름을 지정하지 않으면 태그이름이 필드명이 된다.
	private String name;
	@XmlAttribute // 속성으로 쓰겠다. 이름을 지정하지 않으면 태그이름이 필드명이 된다.
	private String flavor;
	@XmlElement // 태그로 쓰겠다. 이름을 지정하지 않으면 태그이름이 필드명이 된다.
	private List<String> toppings;
	
	public Pizza(String name) {
		this.name = name;
		this.flavor = "spicy";
		this.toppings = Arrays.asList("치즈,파인애플,감자".split(","));
	}
}
