package kr.human.boot;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController // View를 통과하지 않고 바로 출력해라!!!
public class HomeController {

	@RequestMapping(value = "/")
	public String home() {
		return "Hello Boot Application!!!!";
	}
}
