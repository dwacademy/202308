package kr.human.boot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootEx02HelloWorldGradleApplication {

	public static void main(String[] args) {
		SpringApplication.run(BootEx02HelloWorldGradleApplication.class, args);
	}

}
