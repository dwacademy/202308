package kr.human.app.service;

import org.springframework.stereotype.Component;

@Component
public class AnotherBean {
	
	public void printAnotherMessage() {
		System.out.println("나는 쿼츠에 의해서 자동으로 불려지는 메서드 일껄~~~~~~~~~~~~~~~ ");
	}
}
