package kr.human.boot.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import kr.human.boot.dao.PersonRepository;
import kr.human.boot.vo.Person;

@Service
public class PersonService {

	@Autowired
	private PersonRepository personRepository;
	
	// long count() : 개수를 리턴한다.
	public long selectCount() {
		return personRepository.count();
	}
	// 순서대로 얻기
	public List<Person> selectListAsc(){
		List<Person> list = new ArrayList<>();
		personRepository.findAll().forEach(list::add);
		return list;
	}
	// 순서 역순 으로 얻기
	public List<Person> selectListDesc(){
		List<Person> list = new ArrayList<>();
		personRepository.findAllByOrderByIdxDesc().forEach(list::add);
		return list;
	}
	// 1개 저장하기
	// save(S 엔티티) - 주어진 엔티티를 저장합니다.
	public void insert(Person person) {
		if(person!=null) {
			person.setRegdate(new Date());
			personRepository.save(person);
		}
	}
	
	// 여러개를 한번에 저장해 준다.
	// Iterable  saveAll(Iterable entities) - 주어진 모든 엔티티를 저장합니다.
	public void insertAll(List<Person> persons) {
		if(persons!=null && persons.size()>0) {
			for(Person p : persons) p.setRegdate(new Date()); // 날짜 넣기
			personRepository.saveAll(persons);
		}
	}
}
