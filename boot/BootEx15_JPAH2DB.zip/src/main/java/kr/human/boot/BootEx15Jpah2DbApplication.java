package kr.human.boot;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import kr.human.boot.service.PersonService;
import kr.human.boot.vo.Person;

@SpringBootApplication
public class BootEx15Jpah2DbApplication {

	
	public static void main(String[] args) {
		SpringApplication.run(BootEx15Jpah2DbApplication.class, args);
	}

	@Bean
	public CommandLineRunner commandLineRunner(PersonService personService) {
		return (args)->{
			// 1개 저장
			personService.insert(new Person("한사람", 22, false, null));
			
			// 여러개 저장
			List<Person> list = new ArrayList<>();
			list.add(new Person("두사람", 22, false, null));
			list.add(new Person("세사람", 33, true, null));
			list.add(new Person("네사람", 41, true, null));
			list.add(new Person("오사람", 53, false, null));
			
			personService.insertAll(list);
		};
	}
	
}
