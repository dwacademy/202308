package kr.human.boot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BootEx15Jpah2DbApplicationTests {

	@Test
	void contextLoads() {
	}

}
