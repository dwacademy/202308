CREATE SEQUENCE memo_idx_seq;
CREATE TABLE memo(
	idx NUMBER PRIMARY KEY ,
	name varchar2(20) NOT NULL,
	password varchar2(60) NOT NULL,
	content varchar2(2000) NOT NULL,
	regdate timestamp DEFAULT sysdate,
	ip varchar2(20) NOT NULL
); 

SELECT * FROM memo;