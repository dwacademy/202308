package kr.human.mvc.service;

import java.util.HashMap;

import kr.human.mvc.vo.TestVO;

public interface TestService {
	String selectToday();
	TestVO selectVO(int num1, int num2);
	HashMap<String, Object> selectMap(int num1, int num2);
}
