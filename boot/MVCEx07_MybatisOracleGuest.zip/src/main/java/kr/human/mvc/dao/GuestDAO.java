package kr.human.mvc.dao;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;

import kr.human.mvc.vo.GuestVO;

public interface GuestDAO {
	//<!-- 1. 1 페이지 얻기 -->
	List<GuestVO> selectList(HashMap<String, Integer> map) throws SQLException;
	//<!-- 2. 저장 -->
	void insert(GuestVO vo) throws SQLException;
	//<!-- 3. 수정 -->
	void update(GuestVO vo) throws SQLException;
	//<!-- 4. 삭제 -->
	void delete(int idx) throws SQLException;
	//<!-- 5. 1개얻기 -->
	GuestVO selectByIdx(int idx) throws SQLException;
	//<!-- 6. 전체 개수 얻기 -->
	int selectCount() throws SQLException;
}
