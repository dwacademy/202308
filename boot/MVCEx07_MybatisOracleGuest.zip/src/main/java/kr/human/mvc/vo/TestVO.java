package kr.human.mvc.vo;

import java.util.Date;

import lombok.Data;

@Data
public class TestVO {
	private Date today;
	private int num1;
	private int num2;
	private int sum;
	private int mul;
}
