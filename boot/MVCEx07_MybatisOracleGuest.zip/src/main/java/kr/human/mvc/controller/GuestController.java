package kr.human.mvc.controller;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.servlet.support.RequestContextUtils;

import kr.human.mvc.service.GuestService;
import kr.human.mvc.vo.GuestVO;
import lombok.extern.slf4j.Slf4j;

@Controller
@RequestMapping("/guest") // 컨트롤러에 맵핑을 하면 경로가 된다.
@Slf4j
public class GuestController {
	@Autowired
	private GuestService guestService;
	
	@RequestMapping(value = "/list")
	public String list(
			@RequestParam Map<String, String> params,
			@RequestParam(required = false, defaultValue="1") Integer p,
			@RequestParam(required = false, defaultValue="5") Integer s,
			@RequestParam(required = false, defaultValue="5") Integer b,
			HttpServletRequest request, 
			Model model
			) {
		
		Map<String, ?> flashMap = RequestContextUtils.getInputFlashMap(request);
		log.debug("flashMap : {}", flashMap);
		log.debug("params : {}", params);
		log.debug("method : {}", request.getMethod());
		if(flashMap!=null) { //flashMap이 존재하면
			// 맵에서 읽어서 값을 가벼오고 
			params = (Map<String, String>) flashMap.get("map");
			p = Integer.parseInt(params.get("p"));
			s = Integer.parseInt(params.get("s"));
			b = Integer.parseInt(params.get("b"));
		}else { //flashMap이 존재하지 않으면
			// 넘어온값 가지고
			// 만약에 GET방식으로 넘오온 값이 있다면
			if(request.getMethod().equals("GET")) {
				p=1;s=5;b=5; // 초기값으로 줘버린다.
			}
		}
		log.debug("p,s,b : {},{},{}", p,s,b);
		model.addAttribute("pv", guestService.selectList(p, s, b));
		model.addAttribute("newLine", "\n");
		model.addAttribute("br", "<br>");
		return "guestList";
	}
	// 모든 값들은 VO로 받지만 mode는 받지 않는다. 그래서 별도로 받는다.
	// Get 방식의 요청의 경우는 누군가가 직접 주소를 타이핑했다. 이것은 막아야 한다.
	@RequestMapping(value = "updateOk", method=RequestMethod.GET)
	public String updateOk() {
		return "redirect:/memo/list";
	}
	
	// POST방식의 요청이면 폼을 통해서 받았다. 정상적인 호출이다. 
	@RequestMapping(value = "updateOk", method=RequestMethod.POST)
	public String updateOk(@ModelAttribute GuestVO guestVO, 
			@RequestParam String mode,
			@RequestParam(defaultValue = "1", required = false) Integer p,
			@RequestParam(defaultValue = "5", required = false) Integer s,
			@RequestParam(defaultValue = "5", required = false) Integer b,
			RedirectAttributes redirectAttributes /* POST전송에 필요함!!!! */
			) {
		switch (mode) {
		case "insert":
			if(guestVO!=null) {
				if(guestService.insert(guestVO)) {
					log.debug("저장성공 : {}", guestVO.toString());
					p = 1; // 저장하고는 1페이지로 간다.
				}else {
					log.debug("저장실패 : {}", guestVO.toString());
				}
			}
			break;
		case "update":
			if(guestVO!=null) {
				if(guestService.update(guestVO)) {
					log.debug("수정성공 : {}", guestVO.toString());
				}else {
					log.debug("수정실패 : {}", guestVO.toString());
				}
			}
			break;
		case "delete":
			if(guestVO!=null) {
				if(guestService.delete(guestVO)) {
					log.debug("삭제성공 : {}", guestVO.toString());
				}else {
					log.debug("삭제실패 : {}", guestVO.toString());
				}
			}
			break;

		}
		// return "redirect:/memo/list?p=" + p + "&s=" + s + "&b=" + b; // GET 방식의 리다렉트!!!
		// POST 방식으로 리다이렉션할때 값을 넘기는 방식!!!
		// 1. 인수로 RedirectAttributes를 받는다.
		// 2. 넘길 값을 맵에 저장한다.
		Map<String, String> map = new HashMap<String, String>();
		map.put("p", p + "");
		map.put("s", s + "");
		map.put("b", b + "");
		// 3. RedirectAttributes에 담아서 전송한다.
		redirectAttributes.addFlashAttribute("map", map);
		// 4. 받는 쪽에서 GET/POST 처리를 한다.
		return "redirect:/guest/list"; // POST 방식의 리다렉트!!!
	}
	
}
