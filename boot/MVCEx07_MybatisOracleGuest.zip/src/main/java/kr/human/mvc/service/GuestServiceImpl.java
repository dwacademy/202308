package kr.human.mvc.service;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import kr.human.mvc.dao.GuestDAO;
import kr.human.mvc.vo.GuestVO;
import kr.human.mvc.vo.PagingVO;

@Service("guestService")
public class GuestServiceImpl implements GuestService{

	@Autowired
	private GuestDAO guestDAO;

	@Override
	public PagingVO<GuestVO> selectList(int currentPage, int pageSize, int blockSize) {
		PagingVO<GuestVO> pagingVO = null;
		try {
			int totalCount = guestDAO.selectCount();
			pagingVO = new PagingVO<GuestVO>(totalCount, currentPage, pageSize, blockSize); // 계산 완료
			HashMap<String, Integer> map = new HashMap<String, Integer>();
			map.put("startNo", pagingVO.getStartNo());
			map.put("endNo", pagingVO.getEndNo());
			List<GuestVO> list = guestDAO.selectList(map); // 목록가져오고
			pagingVO.setList(list); // 목록을 대입
		}catch (Exception e) {
			e.printStackTrace();
		}
		return pagingVO;
	}

	@Override
	public boolean insert(GuestVO guestVO) {
		boolean result = false;
		try {
			if(guestVO!=null) {
				guestDAO.insert(guestVO);
				result = true;
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	@Override
	public boolean update(GuestVO guestVO) {
		boolean result = false;
		try {
			if(guestVO!=null) {
				// 먼저 DB에서 원본을 가져온다. 원본의 비번과 현재 비번이 같을때만 수정한다.
				GuestVO dbVO = guestDAO.selectByIdx(guestVO.getIdx());
				if(dbVO!=null && dbVO.getPassword().equals(guestVO.getPassword())) {
					guestDAO.update(guestVO);
					result = true;
				}
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	@Override
	public boolean delete(GuestVO guestVO) {
		boolean result = false;
		try {
			if(guestVO!=null) {
				// 먼저 DB에서 원본을 가져온다. 원본의 비번과 현재 비번이 같을때만 삭제한다.
				GuestVO dbVO = guestDAO.selectByIdx(guestVO.getIdx());
				if(dbVO!=null && dbVO.getPassword().equals(guestVO.getPassword())) {
					guestDAO.delete(guestVO.getIdx()); // 삭제
					result = true;
				}
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
	
}
