package kr.human.mvc.service;

import kr.human.mvc.vo.GuestVO;
import kr.human.mvc.vo.PagingVO;

public interface GuestService {
	// 목록보기
	PagingVO<GuestVO> selectList(int currentPage, int pageSize, int blockSize);
	// 저장
	boolean insert(GuestVO vo);
	// 수정
	boolean update(GuestVO vo);
	// 삭제
	boolean delete(GuestVO vo);
}
