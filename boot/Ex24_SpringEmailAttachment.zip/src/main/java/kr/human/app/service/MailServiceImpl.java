package kr.human.app.service;

import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.mail.javamail.MimeMessagePreparator;
import org.springframework.stereotype.Service;

@Service("mailService")
public class MailServiceImpl implements MailService {

	@Autowired
	private JavaMailSender mailSender;

	@Override
	public void sendMail() {
		MimeMessagePreparator preparator = new MimeMessagePreparator() {

			@Override
			public void prepare(MimeMessage mimeMessage) throws Exception {
				MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, true, "UTF-8"); // Helper클래스를 이용한다.
				// 보낼 내용을 만든다.
				helper.setFrom("ithuman202303@gmail.com"); // 이놈은 반드시 XML에 지정한 인증 메일과 일치해야 한다.
				helper.setTo("ithuman202303@gmail.com");
				helper.setSubject("하하하하하 제목이야!!!!");
				helper.setText("<html><body><p>나는 내용입니다.</p><img src='cid:logo'></body></html>", true);
				// 첨부 파일의 이름을 logo로 바꿔서 첨부한다.
				helper.addInline("logo", new ClassPathResource("linux-icon.png"));
			}
		};
		try {
			mailSender.send(preparator);
			System.out.println("메일 발송 성공!!!!");
		} catch (Exception e) {
			System.out.println("메일 발송 실패!!!");
			e.printStackTrace();
		}
	}

	@Override
	public void sendMail(String toAddress, String subject, String content) {
		MimeMessagePreparator preparator = new MimeMessagePreparator() {

			@Override
			public void prepare(MimeMessage mimeMessage) throws Exception {
				MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, true, "UTF-8"); // Helper클래스를 이용한다.
				// 보낼 내용을 만든다.
				helper.setFrom("ithuman202303@gmail.com"); // 이놈은 반드시 XML에 지정한 인증 메일과 일치해야 한다.
				helper.setTo(toAddress);
				helper.setSubject(subject);
				helper.setText("<html><body><p>" + content + "</p><img src='cid:logo'></body></html>", true);
				// 첨부 파일의 이름을 logo로 바꿔서 첨부한다.
				helper.addInline("logo", new ClassPathResource("linux-icon.png"));
				// 첨부 파일의 첨부한다.
				helper.addAttachment("logo한글.png", new ClassPathResource("linux-icon.png"));
				helper.addAttachment("이쁜펭귄.png", new ClassPathResource("logo2.png"));
			}
		};
		try {
			mailSender.send(preparator);
			System.out.println("메일 발송 성공!!!!");
		} catch (Exception e) {
			System.out.println("메일 발송 실패!!!");
			e.printStackTrace();
		}
	}

}
