drop table examResult;
create table examResult(
	idx int primary key auto_increment,
	name varchar(100) not null,
	date date not null,
	score int(5)
);
