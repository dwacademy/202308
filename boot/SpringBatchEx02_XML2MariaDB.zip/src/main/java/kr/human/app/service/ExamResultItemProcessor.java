package kr.human.app.service;

import org.springframework.batch.item.ItemProcessor;

import kr.human.app.vo.ExamResult;

// 1개의 아이템을 읽을때마다 처리할 클래스(선택)
public class ExamResultItemProcessor implements ItemProcessor<ExamResult, ExamResult>{

	@Override
	public ExamResult process(ExamResult item) throws Exception {
		return item;
	}

}
