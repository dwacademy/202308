package kr.human.app.service;

import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.springframework.batch.item.database.ItemPreparedStatementSetter;

import kr.human.app.vo.ExamResult;

// 객체를 받아 SQL명령어의 ?를 채워주는 클래스
public class ExamResultItemPreparedStatementSetter implements ItemPreparedStatementSetter<ExamResult>{

	@Override
	public void setValues(ExamResult item, PreparedStatement ps) throws SQLException {
		ps.setString(1, item.getName());
		ps.setDate(2, new java.sql.Date(item.getDate().getTime()));
		ps.setInt(3, item.getScore());
		
	}

}
