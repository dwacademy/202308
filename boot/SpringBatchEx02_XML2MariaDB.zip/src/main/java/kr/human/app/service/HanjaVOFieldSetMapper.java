package kr.human.app.service;

import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FieldSet;
import org.springframework.validation.BindException;

import kr.human.app.vo.HanjaVO;

public class HanjaVOFieldSetMapper implements FieldSetMapper<HanjaVO>{

	// FieldSet : 1줄의 데이터. DB로 보면 ResultSet과 같다.
	// 1줄을 읽어서 VO를 만들어 리턴해주면 된다.
	@Override
	public HanjaVO mapFieldSet(FieldSet fieldSet) throws BindException {
		HanjaVO hanjaVO = new HanjaVO();
		// VO를 채워준다.
		hanjaVO.setIndex(fieldSet.readInt(0));
		hanjaVO.setH(fieldSet.readString(1));
		hanjaVO.setK(fieldSet.readString(3));
		return hanjaVO;
	}

}
