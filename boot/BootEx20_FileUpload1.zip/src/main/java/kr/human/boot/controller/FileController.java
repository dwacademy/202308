package kr.human.boot.controller;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.InputStreamResource;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import kr.human.boot.vo.FileVO;
import lombok.extern.slf4j.Slf4j;

@Controller
@Slf4j
public class FileController {

	// application.properties에 등록된 파일의 경로를 가져온다.
	// @Value("${spring.servlet.multipart.location}")
	String filePath;
	
	@Autowired
	ResourceLoader resourceLoader;
	
	@GetMapping(value = "/uploadForm")
	public String uploadForm() {
		return "uploadForm";
	}
	
	// 업로드를 처리할 주소를 생성
	@GetMapping(value = "/uploadOk")
	public String uplaodOkGet() {
		return "redirect:/uploadForm";
	}
	// 파일 업로드를 처리할 메서드
	@PostMapping(value = "/uploadOk")
	public String uplaodOkPost(
			@RequestParam(required = false, defaultValue = "파일설명이다.")String content, // 일반값 받기
			@RequestParam MultipartFile[] uploadFile, // 파일을 배열로 받기
			Model model) throws IllegalStateException, IOException {
			//=====================================================================================
			// 여기를 추가함 위에 아래의 두줄을 필드로 추가하고
			// @Autowired
			// ResourceLoader resourceLoader;
		
			filePath = resourceLoader.getResource("/").getURI().toString() + "upload/"; // 절대경로
			filePath = filePath.substring(6); // 앞의 6자리 없애기
			log.info("-".repeat(80));
			log.info(filePath);
			File f = new File(filePath); // 파일객체
			if(!f.exists()) f.mkdirs();  // 폴더가 없으면 생성
			log.info("-".repeat(80));
			//=====================================================================================
			model.addAttribute("content", content);
			List<FileVO> list = new ArrayList<>();
			if(uploadFile!=null && uploadFile.length>0) { //파일이 넘어 왔다면 
				for(MultipartFile file : uploadFile) {
					if(!file.isEmpty()) { // 파일이 있다면
						FileVO vo = new FileVO( UUID.randomUUID().toString(), 
												file.getOriginalFilename(), 
												file.getContentType());
						list.add(vo);
						
						// 실제 파일을 저장해줘야 한다.
						File newFile = new File(filePath + vo.getUuid() + "_" + vo.getFileName());
						file.transferTo(newFile);
						
					}
				}
			}
			model.addAttribute("files", list);
			return "result";
	}
	// 파일을 다운로드할 메서드
	@GetMapping(value = "/download")
	public ResponseEntity<Resource> download(@ModelAttribute FileVO vo) throws IOException{
		Path path = Paths.get(filePath + "/" + vo.getUuid() + "_" + vo.getFileName());
		log.info("실제 저장위치 : {}", path.toString());
		String contentType = Files.probeContentType(path); // 파일 종류
		// 다운로드를 하려면 헤더의 값을 변경해야 한다.
		HttpHeaders headers = new HttpHeaders();
		// 첨부파일을 원본이름으로 바꿔서 다운로드를 해야한다. 다운로드될 파일의 이름을 지정
		headers.setContentDisposition(
				ContentDisposition.builder("attachment").filename(vo.getFileName(),StandardCharsets.UTF_8).build());
		// 파일의 종류 지정
		headers.add(HttpHeaders.CONTENT_TYPE, contentType);
		// 실제 파일의 리소스 객체
		Resource resource = new InputStreamResource(Files.newInputStream(path));
		// 값을 리턴하면 다운로드가 진행된다.
		return new ResponseEntity<>(resource, headers, HttpStatus.OK);
		
	}
	
}
