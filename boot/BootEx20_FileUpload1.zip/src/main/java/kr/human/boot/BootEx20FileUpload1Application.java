package kr.human.boot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootEx20FileUpload1Application {

	public static void main(String[] args) {
		SpringApplication.run(BootEx20FileUpload1Application.class, args);
	}

}
