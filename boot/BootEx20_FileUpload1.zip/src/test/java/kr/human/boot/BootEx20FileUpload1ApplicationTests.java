package kr.human.boot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BootEx20FileUpload1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
