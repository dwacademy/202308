package kr.human.di.vo;

public interface MessageService {
	boolean sendMessage(String msg, String rec);
}