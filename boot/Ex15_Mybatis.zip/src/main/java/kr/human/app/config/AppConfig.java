package kr.human.app.config;

import javax.sql.DataSource;

import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.mapper.MapperScannerConfigurer;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

@Configuration // 환경설정 파일이다.
@ComponentScan(basePackages = {"kr.human.app"}) // 자동으로 검색해서 객체를 등록해라
@PropertySource(value = {"classpath:jdbc.properties"})
public class AppConfig {
	@Value("${m.driver}")
	private String driverClassName;
	@Value("${m.url}")
	private String url;
	@Value("${m.username}")
	private String username;
	@Value("${m.password}")
	private String password;
	
	@Bean("dataSource")
	public DataSource getDataSource() {
		// System.out.println("개발용 데이터베이스 입니다.......");
		// 여기서는 MariaDB의 데이터 소스를 생성한다.
		DriverManagerDataSource dataSource = new DriverManagerDataSource();
		dataSource.setDriverClassName("net.sf.log4jdbc.sql.jdbcapi.DriverSpy");
		dataSource.setUrl("jdbc:log4jdbc:mysql://localhost:3306/jspdb");
		dataSource.setUsername("jspuser");
		dataSource.setPassword("123456");
		return dataSource;
	}

	@Bean // @Value를 사용할 경우에 반드시 만들어 준다.
	public static PropertySourcesPlaceholderConfigurer placeholderConfigurer() {
		return new PropertySourcesPlaceholderConfigurer();
	}

	// 스프링에서 제공하는 DB연결 객체!!!! 
	@Bean
	public JdbcTemplate jdbcTemplate() {
		return new JdbcTemplate(getDataSource());
	}
	
	// ibatis 객체 등록 
	/*
	@SuppressWarnings("deprecation")
	@Bean("sqlMapClient")
	public SqlMapClientFactoryBean sqlMapClient() {
		SqlMapClientFactoryBean sqlMapClient = new SqlMapClientFactoryBean();
		sqlMapClient.setDataSource(getDataSource());
		PathMatchingResourcePatternResolver pmrpr = new PathMatchingResourcePatternResolver();
		sqlMapClient.setConfigLocation(pmrpr.getResource("classpath:SqlMapConfig.xml"));
		return sqlMapClient;
	}
	*/
	
	@Bean("sqlSessionFactory")
	public SqlSessionFactoryBean sqlSessionFactory() {
		SqlSessionFactoryBean sessionFactoryBean = new SqlSessionFactoryBean();
		sessionFactoryBean.setDataSource(getDataSource());
		sessionFactoryBean.setTypeAliasesPackage("kr.human.app.vo");
		PathMatchingResourcePatternResolver pmrpr = new PathMatchingResourcePatternResolver();
		sessionFactoryBean.setMapperLocations(pmrpr.getResource("classpath:/kr/human/app/dao/testMapper.xml"));
		return sessionFactoryBean;
	}
	
	@Bean
	public MapperScannerConfigurer getMapperScannerConfigurer() {
		MapperScannerConfigurer mapperScannerConfigurer = new MapperScannerConfigurer();
		mapperScannerConfigurer.setBasePackage("kr.human.app.dao");
		mapperScannerConfigurer.setSqlSessionFactoryBeanName("sqlSessionFactory");
		return mapperScannerConfigurer;
	}
}
