package kr.human.webjars;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@ResponseBody
@RequestMapping("/api2")
public class APIHomeController2 {

	@GetMapping(value = {"/","/today"})
	public String index(Model model) {
		return LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy년 MM월 dd일(EEEE) hh:mm:ss"));
	}
	/*
	스프링 프레임워크에서 비동기 통신, 
	즉 API 통신을 구현하기 위해 @RequestBody와 @ResponseBody 어노테이션을 사용한다.
	클라이언트 -> 서버 요청 : @RequestBody
	서버 -> 클라이언트 응답 : @ResponseBody
	 */
	@PostMapping("/user1") // @RequestBody로 받기
	public UserVO putUser1(@RequestBody UserVO userVO) {
		System.out.println("받은값 : " + userVO);
		return userVO;
	}
	
	@PostMapping("/user2") // @ModelAttribute로 받기
	public UserVO putUser2(@ModelAttribute UserVO userVO) {
		System.out.println("받은값 : " + userVO);
		return userVO;
	}
}
