package kr.human.boot.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import kr.human.boot.dao.PersonVORepository;
import kr.human.boot.vo.PersonVO;

@RestController
public class PersonVOController {

	@Autowired
	private PersonVORepository personVORepository;

	@GetMapping("/persons")
	List<PersonVO> all() {
		List<PersonVO> list = new ArrayList<>();
		personVORepository.findAll().forEach(list::add);
		return list;
	}
	@PostMapping("/persons")
	PersonVO newPerson(@RequestBody PersonVO personVO) {
		return personVORepository.save(personVO);
	}
	@GetMapping("/persons/{id}")
	PersonVO one(@PathVariable Long id) {
		return personVORepository.findById(id).orElse(null);
	}
	@PutMapping("/persons/{id}")
	PersonVO replaceEmployee(@RequestBody PersonVO newPersonVO, @PathVariable Long id) {
		Optional<PersonVO> optionalPersonVO = personVORepository.findById(id);
		if(optionalPersonVO.isPresent()) {
			PersonVO personVO = optionalPersonVO.get();
			personVO.setName(newPersonVO.getName());
			personVO.setAge(newPersonVO.getAge());
			personVO.setGender(newPersonVO.getGender());
			return personVORepository.save(personVO);
		}else{
			return null;
		}
	}
	@DeleteMapping("/persons/{id}")
	PersonVO deleteEmployee(@PathVariable Long id) {
		Optional<PersonVO> optionalPersonVO = personVORepository.findById(id);
		if(optionalPersonVO.isPresent()) {
			personVORepository.deleteById(id);
			return optionalPersonVO.get();
		}else{
			return null;
		}
	}
}