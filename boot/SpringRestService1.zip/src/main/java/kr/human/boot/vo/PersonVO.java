package kr.human.boot.vo;

import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.util.StdConverter;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

// https://stackify.com/java-xml-jackson/ 참조
@Entity
@JacksonXmlRootElement(localName = "Person")
@JsonPropertyOrder({"idx", "age", "gender", "name"})
@Data
@AllArgsConstructor
@NoArgsConstructor
public class PersonVO {
	
	@JacksonXmlProperty
	private @Id @GeneratedValue Long id;
	@JacksonXmlProperty
	private String name;
	@JacksonXmlProperty(isAttribute = true)
	private int age;
	@JacksonXmlProperty
	@JsonSerialize(converter=Gender2String.class)
	@JsonDeserialize(converter=String2Gender.class)
	private Boolean gender;

	public PersonVO(String name, int age, Boolean gender) {
		super();
		this.name = name;
		this.age = age;
		this.gender = gender;
	}
	
	@Override
	public String toString() {
		return name + "(" + age + "세, " + (gender ? "남":"여") + ")";
	}

	public static class Gender2String extends StdConverter<Boolean, String>{
		@Override
		public String convert(Boolean value) {
			return value ? "남자" : "여자";
		}
	}
	public static class String2Gender extends StdConverter<String, Boolean>{

		@Override
		public Boolean convert(String value) {
			return value.equals("남자");
		}
	}
}
