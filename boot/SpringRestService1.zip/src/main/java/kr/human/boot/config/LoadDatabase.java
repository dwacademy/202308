package kr.human.boot.config;

import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import kr.human.boot.dao.EmployeeRepository;
import kr.human.boot.dao.PersonVORepository;
import kr.human.boot.vo.Employee;
import kr.human.boot.vo.PersonVO;
import lombok.extern.slf4j.Slf4j;

@Configuration
@Slf4j
public class LoadDatabase {

  @Bean
  CommandLineRunner initDatabase1(EmployeeRepository repository) {
    return args -> {
      log.info("저장 " + repository.save(new Employee("한사람", "DBA")));
      log.info("저장 " + repository.save(new Employee("두사람", "관리자")));
    };
  }
  @Bean
  CommandLineRunner initDatabase2(PersonVORepository repository) {
	  return args -> {
		  log.info("저장 " + repository.save(new PersonVO("한사람",24,true)));
		  log.info("저장 " + repository.save(new PersonVO("두사람",18,false)));
		  log.info("저장 " + repository.save(new PersonVO("세사람",32,true)));
		  log.info("저장 " + repository.save(new PersonVO("네사람",21,false)));
		  log.info("저장 " + repository.save(new PersonVO("오사람",47,true)));
	  };
  }
}