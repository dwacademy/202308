package kr.human.boot.vo;

import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@JacksonXmlRootElement(localName = "Employee")
@JsonPropertyOrder({"id", "name", "role"})
public class Employee {
	@JacksonXmlProperty(isAttribute = true)
	private @Id @GeneratedValue Long id;
	@JacksonXmlProperty
	private String name;
	@JacksonXmlProperty
	private String role;

	public Employee(String name, String role) {
		super();
		this.name = name;
		this.role = role;
	}
}