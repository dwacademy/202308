package kr.human.boot.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import kr.human.boot.dao.EmployeeRepository;
import kr.human.boot.vo.Employee;

@RestController
public class EmployeeController {

	@Autowired
	private EmployeeRepository employeeRepository;

	@GetMapping("/employees")
	List<Employee> all() {
		List<Employee> list = new ArrayList<>();
		employeeRepository.findAll().forEach(list::add);
		return list;
	}
	@PostMapping("/employees")
	Employee newEmployee(@RequestBody Employee newEmployee) {
		return employeeRepository.save(newEmployee);
	}
	@GetMapping("/employees/{id}")
	Employee one(@PathVariable Long id) {
		return employeeRepository.findById(id).orElse(null);
		//return employeeRepository.findById(id).orElseThrow(()->new EmployeeNotFoundException(id));
	}
	@PutMapping("/employees/{id}")
	Employee replaceEmployee(@RequestBody Employee newEmployee, @PathVariable Long id) {
		Optional<Employee> optionalEmployee = employeeRepository.findById(id);
		if(optionalEmployee.isPresent()) {
			Employee employee = optionalEmployee.get();
			employee.setName(newEmployee.getName());
			employee.setRole(newEmployee.getRole());
			return employeeRepository.save(employee);
		}else{
			return null;
		}
	}
	@DeleteMapping("/employees/{id}")
	Employee deleteEmployee(@PathVariable Long id) {
		Optional<Employee> optionalEmployee = employeeRepository.findById(id);
		if(optionalEmployee.isPresent()) {
			employeeRepository.deleteById(id);
			return optionalEmployee.get();
		}else{
			return null;
		}
	}
}