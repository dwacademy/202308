package kr.human.boot.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import kr.human.boot.vo.PersonVO;

@RestController
@RequestMapping(value = "/api/")
public class HomeRestController {
    @RequestMapping(method = RequestMethod.GET, value = "/", produces = MediaType.TEXT_PLAIN_VALUE)
    public String sample(@RequestParam(defaultValue = "한사람", required = false) String param) {
        return "Hello " + param;
    }
    @RequestMapping(method = RequestMethod.GET, value = "person.txt", produces = MediaType.TEXT_PLAIN_VALUE)
    public String personText() {
    	return new PersonVO("한사람", 23, false).toString();
    }
    @RequestMapping(method = RequestMethod.GET, value = "person.json", produces = MediaType.APPLICATION_JSON_VALUE)
    public PersonVO personJson() {
    	return new PersonVO("한사람", 23, false);
    }
    @RequestMapping(method = RequestMethod.GET, value = "persons.json", produces = MediaType.APPLICATION_JSON_VALUE)
    public List<PersonVO> personListJson() {
    	List<PersonVO> list = new ArrayList<>();
    	list.add(new PersonVO("한사람", 23, false));
    	list.add(new PersonVO("두사람", 23, false));
    	list.add(new PersonVO("세사람", 23, false));
    	list.add(new PersonVO("네사람", 23, false));
    	return list;
    }
    @RequestMapping(method = RequestMethod.GET, value = "person.xml",produces = MediaType.APPLICATION_XML_VALUE)
    public PersonVO personXML() {
		return new PersonVO("한사람", 23, false);
    }
}
