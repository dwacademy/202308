package com.tistory.top2blue.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.tistory.top2blue.service.MemberService;
import com.tistory.top2blue.vo.Member;

import lombok.extern.slf4j.Slf4j;

@Controller
@Slf4j
@RequestMapping(value = "/members")
public class PersonController {
	@Autowired
	private MemberService memberService;
	
	@GetMapping(value = {"/","/list"})
	public String findAll(Model model) throws Exception {
		log.info("컨트롤러 findAll() 호출");
		List<Member> memberList = memberService.findAll();
		log.info("컨트롤러 findAll() 리턴 : {}", memberList);
		model.addAttribute("list", memberList);
		return "member/list";
	}

	@GetMapping(value = {"/findByName"})
	public String findByName(@RequestParam(defaultValue = "한사람")String name, Model model) throws Exception {
		log.info("컨트롤러 findByName({}) 호출", name);
		List<Member> memberList = memberService.findByName2(name);
		log.info("컨트롤러 findByName({}) 리턴 : {}", name, memberList);
		model.addAttribute("list", memberList);
		return "member/list";
	}

	@GetMapping(value = {"/findByName3"})
	public String findByName3(@RequestParam(defaultValue = "한사람")String name, Model model) throws Exception {
		log.info("컨트롤러 findByName3({}) 호출", name);
		List<Member> memberList = memberService.findByName3(name);
		log.info("컨트롤러 findByName3({}) 리턴 : {}", name, memberList);
		model.addAttribute("list", memberList);
		return "member/list";
	}
	
	@GetMapping(value = {"/findByGenderAge"})
	public String findByGenderAge(@RequestParam(defaultValue = "true")Boolean gender, @RequestParam(defaultValue = "22")int age, Model model) throws Exception {
		log.info("컨트롤러 findByGenderAge({},{}) 호출", gender, age);
		List<Member> memberList = memberService.findByGenderAge(gender, age);
		log.info("컨트롤러 findByGenderAge({},{}) 리턴 : {}", gender, age, memberList);
		model.addAttribute("list", memberList);
		return "member/list";
	}
	
	@GetMapping(value = {"/findByMaxMinAge"})
	public String findByMaxMinAge(Model model) throws Exception {
		log.info("컨트롤러 findByMaxMinAge() 호출");
		List<Object[]> memberList = memberService.findByMaxMinAge();
		log.info("컨트롤러 findByMaxMinAge() 리턴 : {}",  memberList);
		model.addAttribute("list", memberList);
		return "member/list2";
	}
	
	@GetMapping(value = {"/findByMaxMinAge3"})
	public String findByMaxMinAge3(Model model) throws Exception {
		log.info("컨트롤러 findByMaxMinAge3() 호출");
		List<Object[]> memberList = memberService.findByMaxMinAge3();
		log.info("컨트롤러 findByMaxMinAge3() 리턴 : {}",  memberList);
		model.addAttribute("list", memberList);
		return "member/list2";
	}
	
}
