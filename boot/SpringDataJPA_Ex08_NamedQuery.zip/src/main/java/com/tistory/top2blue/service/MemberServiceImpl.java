package com.tistory.top2blue.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tistory.top2blue.repository.MemberRepository;
import com.tistory.top2blue.vo.Member;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service("memberService")
public class MemberServiceImpl implements MemberService {

	@Autowired
	private MemberRepository memberRepository;

	@Override
	public List<Member> findAll() {
		log.info("서비스 findAll() 호출");
		List<Member> list = new ArrayList<>();
		memberRepository.findAll().forEach(list::add);
		log.info("서비스 findAll() 리턴 : {}", list);
		return list;
	}

	@Override
	public List<Member> findByName2(String name) {
		log.info("서비스 findByName({}) 호출", name);
		List<Member> list = new ArrayList<>();
		memberRepository.findByName2(name).forEach(list::add);
		log.info("서비스 findByName({}) 리턴 : {}", name, list);
		return list;
	}
	
	@Override
	public List<Member> findByName3(String name) {
		log.info("서비스 findByName3({}) 호출", name);
		List<Member> list = new ArrayList<>();
		memberRepository.findByName3(name).forEach(list::add);
		log.info("서비스 findByName3({}) 리턴 : {}", name, list);
		return list;
	}

	@Override
	public List<Object[]> findByMaxMinAge() {
		log.info("서비스 findByMaxMinAge() 호출");
		List<Object[]> list = memberRepository.findByMaxMinAge();
		log.info("서비스 findByMaxMinAge() 리턴 : {}", list);
		return list;
	}

	@Override
	public List<Object[]> findByMaxMinAge3() {
		log.info("서비스 findByMaxMinAge2() 호출");
		List<Object[]> list = memberRepository.findByMaxMinAge3();
		log.info("서비스 findByMaxMinAge3() 리턴 : {}", list);
		return list;
	}

	@Override
	public List<Member> findByGenderAge(boolean gender, int age) {
		log.info("서비스 findByGenderAge({},{}) 호출", gender, age);
		List<Member> list = new ArrayList<>();
		memberRepository.findByGenderAge(gender, age).forEach(list::add);
		log.info("서비스 findByGenderAge({},{}) 리턴 : {}", gender, age, list);
		return list;
	}
}