package com.tistory.top2blue.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.tistory.top2blue.vo.Member;

/*


*/
public interface MemberRepository extends CrudRepository<Member, Long> {
	List<Member> findByName2(String name);

	@Query("select m from Member m where m.name = ?1")
	List<Member> findByName3(String name);
	
	@Query("select m from Member m where m.gender = ?1 or m.age<= ?2")
	List<Member> findByGenderAge(boolean gender, int age);
	
	List<Object[]> findByMaxMinAge();
	
	@Query("select Max(age), Min(age) from Member")
	List<Object[]> findByMaxMinAge3();
	
}
