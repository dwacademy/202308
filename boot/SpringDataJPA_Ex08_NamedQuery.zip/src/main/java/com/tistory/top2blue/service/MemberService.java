package com.tistory.top2blue.service;

import java.util.List;

import com.tistory.top2blue.vo.Member;

public interface MemberService {
	// 전체 얻기
	List<Member> findAll(); 

	List<Member> findByName2(String name);
	List<Member> findByName3(String name);
	
	List<Member> findByGenderAge(boolean gender, int age);
	
	List<Object[]> findByMaxMinAge();
	List<Object[]> findByMaxMinAge3();
}
