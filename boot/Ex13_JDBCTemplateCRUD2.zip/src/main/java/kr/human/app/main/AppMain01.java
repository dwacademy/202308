package kr.human.app.main;

import java.util.List;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import kr.human.app.config.AppConfig;
import kr.human.app.controller.PeopleController;
import kr.human.app.vo.PeopleVO;

public class AppMain01 {
	public static void main(String[] args) {
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
		
		PeopleController peopleController = context.getBean("peopleController", PeopleController.class);
		// 조회 
		print(peopleController);
		
		// 저장
		PeopleVO peopleVO = new PeopleVO(0, "저인간", 14);
		peopleController.insert(peopleVO);
		
		// 조회 
		print(peopleController);
		
		// 수정
		peopleVO.setIdx(peopleController.selectCount());
		peopleVO.setName("바뀐놈");
		peopleVO.setAge((int)(Math.random()*100) +1);
		peopleController.update(peopleVO);
		System.out.println(peopleController.selectByIdx(peopleController.selectCount()));
		
		// 조회 
		print(peopleController);
		
		
		// 삭제
		peopleVO.setIdx((int)(Math.random()*10) +1);
		if(peopleController.delete(peopleVO)) {
			System.out.println(peopleVO.getIdx() + "번 삭제 성공!!!");
		}else {
			System.out.println(peopleVO.getIdx() + "번 삭제 실패!!!");
		}
		
		// 조회 
		print(peopleController);

		context.close();
	}

	private static void print(PeopleController peopleController) {
		System.out.println("\n\n전체 개수 : " + peopleController.selectCount() + "명 있다!!!!");
		List<PeopleVO> list = peopleController.selectList();
		for(PeopleVO peopleVO : list) {
			System.out.print(peopleVO.getIdx() + ". ");
			System.out.print(peopleVO.getName() + "(");
			System.out.println(peopleVO.getAge() + "세)");
		}
		System.out.println("-".repeat(40));
	}
}
