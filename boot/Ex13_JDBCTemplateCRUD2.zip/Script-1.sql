CREATE TABLE people(
	idx int PRIMARY key auto_increment ,
	name varchar(100) NOT NULL,
	age int DEFAULT 0
);

SELECT * FROM people;

INSERT INTO people (name, age) VALUES ('한사람', 18);
INSERT INTO people (name, age) VALUES ('두사람', 22);
INSERT INTO people (name, age) VALUES ('세사람', 15);
INSERT INTO people (name, age) VALUES ('네사람', 27);
INSERT INTO people (name, age) VALUES ('오사람', 31);
INSERT INTO people (name, age) VALUES ('육사람', 33);

SELECT * FROM people;