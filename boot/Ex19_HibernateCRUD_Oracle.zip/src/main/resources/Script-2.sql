CREATE SEQUENCE student_idx_seq;

create table student(
	idx NUMBER PRIMARY KEY, 
	name VARCHAR(50) NOT NULL,
	section VARCHAR(50) NOT NULL
);