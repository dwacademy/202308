package kr.human.app.dao;

import java.util.List;

import kr.human.app.vo.StudentVO;

public interface StudentDAO {
	// 1. 저장
	void insert(StudentVO studentVO);
	// 2. 모두보기
	List<StudentVO> selectList();
	// 3. 수정
	void update(StudentVO studentVO);
	// 4. 삭제
	void delete(int idx);
	// 5. 1개얻기
	StudentVO selectByIdx(int idx);
}
