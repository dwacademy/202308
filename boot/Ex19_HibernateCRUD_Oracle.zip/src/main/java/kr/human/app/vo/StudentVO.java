package kr.human.app.vo;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity(name = "Student")
@Table(name="STUDENT")
public class StudentVO implements Serializable {

	@Id
	@Column(name="id")
	@GeneratedValue(generator = "generator", strategy = GenerationType.SEQUENCE)
	@SequenceGenerator(name = "generator", sequenceName = "student_id_seq", initialValue=1, allocationSize=1)
	private int id;
	
	@Column(name = "NAME", nullable = false)
	private String name;
	@Column(name = "SECTION", nullable = false)
	private String section;
}
