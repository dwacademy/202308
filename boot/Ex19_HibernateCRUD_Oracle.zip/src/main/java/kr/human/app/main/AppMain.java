package kr.human.app.main;

import java.util.List;
import java.util.Random;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import kr.human.app.service.StudentService;
import kr.human.app.vo.StudentVO;

public class AppMain {
	public static void main(String[] args) {
		AbstractApplicationContext context = new ClassPathXmlApplicationContext("appConfig.xml");
		
		StudentService service = context.getBean("studentService", StudentService.class);
		
		// 저장
		service.insert(new StudentVO(0, "한사람", "자바 프로그래머"));
		service.insert(new StudentVO(0, "두사람", "SQL 프로그래머"));
		service.insert(new StudentVO(0, "세사람", "자바 프로그래머"));
		
		// 읽기
		List<StudentVO> list = service.selectList();
		System.out.println("-".repeat(40));
		System.out.println(list.size() + "명!!!");
		for(StudentVO vo : list) {
			System.out.println(vo);
		}
		System.out.println("-".repeat(40));
		
		
		context.close();
	}
}
