package kr.human.mvc.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import kr.human.mvc.dao.TestDAO;

@Service("testService")
public class TestServiceImpl implements TestService{

	@Autowired
	private TestDAO testDAO;

	@Override
	public String selectTodayMaria() {
		return testDAO.selectTodayMaria();
	}

	@Override
	public String selectTodayOracle() {
		return testDAO.selectTodayOracle();
	}
}
