package kr.human.mvc.dao;

public interface TestDAO {
	String selectTodayMaria();
	String selectTodayOracle();
}
