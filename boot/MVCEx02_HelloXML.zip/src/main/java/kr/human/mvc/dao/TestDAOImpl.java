package kr.human.mvc.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
@Repository("testDAO")
public class TestDAOImpl implements TestDAO {
	@Autowired
	private JdbcTemplate jdbcTemplate1;
	@Autowired
	private JdbcTemplate jdbcTemplate2;
	
	@Override
	public String selectTodayMaria() {
		return jdbcTemplate1.queryForObject("select now()", String.class);
	}
	@Override
	public String selectTodayOracle() {
		return  jdbcTemplate2.queryForObject("select sysdate from dual", String.class);
	}
}
