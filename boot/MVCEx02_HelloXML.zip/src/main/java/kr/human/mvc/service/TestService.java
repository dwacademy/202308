package kr.human.mvc.service;

public interface TestService {
	String selectTodayMaria();
	String selectTodayOracle();
}
