package kr.human.app.main;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import kr.human.app.controller.TestController;

public class AppMain02 {
	public static void main(String[] args) {
		AbstractApplicationContext context = new ClassPathXmlApplicationContext("AppConfig.xml");
		
		TestController testController = context.getBean("testController", TestController.class);
		
		System.out.println("디비시간 : " + testController.selectToday());
		System.out.println("계산 : " + testController.selectTestVO(12, 34));
		
		context.close();
	}
}
