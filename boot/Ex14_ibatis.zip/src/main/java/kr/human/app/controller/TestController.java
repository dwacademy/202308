package kr.human.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import kr.human.app.service.TestService;
import kr.human.app.vo.TestVO;

@Controller("testController")
public class TestController {
	@Autowired
	private TestService testService;
	
	public String selectToday() {
		return testService.selectToday();
	}
	public TestVO selectTestVO(int num1, int num2) {
		return testService.selectTestVO(num1, num2);
	}
}
