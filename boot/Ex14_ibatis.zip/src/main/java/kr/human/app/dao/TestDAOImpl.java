package kr.human.app.dao;

import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ibatis.sqlmap.client.SqlMapClient;

import kr.human.app.vo.TestVO;

@Repository("testDAO")
public class TestDAOImpl implements TestDAO {
	
	@Autowired
	private SqlMapClient sqlMapClient;

	@Override
	public String selectToday()  throws SQLException{
		return (String) sqlMapClient.queryForObject("test.selectToday");
	}

	@Override
	public TestVO selectTestVO(TestVO testVO) throws SQLException {
		return (TestVO) sqlMapClient.queryForObject("test.selectTestVO", testVO);
	}

}
