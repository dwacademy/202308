package kr.human.app.service;

import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import kr.human.app.dao.TestDAO;
import kr.human.app.vo.TestVO;

@Service("testService")
public class TestServiceImpl implements TestService {
	@Autowired
	private TestDAO testDAO;
	@Override
	public String selectToday() {
		String today = "";
		try {
			today = testDAO.selectToday();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return today;
	}
	@Override
	public TestVO selectTestVO(int num1, int num2) {
		TestVO resultVO = null;
		try {
			TestVO testVO = new TestVO();
			testVO.setNum1(num1);
			testVO.setNum2(num2);
			resultVO = testDAO.selectTestVO(testVO);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return resultVO;
	}
	
	
}
