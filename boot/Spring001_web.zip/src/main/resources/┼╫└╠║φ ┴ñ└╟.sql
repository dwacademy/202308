-- 시퀀스를 만들자
CREATE SEQUENCE mymem_idx_seq;
-- 테이블을 만들자
CREATE TABLE mymem(
	idx NUMBER PRIMARY KEY,
	userid varchar2(100) NOT NULL,
	password varchar2(100) NOT NULL,
	username varchar2(100) NOT NULL,
	phone varchar2(20) NOT NULL,
	point NUMBER DEFAULT 100,
	regDate timestamp DEFAULT sysdate,
	lev varchar2(10) NOT null
);
-- 등록을 받지 않을 아이디는 기본적으로 저장해주면 좋다.
INSERT INTO mymem 
	(idx,userid,password,username,phone,lev)
VALUES
	(mymem_idx_seq.nextval,'admin','9999','최고관리자','010-1111-2222','admin');
	
SELECT * FROM mymem;