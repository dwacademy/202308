package com.human.web01.service;

import java.util.List;

import com.human.web01.vo.MyMemVO;

public interface MyMemService {
	// 1. 저장(회원가입)
	void insert(MyMemVO myMemVO);
	// 2. 모두 얻기(회원목록)
	List<MyMemVO> selectList();
	// 3. 1개 얻기(자세히보기)
	MyMemVO selectByIdx(int idx);
	// 4. 삭제
	void delete(MyMemVO myMemVO);
	// 5. 수정
	void update(MyMemVO myMemVO);
	// 6. 같은 아이디 개수 얻기(아이디 중복확인)
	int selectByUseridCount(String userid);
	
	// 7. idx와 비번을 받아 비번일치 여부를 확인해주는 메서드 
	boolean passwordCheck(int idx, String password); 
}
