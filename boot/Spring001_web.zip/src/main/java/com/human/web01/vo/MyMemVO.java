package com.human.web01.vo;

import java.util.Date;

import lombok.Data;

@Data
public class MyMemVO {
	private int 	idx;
	private String 	userid;
	private String 	password;
	private String 	username;
	private String 	phone;
	private int 	point;
	private Date 	regDate;
	private String 	lev;
}
