package com.human.web01;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.jdbc.core.JdbcTemplate;

import com.human.web01.dao.TestDAO;

@SpringBootApplication
public class Spring001WebApplication {

	// 1. DB 연동테스트 : 두개가 스프링에 자동으로 등록된다. 추가하고 실행시 에러가 나지 않으면 DB는 연결 성공
	//                    에러가 나면 application.properties파일의 datasource 설정이 잘못된것이다.
	@Autowired
	DataSource  dataSource;
	@Autowired
	JdbcTemplate jdbcTemplate;

	// 3. Mybatis연결을 해보자!!!
	//    1) 매퍼 하나를 만들고
	//    2) DAO인터페이스 만들고
	//    3) 연결 확인
	
	@Autowired
	private TestDAO testDAO;
	
	// 4. 네번째 테스트는 웹으로 확인해보자!!!
	//    1) 서비스 클래스 만들고
	//    2) 컨트롤러 만들고
	//    3) html(뷰)을 만들고
	//    4) localhost:8080에 접속해서 확인해보자!!!
	
	public static void main(String[] args) {
		SpringApplication.run(Spring001WebApplication.class, args);
	}

	// 2. SQL 명령이 실행되는지 테스트해보자. 다음의 코드를 추가해 본다.
	//    실행했을때 에러가 없이 콘솔창에 DB시간이 나오면 오라클은 정확하게 연결이 된것이다.
	@Bean // 애플리케이션이 실행될때 자동으로 실행되는 객체가 CommandLineRunner와 ApplicationRunner이다.
	CommandLineRunner getCommandLineRunner() {
		return (args)->{
			System.out.println("-".repeat(80));
			@SuppressWarnings("deprecation")
			String today = jdbcTemplate.queryForObject("select sysdate from dual",null, String.class);
			System.out.println("jdbcTemplate을 이용한 오라클 DB 시간 : " + today);
			// 위에 3번을 처리하고 마이바티스 연동 테스트
			System.out.println("Mybatis를 이용한 오라클 DB 시간 : " + testDAO.selectToday());
			System.out.println("-".repeat(80));
		};
	}
	
	
}
