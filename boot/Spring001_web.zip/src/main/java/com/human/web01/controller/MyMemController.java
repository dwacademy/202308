package com.human.web01.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.human.web01.service.MyMemService;
import com.human.web01.vo.MyMemVO;

@Controller
public class MyMemController {

	
	@Autowired
	MyMemService myMemService;
	
	
	@GetMapping(value = "/") // 메인화면
	public String index() {
		return "index";
	}
	
	@GetMapping(value = "/board") // 게시판 화면
	public String board() {
		return "board";
	}
	
	@GetMapping(value = "/list") // 회원 목록 화면
	public String list(Model model) {
		// html에서 출력할 내용들은 서비스를 호출하여 만들고 모델에 저장한다.
		List<MyMemVO> list = myMemService.selectList();
		model.addAttribute("list", list);
		return "list";
	}
	
	@GetMapping(value = "/deleteOk") // 삭제 완료!!!
	public String deleteOk(@ModelAttribute MyMemVO myMemVO) {
		myMemService.delete(myMemVO);
		return "redirect:/list";
	}
	
	@GetMapping(value = "/update") // 수정 폼으로!!!
	public String update(@ModelAttribute MyMemVO myMemVO, Model model) {
		if(myMemService.passwordCheck(myMemVO.getIdx(), myMemVO.getPassword())) { // 비번이 일치하면
			model.addAttribute("vo", myMemService.selectByIdx(myMemVO.getIdx())); // 글의 정보를 가지고 수정폼으로 간다.
			return "update";
		}else { // 비번이 틀리면 목록으로 가자!!!
			return "redirect:/list";
		}
	}
	
	@GetMapping(value = "/insertOk") // 직접 타이핑하면 리스트로 보내버린다.
	public String insertOkGet() {
		return "redirect:/list";
	}
	
	@PostMapping(value = "/insertOk") // 가입 완료!!!
	public String insertOkPOst(@ModelAttribute MyMemVO myMemVO) {
		myMemService.insert(myMemVO);
		return "redirect:/list";
	}
	
	@GetMapping(value = "/updateOk") // 수정완료를 직접 타이핑하면 리스트로 보내버린다.
	public String updateOkGet() {
		return "redirect:/list";
	}
	
	@PostMapping(value = "/updateOk") // 수정 완료!!!
	public String updateOkPOst(@ModelAttribute MyMemVO myMemVO) {
		myMemService.update(myMemVO);
		return "redirect:/list";
	}
	
	// 내용보기
	@GetMapping(value = "/view")
	public String view(@RequestParam(required = true, defaultValue = "0") int idx, Model model) {
		model.addAttribute("vo", myMemService.selectByIdx(idx)); // 글의 정보를 가지고 수정폼으로 간다.
		return "view";
	}

	// 회원 가입
	@GetMapping(value = "/join") 
	public String join() {
		return "join";
	}
	
	// 아이디 중복확인
	@GetMapping("/idCheck")
	@ResponseBody // 직접 출력해라!!!!
	public int idCheck(@RequestParam(required = true, defaultValue = "") String userid) {
		return myMemService.selectByUseridCount(userid);
	}
	
	
	
}
