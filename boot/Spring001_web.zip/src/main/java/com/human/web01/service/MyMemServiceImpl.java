package com.human.web01.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.human.web01.dao.MyMemDAO;
import com.human.web01.vo.MyMemVO;

import lombok.extern.slf4j.Slf4j;

@Service("myMemService")
@Slf4j
public class MyMemServiceImpl implements MyMemService{

	@Autowired
	private MyMemDAO myMemDAO;

	@Override
	public void insert(MyMemVO myMemVO) {
		try {
			if(myMemVO!=null) {
				// 3번 조건
				if(myMemVO.getLev().equalsIgnoreCase("vip")) {
					myMemVO.setPoint(1000);
				}else {
					myMemVO.setPoint(100);
				}
				// 각각의 값에 대한 모든 휴효성 검사를 추가한다.
				// 실제 DB에 저장한다.
				myMemDAO.insert(myMemVO);
				log.info("{} 저장 성공!!!", myMemVO);
			}
		}catch (Exception e) {
			log.info("{} 저장 실패!!!", myMemVO);
			e.printStackTrace();
		}
	}

	@Override
	public List<MyMemVO> selectList() {
		List<MyMemVO> list = null;
		try {
			list = myMemDAO.selectAll();
			log.info("모두 얻기 성공 : {}", list);
		}catch (Exception e) {
			log.info("모두 얻기 실패!!!");
			e.printStackTrace();
		}
		return list;
	}

	@Override
	public MyMemVO selectByIdx(int idx) {
		MyMemVO vo = null;
		try {
			vo = myMemDAO.selectByIdx(idx);
			log.info("1개 얻기 성공 : {}", vo);
		}catch (Exception e) {
			log.info("1개 얻기 실패!!!");
			e.printStackTrace();
		}
		return vo;
	}

	@Override
	public void delete(MyMemVO myMemVO) {
		try {
			if(myMemVO!=null) {
				// DB에 있는자료와 비번이 같을때만 삭제
				MyMemVO dbVO = myMemDAO.selectByIdx(myMemVO.getIdx());
				if(dbVO!=null && dbVO.getPassword().equals(myMemVO.getPassword())) {
					// 실제 DB에 삭제한다.
					myMemDAO.delete(myMemVO.getIdx());
					log.info("{} 삭제 성공!!!", myMemVO);
				}
			}
		}catch (Exception e) {
			log.info("{} 삭제 실패!!!", myMemVO);
			e.printStackTrace();
		}
	}

	@Override
	public void update(MyMemVO myMemVO) {
		try {
			if(myMemVO!=null) {
				// DB에 있는자료와 비번이 같을때만 수정
				MyMemVO dbVO = myMemDAO.selectByIdx(myMemVO.getIdx());
				if(dbVO!=null && dbVO.getPassword().equals(myMemVO.getPassword())) {
					// 실제 DB에 수정한다.
					myMemDAO.update(myMemVO);
					log.info("{} 수정 성공!!!", myMemVO);
				}
			}
		}catch (Exception e) {
			log.info("{} 수정 실패!!!", myMemVO);
			e.printStackTrace();
		}
	}

	@Override
	public int selectByUseridCount(String userid) {
		int count = 0;
		try {
			count = myMemDAO.selectByUseridCount(userid);
			log.info("id개수  얻기 성공 : {}", count);
		}catch (Exception e) {
			log.info("id개수  얻기 실패!!!");
			e.printStackTrace();
		}
		return count;
	}

	@Override
	public boolean passwordCheck(int idx, String password) {
		boolean isCheck = false;
		try {
			// DB에 있는자료와 비번이 같을때만 수정
			MyMemVO dbVO = myMemDAO.selectByIdx(idx);
			if(dbVO!=null && dbVO.getPassword().equals(password)) {
				isCheck = true;
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return isCheck;
	}
}
