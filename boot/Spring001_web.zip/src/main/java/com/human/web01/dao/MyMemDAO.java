package com.human.web01.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.human.web01.vo.MyMemVO;

@Mapper
public interface MyMemDAO {
	void insert(MyMemVO myMemVO); //  1. 가입 
	List<MyMemVO> selectAll(); // 2. 전체보기
	MyMemVO selectByIdx(int idx); // 3. 자세히보기
	void update(MyMemVO myMemVO); //  4. 수정 
	void delete(int idx); //  5. 삭제
	int selectByUseridCount(String userid); // 6. 아이디 중복확인
}
