package com.human.web01.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.human.web01.service.TestService;

@Controller
public class TestController {

	@Autowired
	private TestService testService;
	
	@GetMapping(value = {"/today"})
	public String home(Model model) {
		// 화면에 출력하고 싶은 내용은 모두 모델에 저장한다.
		model.addAttribute("today", testService.selectToday());
		
		// 뷰페이지로 포워딩한다.
		return "test"; // classpath:/templates/ + 리턴값 + ".html"로 포워딩
	}
}
