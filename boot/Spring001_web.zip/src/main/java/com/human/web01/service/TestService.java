package com.human.web01.service;

public interface TestService {
	String selectToday();
}
