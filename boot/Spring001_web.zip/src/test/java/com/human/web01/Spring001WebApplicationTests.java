package com.human.web01;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.human.web01.service.MyMemService;
import com.human.web01.vo.MyMemVO;

@SpringBootTest
class Spring001WebApplicationTests {

	@Autowired
	private MyMemService myMemService;
	
	@Test
	void contextLoads() {
		assertNotNull(myMemService.selectList());
	}
	/*
	@Test
	void insertNull() {
		myMemService.insert(null);
		assertTrue(true);
	}
	
	@Test
	void insertVO() {
		MyMemVO vo = new MyMemVO();
		vo.setUserid("root");
		vo.setPassword("123456");
		vo.setUsername("관리자");
		vo.setPhone("010-2222-2222");
		vo.setLev("vip");
		myMemService.insert(vo);
		assertTrue(true);
	}
	*/
}
