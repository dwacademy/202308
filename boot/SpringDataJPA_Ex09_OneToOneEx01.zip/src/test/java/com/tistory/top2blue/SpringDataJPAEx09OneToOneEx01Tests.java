package com.tistory.top2blue;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.tistory.top2blue.repository.AddressRepository;
import com.tistory.top2blue.repository.PersonRepository;

@SpringBootTest
class SpringDataJPAEx09OneToOneEx01Tests {

	@Autowired
    private PersonRepository personRepository;
	@Autowired
    private AddressRepository addressRepository;

	@Test
	public void test() {
		System.out.println(personRepository.count());
		System.out.println(addressRepository.count());
	}
}
