package com.tistory.top2blue.repository;

import org.springframework.data.repository.CrudRepository;

import com.tistory.top2blue.vo.Person;

public interface PersonRepository extends CrudRepository<Person,Long> {
	
}