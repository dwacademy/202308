package com.tistory.top2blue.vo;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder
@Entity
@Table(name = "addresses")
public class Address {
	// 서로 상호 참조를 하므로 양쪽에 ToString을 만들면 자기 참조 순환에 거려 에러이다.
	// 기본생성자와 모든 매개변수를 받는 생성자를 만들어 주어야 한다.
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String street;
    private String city;
    private String state;
    private String zipCode;
    private String country;
    @OneToOne(mappedBy = "address")
    private Person person;
    
    public Address() {
    	
    }

	public Address(Long id, String street, String city, String state, String zipCode, String country, Person person) {
		super();
		this.id = id;
		this.street = street;
		this.city = city;
		this.state = state;
		this.zipCode = zipCode;
		this.country = country;
		this.person = person;
	}
    
    
}