package com.tistory.top2blue;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringDataJPAEx09OneToOneEx01 {

	public static void main(String[] args) {
		SpringApplication.run(SpringDataJPAEx09OneToOneEx01.class, args);
	}
	
	
}
