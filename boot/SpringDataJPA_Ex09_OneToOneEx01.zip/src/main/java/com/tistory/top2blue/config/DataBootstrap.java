package com.tistory.top2blue.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.tistory.top2blue.repository.AddressRepository;
import com.tistory.top2blue.repository.PersonRepository;
import com.tistory.top2blue.vo.Address;
import com.tistory.top2blue.vo.Person;

import jakarta.transaction.Transactional;

@Component
public class DataBootstrap implements CommandLineRunner {

	
	@Autowired
    private PersonRepository personRepository;
	@Autowired
    private AddressRepository addressRepository;

     @Transactional
     public void run(String... args) throws Exception {
        Person person = Person.builder()
                .name("Martin")
                .email("martin.page@example.com")
                .password("1234abcd")
                .build();

        Address address = Address.builder()
                .street("Lake victoria")
                .city("Berlin")
                .state("Berlin")
                .country("Germany")
                .zipCode("10115")
                .build();

        address.setPerson(person);
        person.setAddress(address);
        addressRepository.save(address);
        personRepository.save(person);
    }
}