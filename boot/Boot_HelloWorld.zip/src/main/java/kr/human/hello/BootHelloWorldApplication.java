package kr.human.hello;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
@RestController // 이 클래스를 RestController로 사용하겠다.
public class BootHelloWorldApplication {

	public static void main(String[] args) {
		SpringApplication.run(BootHelloWorldApplication.class, args);
	}

	// 웹상에 주소 하나 생성한다. GET방식의 요청에 응답하는 주소!!!
	@GetMapping(value = "/")
	public String hello() {
		return "Hello Spring Boot Application!!!! 한글도 될까?"; 
	}
	// 하나의 메서드로 주소를 여러개 생성한다. 배열로 주소 지정
	@GetMapping(value = {"/hello","/hi","/babo/hello"})
	public String hello2(@RequestParam(required = false) String name) {
		if(name==null || name.trim().length()==0) name="손";
		return name + "님 반가워요~~~~"; 
	}
	
	@RequestMapping(value = "/vo")
	public TestVO testVO() {
		return new TestVO("한사람", 23, false);
	}
}
