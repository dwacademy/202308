package kr.human.boot.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import kr.human.boot.dao.StudentDAO;
import kr.human.boot.vo.Student;

@Service
public class StudentService {
	@Autowired
	private StudentDAO studentDAO;
	
	// 모두 얻기 : 번호순
	public List<Student> selectAll(){
		List<Student> list = new ArrayList<>();
		studentDAO.findAll().forEach(list::add);
		return list;
	}
	
	// 모두 얻기 : 번호 역순
	public List<Student> selectAllOrderByIdxDesc(){
		List<Student> list = new ArrayList<>();
		studentDAO.findAllByOrderByIdxDesc().forEach(list::add);
		return list;
	}
	// 모두 얻기 : 이름 오름차순
	public List<Student> selectAllOrderByLastName(){
		List<Student> list = new ArrayList<>();
		studentDAO.findAllByOrderByLastName().forEach(list::add);
		return list;
	}
	// 모두 얻기 : 이름 내림차순
	public List<Student> selectAllOrderByLastNameDesc(){
		List<Student> list = new ArrayList<>();
		studentDAO.findAllByOrderByLastNameDesc().forEach(list::add);
		return list;
	}
	// 모두 얻기 : Section 오름차순
	public List<Student> selectAllOrderBySection(){
		List<Student> list = new ArrayList<>();
		studentDAO.findAllByOrderBySection().forEach(list::add);
		return list;
	}
	// 모두 얻기 : Section 오름차순
	public List<Student> selectAllOrderBySectionDesc(){
		List<Student> list = new ArrayList<>();
		studentDAO.findAllByOrderBySectionDesc().forEach(list::add);
		return list;
	}
	
	// 1개 얻기
	public Optional<Student> selectByIdx(int idx){
		return studentDAO.findById(idx);
	}
	
	// 1개 저장하기
	public Student insert(Student student) {
		return studentDAO.save(student);
	}
	// 여러개 저장하기
	public void insert(List<Student> students) {
		studentDAO.saveAll(students);
	}
	
	// 수정하기
	public Student update(Student student) {
		Optional<Student> vo = studentDAO.findById(student.getIdx());
		if(!vo.isPresent()) {
			return null;
		}
		Student student2 = vo.get();
		student2.setFirstName(student.getFirstName());
		student2.setLastName(student.getLastName());
		student2.setSection(student.getSection());
		return studentDAO.save(student2);
	}
	// 1개 삭제하기
	public Student delete(Student student) {
		Optional<Student> vo = studentDAO.findById(student.getIdx());
		if(!vo.isPresent()) {
			return null;
		}
		Student student2 = vo.get();
		studentDAO.delete(student2);
		return student2;
	}
	// 여러개 삭제하기
	public void delete(List<Student> students) {
		studentDAO.deleteAll(students);
	}
}
