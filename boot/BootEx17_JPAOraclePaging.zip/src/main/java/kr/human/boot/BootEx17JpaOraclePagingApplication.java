package kr.human.boot;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootEx17JpaOraclePagingApplication implements CommandLineRunner{

	public static void main(String[] args) {
		SpringApplication.run(BootEx17JpaOraclePagingApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		System.out.println("-".repeat(80));
		System.out.println("http://localhost:8080 으로 접속해주세요");
		System.out.println("-".repeat(80));		
	}
}
