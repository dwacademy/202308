package kr.human.boot.controller;

import java.util.Arrays;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import kr.human.boot.service.StudentPagingService;
import kr.human.boot.vo.PagingVO;
import kr.human.boot.vo.Student;

@Controller
public class StudentPagingController {
	
	@Autowired
	private StudentPagingService studentPagingService;
	
	@GetMapping(value = "/insertAll")
	public String insertAll() {
		Random rnd = new Random();
		
		Student student1 = new Student("성"+ String.format("%05d", rnd.nextInt(10000)), "이름"+ String.format("%05d", rnd.nextInt(10000)), "언어"+ String.format("%05d", rnd.nextInt(10000)));
		Student student2 = new Student("성"+ String.format("%05d", rnd.nextInt(10000)), "이름"+ String.format("%05d", rnd.nextInt(10000)), "언어"+ String.format("%05d", rnd.nextInt(10000)));
		Student student3 = new Student("성"+ String.format("%05d", rnd.nextInt(10000)), "이름"+ String.format("%05d", rnd.nextInt(10000)), "언어"+ String.format("%05d", rnd.nextInt(10000)));
	
		studentPagingService.saveAll(Arrays.asList(student1,student2,student3));
		return "redirect:/pagingList1";
	}
	
	@GetMapping(value = "/pagingList1")
	public String list1(Model model) {
		model.addAttribute("list", studentPagingService.selectAll());
		return "pagingList1";
	}

	// 페이징 계산을 JPA에 있는 클래스(Page<T>)에 맡겼다....
	// 페이징된 내용을 얻어보자!!!
	@GetMapping(value = "/pagingList2")
	public String list2(
			@RequestParam(required = false, defaultValue = "1") int pageNo,
			@RequestParam(required = false, defaultValue = "10") int pageSize,
			@RequestParam(required = false, defaultValue = "10") int blockSize,
			Model model) {
		Page<Student> page = studentPagingService.selectList1(pageNo, pageSize, blockSize);
		model.addAttribute("page", page);
		int startPage = (pageNo-1)/blockSize * blockSize + 1;
		int endPage = startPage + blockSize -1;
		if(endPage>page.getTotalPages()) endPage = page.getTotalPages();
		model.addAttribute("startPage", startPage);
		model.addAttribute("endPage", endPage);
		model.addAttribute("blockSize", blockSize);
		return "pagingList2";
	}
	// 페이징 계산을 PagingVO를 사용해보자
	// 페이징된 내용을 얻어보자!!!
	@GetMapping(value = "/pagingList3")
	public String list3(
			@RequestParam(required = false, defaultValue = "1") int p,
			@RequestParam(required = false, defaultValue = "10") int s,
			@RequestParam(required = false, defaultValue = "10") int b,
			Model model) {
		PagingVO<Student> pv = studentPagingService.selectList2(p, s, b,"idx","desc");
		model.addAttribute("pv", pv);
		return "pagingList3";
	}
}
