package kr.human.boot.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import kr.human.boot.service.StudentService;

@Controller
public class StudentController {
	
	@Autowired
	private StudentService studentService;
	
	@GetMapping(value = "/list1")
	public String list1(Model model) {
		model.addAttribute("list", studentService.selectAll());
		return "list1";
	}
	@GetMapping(value = "/list2")
	public String list2(Model model) {
		model.addAttribute("list", studentService.selectAllOrderByIdxDesc());
		return "list1";
	}
	@GetMapping(value = "/list3")
	public String list3(Model model) {
		model.addAttribute("list", studentService.selectAllOrderByLastName());
		return "list1";
	}
	@GetMapping(value = "/list4")
	public String list4(Model model) {
		model.addAttribute("list", studentService.selectAllOrderByLastNameDesc());
		return "list1";
	}
	@GetMapping(value = "/list5")
	public String list5(Model model) {
		model.addAttribute("list", studentService.selectAllOrderBySection());
		return "list1";
	}
	@GetMapping(value = "/list6")
	public String list6(Model model) {
		model.addAttribute("list", studentService.selectAllOrderBySectionDesc());
		return "list1";
	}
}
