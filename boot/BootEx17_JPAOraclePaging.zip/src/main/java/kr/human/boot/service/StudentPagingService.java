package kr.human.boot.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import kr.human.boot.dao.StudentPagingDAO;
import kr.human.boot.vo.PagingVO;
import kr.human.boot.vo.Student;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class StudentPagingService {

	@Autowired
	StudentPagingDAO studentPagingDAO;

	public void saveAll(List<Student> list) {
		studentPagingDAO.saveAll(list);
	}

	// 모두 얻기 : 번호순
	public List<Student> selectAll() {
		List<Student> list = new ArrayList<>();
		studentPagingDAO.findAll().forEach(list::add);
		return list;
	}

	// Page <T> findAll(Pageable pageable); - 해당 유형의 해당 페이지의 Page 인스턴스를 반환합니다.
	public Page<Student> selectList1(int pageNo, int pageSize, int blockSize) {
		// Pageable pageable = PageRequest.of(pageNo-1, pageSize);
		// Page<Person> page = personRepository.findAll(pageable);
		// return page;
		// 위의 두줄을 1줄로 줄이면
		// return personRepository.findAll(PageRequest.of(pageNo-1, pageSize)); // 오름차순
		return studentPagingDAO.findAll(PageRequest.of(pageNo-1, pageSize, Sort.by("idx").descending())); // 역순
	}
	
	// Page <T> findAll(Pageable pageable); - 해당 유형의 해당 페이지의 Page 인스턴스를 반환합니다.
	public PagingVO<Student> selectList2(int pageNo, int pageSize, int blockSize, String sortBy, String sortDir) {
		PagingVO<Student> pv = new PagingVO<>((int) studentPagingDAO.count(), pageNo, pageSize, blockSize);
		Sort sort = sortDir.equalsIgnoreCase(Sort.Direction.ASC.name()) ? Sort.by(sortBy).ascending() : Sort.by(sortBy).descending();
		Pageable pageable = PageRequest.of(pageNo - 1, pageSize, sort);
		Page<Student> page = studentPagingDAO.findAll(pageable);
		pv.setList(page.getContent());
		log.info("결과 : {}", pv);;
		return pv;
	}	
}
