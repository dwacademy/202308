package kr.human.boot.dao;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import kr.human.boot.vo.Student;

public interface StudentDAO extends CrudRepository<Student, Integer>{
	List<Student> findAllByOrderByIdxDesc();
	List<Student> findAllByOrderByLastName();
	List<Student> findAllByOrderByLastNameDesc();
	List<Student> findAllByOrderBySection();
	List<Student> findAllByOrderBySectionDesc();
}
