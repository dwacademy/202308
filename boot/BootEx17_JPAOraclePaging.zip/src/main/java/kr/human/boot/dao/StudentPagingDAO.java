package kr.human.boot.dao;

import org.springframework.data.repository.ListCrudRepository;
import org.springframework.data.repository.PagingAndSortingRepository;

import kr.human.boot.vo.Student;

public interface StudentPagingDAO extends 
	PagingAndSortingRepository<Student, Long>, ListCrudRepository<Student, Long> {

}
