package kr.human.rest;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HomeController {

	@GetMapping(value = "/")
	public String index(Model model) {
		String serverTime = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy년 MM월 dd일(EEEE) hh:mm:ss"));
		model.addAttribute("serverTime", serverTime);
		return "index";
	}
}
