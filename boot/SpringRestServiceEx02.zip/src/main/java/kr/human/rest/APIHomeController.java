package kr.human.rest;

import java.nio.charset.Charset;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class APIHomeController {

	@GetMapping(value = {"/","/today"})
	public String index(Model model) {
		return LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy년 MM월 dd일(EEEE) hh:mm:ss"));
	}
	
	@PostMapping("/user1") // @RequestBody로 받기
	public UserVO putUser1(@RequestBody UserVO userVO) {
		System.out.println("받은값 : " + userVO);
		return userVO;
	}
	
	@PostMapping("/user2") // @ModelAttribute로 받기
	public UserVO putUser2(@ModelAttribute UserVO userVO) {
		System.out.println("받은값 : " + userVO);
		return userVO;
	}
	
	/*
	ResponseEntity란, httpentity를 상속받는, 결과 데이터와 HTTP 상태 코드를 직접 제어할 수 있는 클래스이다.
	ResponseEntity에는 사용자의  HttpRequest에 대한 응답 데이터가 포함된다.
	
	ReponseEntity 구조
	ResponseEntity는 HttpEntity를 상속받고 사용자의 응답 데이터가 포함된 클래스이기 때문에 HttpStatus, HttpHeaders, HttpBody를  포함한다.
	
	response header form
	: 웹브라우저가 요청한 메시지에 대해서 status 즉 성공했는지 여부(202, 400 등), 메시지,
	  그리고 요청한 응답 값들이 body에 담겨있다.
	Location : 301, 302 상태코드일 떄만 볼 수 있는 헤더로 서버의 응답이 다른 곳에 있다고 알려주면서 해당 위치(URI)를 지정한다.
	Server : 웹서버의 종류 ex) nginx
	Age : max-age 시간내에서 얼마나 흘렀는지 초 단위로 알려주는 값
	Referrer-policy : 서버 referrer 정책을 알려주는 값 ex) origin, no-referrer, unsafe-url
	WWW-Authenticate : 사용자 인증이 필요한 자원을 요구할 시, 서버가 제공하는 인증 방식
	Proxy-Authenticate : 요청한 서버가 프록시 서버인 경우 유저 인증을 위한 값	
	
	결론은 ResponseEntity 클래스를 사용하면, 
	결과값! 상태코드! 헤더값!을 모두 프론트에 넘겨줄 수 있고, 
	에러코드 또한 섬세하게 설정해서 보내줄 수 있다는 장점이 있다!
	 */
	@GetMapping("/entity")
	public ResponseEntity<UserVO> getEntity(){
		UserVO userVO = new UserVO(1,"세사람",17,true);
		
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(new MediaType("application", "json", Charset.forName("UTF-8")));

		return new ResponseEntity<UserVO>(userVO, headers, HttpStatus.OK);
	}
	
	@GetMapping(value = "/xml", produces = {MediaType.APPLICATION_XML_VALUE})
	public UserVO getXML(){
		return new UserVO(1,"세사람",17,true);
	}
	
}
