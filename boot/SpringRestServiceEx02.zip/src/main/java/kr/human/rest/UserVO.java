package kr.human.rest;

import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@JacksonXmlRootElement(localName = "Person")
@JsonPropertyOrder({"idx", "name", "age", "gender"})
@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserVO {
	private int idx;
	private String name;
	private int age;
	private boolean gender;
}

