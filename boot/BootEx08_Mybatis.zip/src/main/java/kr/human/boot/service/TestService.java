package kr.human.boot.service;

import java.util.Date;
import kr.human.boot.vo.TestVO;

public interface TestService {
	String selectToday1();
	Date   selectToday2();
	TestVO selectToday3();
}
