package kr.human.boot.service;

import kr.human.boot.vo.MemoVO;
import kr.human.boot.vo.PagingVO;

public interface MemoService {
	// 목록보기
	PagingVO<MemoVO> selectList(int currentPage, int sizeOfPage, int sizeOfBlock);
	// 1개 얻기
	MemoVO selectByIdx(int idx);
	// 저장
	void insert(MemoVO memoVO);
	// 수정
	void update(MemoVO memoVO);
	// 삭제
	void delete(MemoVO memoVO);
}
