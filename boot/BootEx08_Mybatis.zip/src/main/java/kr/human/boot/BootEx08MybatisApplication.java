package kr.human.boot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootEx08MybatisApplication {

	public static void main(String[] args) {
		SpringApplication.run(BootEx08MybatisApplication.class, args);
	}

}
