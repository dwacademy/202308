package kr.human.mvc.controller;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import kr.human.mvc.service.DataService;
import kr.human.mvc.vo.Response;

@Controller
public class MyController {

	@Autowired
	private DataService dataService;
	
	
	@RequestMapping(value = "/")
	public String home(@RequestParam(required = false, defaultValue = "1") int pageNo, 
			           @RequestParam(required = false, defaultValue = "10") int numOfRows, 
			           Model model) {
		model.addAttribute("today",
				LocalDateTime.now().format(DateTimeFormatter.ofPattern("yy년 MM월 dd일(E) hh:mm:ss.S")));
		
		// int pageNo=1;
		// int numOfRows = 10;
		Response response = dataService.getData(pageNo, numOfRows);
		model.addAttribute("data", response.getBody().getItem());
		int totalPage = response.getBody().getTotalCount()/numOfRows + 1;
		model.addAttribute("pageNo", pageNo);
		model.addAttribute("numOfRows", numOfRows);
		model.addAttribute("totalPage", totalPage);
		
		return "index";
	}
	
	@RequestMapping(value = "/list")
	public String selectList(@RequestParam(required = false, defaultValue = "1") int pageNo,Model model) {
		dataService.insert(pageNo);
		model.addAttribute("list", dataService.selectList());
		return "list";
	}
}
