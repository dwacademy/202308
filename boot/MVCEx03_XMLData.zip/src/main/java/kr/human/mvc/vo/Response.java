package kr.human.mvc.vo;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;

import lombok.Data;

@Data
@XmlRootElement
public class Response {
	private Header header;
	private Body   body;
	@Data
	@XmlRootElement
	public static class Header{
		private int resultCode;
		private int resultCount;
	}
	@Data
	@XmlRootElement
	@XmlAccessorType(XmlAccessType.FIELD)
	public static class Body{
		@XmlElement
		private int totalCount;
		@XmlElement
		private int pageNo;
		@XmlElement
		@XmlElementWrapper(name="items")
		private List<Item> item;
	}
	@Data
	@XmlRootElement
	public static class Item{
		private String middleCategory;
		private int articleNo;
		private String answer;
		private String mainCategory;
		private String question;
		private String smallCategory;
	}
}
