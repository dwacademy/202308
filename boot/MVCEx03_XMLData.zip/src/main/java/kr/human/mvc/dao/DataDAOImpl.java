package kr.human.mvc.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import kr.human.mvc.vo.ItemRowMapper;
import kr.human.mvc.vo.Response.Item;

@Repository("dataDAO")
public class DataDAOImpl implements DataDAO{
	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public void insert(Item item) {
		String sql = "insert into lawfirm values (lawfirm_idx_seq.nextval,?,?,?,?,?,?)";
		Object[] params = {item.getMiddleCategory(), item.getArticleNo(),
				item.getAnswer(), item.getMainCategory(), item.getQuestion(),
				item.getSmallCategory()};
		jdbcTemplate.update(sql, params);
	}

	@Override
	public List<Item> selectList() {
		return jdbcTemplate.query("select * from lawfirm", new ItemRowMapper());
	}
}
