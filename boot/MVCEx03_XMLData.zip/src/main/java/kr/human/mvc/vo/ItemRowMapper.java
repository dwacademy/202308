package kr.human.mvc.vo;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import kr.human.mvc.vo.Response.Item;

public class ItemRowMapper implements RowMapper<Response.Item> {

	@Override
	public Item mapRow(ResultSet rs, int rowNum) throws SQLException {
		Response.Item item = new Response.Item();
		item.setAnswer(rs.getString("answer"));
		item.setArticleNo(rs.getInt("articleNo"));
		item.setMainCategory(rs.getString("mainCategory"));
		item.setMiddleCategory(rs.getString("middleCategory"));
		item.setSmallCategory(rs.getString("smallCategory"));
		item.setQuestion(rs.getString("question"));
		return item;
	}

}
