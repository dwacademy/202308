package kr.human.mvc.service;

import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import kr.human.mvc.dao.DataDAO;
import kr.human.mvc.vo.Response;
import kr.human.mvc.vo.Response.Item;
import lombok.extern.log4j.Log4j2;

@Service("dataService")
@Log4j2
public class DataServiceImpl implements DataService{

	@Autowired
	private DataDAO dataDAO;
	
	@Override
	public Response getData(int pageNo, int numOfRows) {
		Response response = null;
		JAXBContext context = null;
		try {
			StringBuilder urlBuilder = new StringBuilder("http://apis.data.go.kr/1270000/lawedu/lawqna"); /* URL */
			urlBuilder.append("?" + URLEncoder.encode("serviceKey", "UTF-8")
					+ "=F%2B1WwrjG0auR%2B6dWJkBs9kAAi6e%2B2CLUFFH56JH0E02yiVuZX6L3mXomYEiRrETRaIoL7NPKnyvnLCh6DAfDGQ%3D%3D");
			urlBuilder
			.append("&" + URLEncoder.encode("pageNo", "UTF-8") + "=" + URLEncoder.encode(pageNo+"", "UTF-8")); /* 페이지번호 */
			urlBuilder.append("&" + URLEncoder.encode("numOfRows", "UTF-8") + "="
					+ URLEncoder.encode(numOfRows+"", "UTF-8")); /* 한 페이지 결과 수 */
			
			URL url = new URL(urlBuilder.toString());
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setRequestMethod("GET");
			conn.setRequestProperty("Content-type", "application/xml");

			context = JAXBContext.newInstance(Response.class);
			Unmarshaller um = context.createUnmarshaller();
			response = (Response) um.unmarshal(new InputStreamReader(conn.getInputStream()));
			log.info("읽은값 : " + response);
			
			conn.disconnect();
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (JAXBException e) {
			e.printStackTrace();
		} 
		return response;
	}

	@Override
	public void insert(int pageNo) {
		Response response = getData(pageNo, 10);
		for(Response.Item item : response.getBody().getItem()) {
			dataDAO.insert(item);
		}
	}

	@Override
	public List<Item> selectList() {
		return dataDAO.selectList();
	}

}
