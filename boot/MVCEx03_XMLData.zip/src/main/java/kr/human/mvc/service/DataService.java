package kr.human.mvc.service;

import java.util.List;

import kr.human.mvc.vo.Response;

public interface DataService {
	Response getData(int pageNo, int numOfRows);
	void insert(int pageNo);
	List<Response.Item> selectList();
}
