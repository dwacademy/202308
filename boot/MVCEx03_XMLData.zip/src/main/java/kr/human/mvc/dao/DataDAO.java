package kr.human.mvc.dao;

import java.util.List;

import kr.human.mvc.vo.Response;

public interface DataDAO {
	void insert(Response.Item item);
	List<Response.Item> selectList();
}
