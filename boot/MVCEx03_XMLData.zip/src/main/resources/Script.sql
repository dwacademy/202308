CREATE SEQUENCE lawfirm_idx_seq;

CREATE TABLE lawfirm(
	idx NUMBER PRIMARY KEY,
	middleCategory varchar2(1000),
	articleNo NUMBER ,
	answer varchar2(1000),
	mainCategory varchar2(1000),
	question varchar2(1000),
	smallCategory varchar2(1000)
);