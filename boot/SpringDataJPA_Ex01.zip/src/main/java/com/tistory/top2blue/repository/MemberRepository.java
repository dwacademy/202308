package com.tistory.top2blue.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.tistory.top2blue.vo.Member;

/*
스프링 데이터 Jpa CrudRepository

CrudRepository interface는 기본 Repository인터페이스를 확장하고 
엔터티 클래스에 대한 모든 기본 CRUD 작업에 대한 메서드를 제공합니다.

save
findById
existsById
findAll
findAllById
deleteById
delete
deleteAll
deleteAll

*/
public interface MemberRepository extends JpaRepository<Member, Long> {

}
