package com.tistory.top2blue.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.tistory.top2blue.service.MemberService;
import com.tistory.top2blue.vo.Member;

import lombok.extern.slf4j.Slf4j;

@Controller
@Slf4j
@RequestMapping(value = "/members")
public class PersonController {
	@Autowired
	private MemberService memberService;
	
	@GetMapping(value = {"/","/list"})
	public String home(Model model) throws Exception {
		log.info("회원 목록보기");
		List<Member> memberList = memberService.getMemberList();
		log.info("회원 목록 : {}", memberList);
		model.addAttribute("list", memberList);
		return "member/list";
	}
}
