package com.tistory.top2blue;

import java.util.Arrays;
import java.util.List;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.tistory.top2blue.repository.MemberRepository;
import com.tistory.top2blue.vo.Member;

@SpringBootApplication
public class SpringDataJpaEx01Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringDataJpaEx01Application.class, args);
	}

	@Bean 
	CommandLineRunner commandLineRunner(MemberRepository repository) {
		return (args) -> {
			System.out.println("=".repeat(80));
			System.out.println("Spring Boot Application이 시작될때 자동으로 실행됩니다.");
			System.out.println("-".repeat(80));
			List<Member> list = Arrays.asList(
					new Member("admin","admin","한사람", 22, false),
					new Member("root","root","두사람", 37, true),
					new Member("user1","user1","세사람", 33, false),
					new Member("user2","user2","네사람", 21, true),
					new Member("user3","user3","오사람", 18, false)
					);
			repository.saveAll(list);
			System.out.println("=".repeat(80));
		};
	}
}
