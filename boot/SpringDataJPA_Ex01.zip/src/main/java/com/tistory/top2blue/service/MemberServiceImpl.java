package com.tistory.top2blue.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tistory.top2blue.repository.MemberRepository;
import com.tistory.top2blue.vo.Member;

import lombok.extern.slf4j.Slf4j;


//@SuppressWarnings({ "unchecked", "rawtypes" })
@Slf4j
@Service("memberService")
public class MemberServiceImpl implements MemberService {

	@Autowired
	private MemberRepository memberRepository;

	@Override
	public List<Member> getMemberList() {
		log.info("서비스 personList() 호출");
		List<Member> list = new ArrayList<>();
		/*
		try {
			Iterable<Member> it = memberRepository.findAll();
			for (Member vo : it) 
				list.add(vo);
		} catch (Exception e) {
			e.printStackTrace();
		}
		*/
		memberRepository.findAll().forEach(list::add);
		log.info("서비스 personList() 리턴 : {}", list);
		return list;
	}
}
