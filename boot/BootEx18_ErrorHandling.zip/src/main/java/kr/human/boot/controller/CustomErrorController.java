package kr.human.boot.controller;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import org.springframework.boot.web.servlet.error.ErrorController;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import jakarta.servlet.http.HttpServletRequest;

// 사용자가 에러 컨트롤러를 만들어 두면 이대로 작동한다.
// ErrorController인터페이스를 구현해서 만든다.
// String Boot 2.x대는 javax.servlet.error 이고
// String Boot 3.x대는 jakarta.servlet.error 이다.
@Controller
public class CustomErrorController implements ErrorController {

	@RequestMapping(value = "/error")
	public String error(HttpServletRequest request, Model model) {
		String errorPage = "";
		// 에러 상태값 얻기
		Object status = request.getAttribute("jakarta.servlet.error.status_code");

		// 출력할 값을 model에 저장한다.
		model.addAttribute("status", "상태 : " + status);
		model.addAttribute("path", request.getAttribute("jakarta.servlet.error.request_uri"));
		model.addAttribute("time", LocalDateTime.now().format(DateTimeFormatter.ofPattern("yy-MM-dd(E) hh:mm:ss.S")));

		// 예외 발생 내용을 얻어서 모델에 저장한다.
		Object exceptionObj = request.getAttribute("jakarta.servlet.error.exception");
		if (exceptionObj != null) {
			Throwable throwable = ((Exception) exceptionObj).getCause();
			model.addAttribute("exception", throwable.getClass().getName());
			model.addAttribute("message", throwable.getMessage());
		}
		// 이동할 페이지를 지정한다.
		if (status.equals(HttpStatus.NOT_FOUND.value())) {
			errorPage = "/error/404";
		} else if (status.equals(405)) {
			errorPage = "/error/405";
		} else {
			errorPage = "/error/500";
		}
		return errorPage;
	}

	// 테스트를 위하여 에러가 발생하는 상황을 만들어 보자!!!!
	@GetMapping(value = { "/accessDenied" })
	public String accessDenied() {
		return "/error/accessDenied";
	}

	// 첫번째 오류: 0으로 나눴으므로 500 오류를 발생시킨다.
	@GetMapping("/div")
	public String problem(Model model) {
		int result = 1 / 0;
		model.addAttribute("serverTime", result);
		return "home";
	}

	// 두 번째 오류: @PostMapping이므로 Get 방식으로 요청 시 405 오류를 발생시킨다.
	@PostMapping("/method")
	public String method() {
		return "home";
	}
}
