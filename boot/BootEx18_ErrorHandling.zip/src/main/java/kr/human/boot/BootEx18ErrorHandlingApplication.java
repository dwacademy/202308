package kr.human.boot;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class BootEx18ErrorHandlingApplication {

	public static void main(String[] args) {
		SpringApplication.run(BootEx18ErrorHandlingApplication.class, args);
	}
	@Bean
	public CommandLineRunner commandLineRunner() throws Exception {
		/* 람다식 사용 */
		
		return (args)->{
			System.out.println("-".repeat(80));
			System.out.println("http://localhost:8080 접속!!!");
			System.out.println("-".repeat(80));
		};
	}
}
