package kr.human.app.vo;

import java.util.Date;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import lombok.Data;

@Data 
@XmlRootElement // 클래스 이름을 루트태그로 쓰겠다.
@XmlAccessorType(XmlAccessType.FIELD) // 형식을 필드에 쓰겠다.
public class ExamResult {
	@XmlElement // 태그로 사용
	private String name;
	@XmlElement
	@XmlJavaTypeAdapter(type = Date.class, value = DateAdapter.class) // 변환시 사용할 클래스 지정
	private Date   date;
	@XmlElement
	private int    score;
}
