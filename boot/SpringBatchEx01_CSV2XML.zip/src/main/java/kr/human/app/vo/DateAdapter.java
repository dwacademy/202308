package kr.human.app.vo;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.xml.bind.annotation.adapters.XmlAdapter;
// XML에 저장되어있는 문자열을 자바 객체에 맞게 변환 처리를 해줄 클래스
// unmarshal : XML을 자바 객체로 만드는과정
// marshal : 자바 객체로 XML로 만드는과정
public class DateAdapter extends XmlAdapter<String, Date>{

	@Override
	public Date unmarshal(String v) throws Exception {
		SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
		return sdf.parse(v);
	}

	@Override
	public String marshal(Date v) throws Exception {
		SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
		return sdf.format(v);
	}

}
