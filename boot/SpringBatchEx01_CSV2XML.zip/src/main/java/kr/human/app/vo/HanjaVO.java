package kr.human.app.vo;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import lombok.Data;

@Data 
@XmlRootElement // 클래스 이름을 루트태그로 쓰겠다.
@XmlAccessorType(XmlAccessType.FIELD) // 형식을 필드에 쓰겠다.
public class HanjaVO {
	@XmlAttribute // 속성으로 쓰겠다
	private int index;
	@XmlElement // 태그로 쓰겠다.
	private String h;
	@XmlElement
	private String k;
}
