package kr.human.app.service;

import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FieldSet;
import org.springframework.validation.BindException;

import kr.human.app.vo.ExamResult;

public class ExamResultFieldSetMapper implements FieldSetMapper<ExamResult>{

	// FieldSet : 1줄의 데이터. DB로 보면 ResultSet과 같다.
	// 1줄을 읽어서 VO를 만들어 리턴해주면 된다.
	@Override
	public ExamResult mapFieldSet(FieldSet fieldSet) throws BindException {
		ExamResult examResult = new ExamResult();
		// VO를 채워준다.
		examResult.setName(fieldSet.readString(0));
		examResult.setDate(fieldSet.readDate(1, "dd/MM/yyyy"));
		examResult.setScore(fieldSet.readInt(2));
		return examResult;
	}

}
