package kr.human.app.service;

import org.springframework.batch.item.ItemProcessor;

import kr.human.app.vo.ExamResult;

// 1개의 아이템을 읽을때마다 처리할 클래스(선택)
public class ExamResultItemProcessor implements ItemProcessor<ExamResult, ExamResult>{

	@Override
	public ExamResult process(ExamResult item) throws Exception {
		// 조건을 주면 조건에 일치하는 데이터만 처리합니다.
		if(item.getScore()<60) { 
			System.out.println(item + "처리 안함!!!!");
			return null;
		}else {
			System.out.println(item + "처리함!!!!");
			return item;
		}
	}

}
