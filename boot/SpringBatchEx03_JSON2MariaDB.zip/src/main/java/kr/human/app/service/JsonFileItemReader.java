package kr.human.app.service;

import java.io.InputStreamReader;
import java.util.List;

import org.springframework.batch.item.file.ResourceAwareItemReaderItemStream;
import org.springframework.batch.item.support.AbstractItemCountingItemStreamItemReader;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.core.io.Resource;
import org.springframework.util.ClassUtils;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import kr.human.app.vo.HanjaVO;
public class JsonFileItemReader extends AbstractItemCountingItemStreamItemReader<HanjaVO>
	implements ResourceAwareItemReaderItemStream<HanjaVO>, InitializingBean {

	private Resource resource;  // 읽을 파일의 위치
	@SuppressWarnings("unused")
	private String classToBound; // 읽을 클래스의 이름
	private List<HanjaVO> items; // 모든 데이터
	private int index; // 모든데이터에 1개씩 읽을때 사용할 인덱스
	private Gson gson = new Gson(); // json파일을 읽을때 사용할 객체
	
	// 생성자
	public JsonFileItemReader() {
		setName(ClassUtils.getShortName(JsonFileItemReader.class));
	}
	
	@Override
	public void afterPropertiesSet() throws Exception {
		;
	}
	
	// 읽을 클래스 이름
	public void setClassToBound(String classToBound) {
		this.classToBound = classToBound;
	}

	@Override // 데이터의 위치
	public void setResource(Resource resource) { 
		this.resource = resource;
	}

	@Override // 1개씩 읽는 기능
	protected HanjaVO doRead() throws Exception { // 1개 읽기
		return this.items==null || index >= this.items.size() ? null : this.items.get(index++);
	}

	@Override // 데이터 전체를 읽기
	protected void doOpen() throws Exception { // 파일에서 읽어서 리스트에 저장
		try {
			InputStreamReader isr = new InputStreamReader(resource.getInputStream());
			this.items = gson.fromJson(isr, new TypeToken<List<HanjaVO>>() {}.getType());
			System.out.println(this.items.size() + "개 읽음!!!");
		}catch (Exception e) {
			System.out.println("파싱에러 : " + e.getMessage());
		}
	}

	@Override
	protected void doClose() throws Exception {
		;
	} 

}
