package kr.human.app.service;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;

// 각각의 데이터를 처리할때 감시자 역활을 하는 클래스(선택)
public class HanjaVOJobListener  implements JobExecutionListener{

	long startTime, endTime;
	
	// 일을 시작하기 전에 실행할 내용
	@Override
	public void beforeJob(JobExecution jobExecution) {
		startTime = System.currentTimeMillis();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
		System.out.println("시작시간 : " + sdf.format(new Date(startTime)));
	}

	// 일을 종료한  후에 실행할 내용
	@Override
	public void afterJob(JobExecution jobExecution) {
		endTime = System.currentTimeMillis();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
		System.out.println("종료시간 : " + sdf.format(new Date(endTime)));
		System.out.println("실행시간 : " + (endTime-startTime) + "ms");
		if(jobExecution.getStatus()==BatchStatus.FAILED) {
			System.out.println("작업 실패!!!!");
		}else if(jobExecution.getStatus()==BatchStatus.COMPLETED){
			System.out.println("작업 성공!!!!");
		}
	}
	
}
