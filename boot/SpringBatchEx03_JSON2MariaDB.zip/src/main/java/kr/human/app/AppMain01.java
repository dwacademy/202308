package kr.human.app;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersInvalidException;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class AppMain01 {
	public static void main(String[] args) {
		AbstractApplicationContext context = new ClassPathXmlApplicationContext("BatchConfig.xml");
		
		// 실행기 찾기
		JobLauncher jobLauncher = context.getBean("jobLauncher", JobLauncher.class);
		
		// 일찾기
		Job job = context.getBean("hanjaVOJob", Job.class);
		
		
		// 일 실행
		try {
			jobLauncher.run(job, new JobParameters());
		} catch (JobExecutionAlreadyRunningException | JobRestartException | JobInstanceAlreadyCompleteException
				| JobParametersInvalidException e) {
			System.out.println("작업 실패!!!!!!!!!!!!!!!!!!!!!!");
			e.printStackTrace();
		}
		
		context.close();
	}
}
