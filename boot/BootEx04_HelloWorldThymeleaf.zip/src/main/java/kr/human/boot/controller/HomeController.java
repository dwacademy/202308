package kr.human.boot.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import kr.human.boot.vo.TestVO;

@Controller
public class HomeController {

	@RequestMapping(value = "/")
	public String index(Model model) {
		
		model.addAttribute("name","<h2>한사람</h2>");
		
		Map<String, Object> map = new HashMap<>();
		map.put("name", "두사람");
		map.put("age", 33);
		map.put("gender", true);
		model.addAttribute("map",map);
		
		TestVO testVO = new TestVO("세사람", 45, false);
		model.addAttribute("vo", testVO);

		List<String> hobby = new ArrayList<>();
		hobby.add("잠자기");
		hobby.add("술마시기");
		hobby.add("노래하기");
		hobby.add("춤추기");
		model.addAttribute("hobby", hobby);
		
		return "index";
	}
}
