package kr.human.app.service;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.HashMap;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import kr.human.app.dao.TestDAO;
import kr.human.app.vo.TestVO;

@Service("testService")
public class TestServiceImpl implements TestService {

	@Autowired
	private TestDAO testDAO;
	
	@Autowired
	private DataSource dataSource;

	@Override
	public String selectToday() {
		String today="";
		Connection conn = null;
		try {
			conn = dataSource.getConnection();
			conn.setAutoCommit(false);
			//-----------------------------------------------------
			today = testDAO.selectToday(conn);
			//-----------------------------------------------------
			conn.commit();
		} catch (SQLException e) {
			try {
				if(conn!=null) conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
		} finally {
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return today;
	}

	@Override
	public TestVO selectVO(int num1, int num2) {
		TestVO testVO = null;
		Connection conn = null;
		try {
			conn = dataSource.getConnection();
			conn.setAutoCommit(false);
			//-----------------------------------------------------
			HashMap<String, Integer> map = new HashMap<>();
			map.put("num1", num1);
			map.put("num2", num2);
			testVO = testDAO.selectVO(conn, map);
			//-----------------------------------------------------
			conn.commit();
		} catch (SQLException e) {
			try {
				if(conn!=null) conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
		} finally {
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return testVO;
	}
	
}
