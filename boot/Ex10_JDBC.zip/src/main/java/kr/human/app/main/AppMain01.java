package kr.human.app.main;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import kr.human.app.config.AppConfig;
import kr.human.app.controller.TestController;

public class AppMain01 {
	public static void main(String[] args) {
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
		
		TestController testController = context.getBean("testController", TestController.class );
		
		System.out.println("디비 시간 : " + testController.selectToday());
		System.out.println("디비 정보 : " + testController.selectVO(11, 22));
		
		context.close();
	}
}
