package kr.human.app.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;

import org.springframework.stereotype.Repository;
import kr.human.app.vo.TestVO;

@Repository("testDAO")
public class TestDAOImpl implements TestDAO {

	@Override
	public String selectToday(Connection conn) throws SQLException {
		String today = "";
		String sql = "select now() today";
		Statement stmt = conn.createStatement();
		ResultSet rs = stmt.executeQuery(sql);
		rs.next();
		today = rs.getString("today");
		rs.close();
		stmt.close();
		return today;
	}

	@Override
	public TestVO selectVO(Connection conn, HashMap<String, Integer> map) throws SQLException {
		TestVO testVO = null;
		String sql = "select now(), ? , ? , ?+? , ?*?";
		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setInt(1, map.get("num1"));
		pstmt.setInt(2, map.get("num2"));
		pstmt.setInt(3, map.get("num1"));
		pstmt.setInt(4, map.get("num2"));
		pstmt.setInt(5, map.get("num1"));
		pstmt.setInt(6, map.get("num2"));

		ResultSet rs = pstmt.executeQuery();
		if(rs.next()) {
			testVO = new TestVO();
			testVO.setToday(rs.getTimestamp(1));
			testVO.setNum1(rs.getInt(2));
			testVO.setNum2(rs.getInt(3));
			testVO.setAdd(rs.getInt(4));
			testVO.setMul(rs.getInt(5));
		}
		rs.close();
		pstmt.close();
		return testVO;
	}

}
