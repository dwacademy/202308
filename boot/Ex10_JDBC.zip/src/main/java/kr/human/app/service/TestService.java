package kr.human.app.service;

import kr.human.app.vo.TestVO;

public interface TestService {
	String selectToday();
	TestVO selectVO(int num1, int num2);
}
