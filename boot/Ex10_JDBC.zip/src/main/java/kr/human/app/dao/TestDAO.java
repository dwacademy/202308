package kr.human.app.dao;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.HashMap;

import kr.human.app.vo.TestVO;

public interface TestDAO {
	String selectToday(Connection conn) throws SQLException;
	TestVO selectVO(Connection conn, HashMap<String, Integer> map) throws SQLException;
}
