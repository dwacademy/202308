package kr.human.app.main;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;

import kr.human.app.config.AppConfig;
import kr.human.app.service.FileService;

public class AppMain01 {
	public static void main(String[] args) {
		AbstractApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
		
		FileService fileService = context.getBean("fileService", FileService.class);
		fileService.readValues();
		
		context.close();
	}
}
