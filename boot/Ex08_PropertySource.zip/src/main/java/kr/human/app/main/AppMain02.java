package kr.human.app.main;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import kr.human.app.service.FileService;

public class AppMain02 {
	public static void main(String[] args) {
		AbstractApplicationContext context = new ClassPathXmlApplicationContext("AppConfig.xml");
		
		FileService fileService = context.getBean("fileService", FileService.class);
		fileService.readValues();
		
		context.close();
	}
}
