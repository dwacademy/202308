package kr.human.app.service;

public interface FileService {
	void readValues();
}
