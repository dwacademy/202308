package kr.human.app.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

@Service("fileService") // 스트링 컨테이너에 이 클래스 객체를 등록한다.
public class FileServiceImpl implements FileService{
	
	@Value("${sourceLocation:c:/temp/input}") // 프로퍼티 파일에서 읽어서 초기화 한다. 없으면 기본값을 가진다.
	private String source;
	
	@Value("${destinationLocation:c:/temp/output}")
	private String destination;
	
	@Autowired // 환경변수값을 읽을 때 사용하는 객체. 스프링에 만들어져 있다. 사용만 하면 된다.
    private Environment environment;
	
	@Override
	public void readValues() {
		// 하나씩 별도로 읽기
		System.out.println("드라이버 클래스 이름 : " + environment.getProperty("jdbc.driverClassName"));
		// 변수로 읽은 값 출력하기
		System.out.println("source Location : " + source);
		System.out.println("destinationLocation : " + destination);
	}
}
