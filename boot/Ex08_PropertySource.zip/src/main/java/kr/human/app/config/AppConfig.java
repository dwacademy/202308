package kr.human.app.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;

@Configuration // 환경설정 파일이다.
@ComponentScan(basePackages = {"kr.human.app"}) // 자동으로 검색해서 객체를 등록해라
@PropertySource(value = "classpath:application.properties") // 프로퍼티 파일의 위치 지정
public class AppConfig {

	@Bean // @Value를 사용할 경우에 반드시 만들어 준다.
	public static PropertySourcesPlaceholderConfigurer placeholderConfigurer() {
		return new PropertySourcesPlaceholderConfigurer();
	}
}
