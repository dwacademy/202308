SELECT * FROM tab;
CREATE SEQUENCE myboard_idx_seq;
CREATE TABLE myboard(
	idx NUMBER PRIMARY KEY,
	name varchar2(100) NOT NULL,
	password varchar2(100) NOT NULL,
	subject varchar2(1000) NOT NULL,
	content varchar2(4000) NOT NULL,
	regdate timestamp DEFAULT sysdate,
	readCount NUMBER DEFAULT 0,
	ip varchar2(30) NOT NULL
);
SELECT * FROM myboard;