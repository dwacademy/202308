package kr.human.boot.service;

import kr.human.boot.vo.MyBoardVO;
import kr.human.boot.vo.PagingVO;

public interface MyBoardService {
	// 목록보기
	PagingVO<MyBoardVO> selectList(int currentPage, int sizeOfPage, int sizeOfBlock);
	// 저장하기
	boolean insert(MyBoardVO myBoardVO);
	// 내용보기
	MyBoardVO selectByIdx(int idx, boolean isReadCount); // isReadCount는 조회수 증가여부
	// 수정하기
	boolean update(MyBoardVO myBoardVO);
	// 삭제하기
	boolean delete(MyBoardVO myBoardVO);
}
