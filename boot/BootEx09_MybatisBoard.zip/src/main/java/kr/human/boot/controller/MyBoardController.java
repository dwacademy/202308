package kr.human.boot.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import jakarta.servlet.http.HttpServletRequest;
import kr.human.boot.service.MyBoardService;
import kr.human.boot.vo.CommVO;
import kr.human.boot.vo.MyBoardVO;
import kr.human.boot.vo.PagingVO;
import lombok.extern.slf4j.Slf4j;

@Controller
@Slf4j
public class MyBoardController {

	@Autowired
	private MyBoardService myBoardService;
	
	// 목록보기
	@GetMapping(value = "/list")
	public String list(@ModelAttribute CommVO commVO, Model model) {
		log.info("넘어온값 : {}", commVO);
		model.addAttribute("cv", commVO);
		PagingVO<MyBoardVO> pagingVO = myBoardService.selectList(commVO.getCurrentPage(), commVO.getSizeOfPage(), commVO.getSizeOfBlock()); 
		model.addAttribute("pv", pagingVO);
		log.info("가져온값 : {}", pagingVO);
		return "list";
	}
	// 저장폼 띄우기
	@GetMapping(value = "/insert")
	public String insert(@ModelAttribute CommVO commVO, Model model) {
		log.info("넘어온값 : {}", commVO);
		model.addAttribute("cv", commVO);
		return "insert";
	}
	// 저장하기 : Get방식일 경우 리스트로 강제이동
	@GetMapping(value = "/insertOk")
	public String insertOkGet(@ModelAttribute CommVO commVO, Model model) {
		return "redirect:/list";
	}
	// 저장하기 : Post방식일때 저장하고 1페이지로 이동
	@PostMapping(value = "/insertOk")
	public String insertPost(
			@ModelAttribute CommVO commVO, 
			@ModelAttribute MyBoardVO myBoardVO, 
			HttpServletRequest request) {
		
		log.info("넘어온값1 : {}", commVO);
		myBoardVO.setIp(request.getRemoteAddr());
		log.info("넘어온값2 : {}", myBoardVO);
		myBoardService.insert(myBoardVO);
		return "redirect:/list?p=1&s=" + commVO.getSizeOfPage()+"&b="+commVO.getSizeOfBlock();
	}
	// 내용보기
	@GetMapping(value = "/view")
	public String view(@ModelAttribute CommVO commVO, Model model) {
		MyBoardVO myBoardVO = myBoardService.selectByIdx(commVO.getIdx(), true); // 받고 조회수 증가
		if(myBoardVO!=null) {
			myBoardVO.setReadCount(myBoardVO.getReadCount()+1); // 조회수 증가
			model.addAttribute("cv", commVO);
			model.addAttribute("vo", myBoardVO);
			model.addAttribute("newLine", "\n");
			model.addAttribute("br", "<br/>");
			return "view";
		}else {
			return "redirect:/list";
		}
	}
	
	// 수정폼 띄우기
	@GetMapping(value = "/update")
	public String update(@ModelAttribute CommVO commVO, Model model) {
		log.info("넘어온값 : {}", commVO);
		model.addAttribute("cv", commVO);
		MyBoardVO myBoardVO = myBoardService.selectByIdx(commVO.getIdx(), false); // 받고 조회수 증가 안함
		if(myBoardVO!=null) {
			model.addAttribute("cv", commVO);
			model.addAttribute("vo", myBoardVO);
			return "update";
		}else {
			return "redirect:/list";
		}
	}
	// 수정하기 : Get방식일 경우 리스트로 강제이동
	@GetMapping(value = "/updateOk")
	public String updateOkGet(@ModelAttribute CommVO commVO, Model model) {
		return "redirect:/list";
	}
	// 수정하기 : Post방식일때 저장하고 1페이지로 이동
	@PostMapping(value = "/updateOk")
	public String updateOkPost(
			@ModelAttribute CommVO commVO, 
			@ModelAttribute MyBoardVO myBoardVO, 
			HttpServletRequest request) {
		
		log.info("넘어온값1 : {}", commVO);
		myBoardVO.setIp(request.getRemoteAddr());
		log.info("넘어온값2 : {}", myBoardVO);
		myBoardService.update(myBoardVO);
		return "redirect:/view?idx="+commVO.getIdx()+"&p=" + commVO.getCurrentPage() + "&s=" + commVO.getSizeOfPage()+"&b="+commVO.getSizeOfBlock();
	}

	// 삭제폼 띄우기
	@GetMapping(value = "/delete")
	public String delete(@ModelAttribute CommVO commVO, Model model) {
		log.info("넘어온값 : {}", commVO);
		model.addAttribute("cv", commVO);
		MyBoardVO myBoardVO = myBoardService.selectByIdx(commVO.getIdx(), false); // 받고 조회수 증가 안함
		if(myBoardVO!=null) {
			model.addAttribute("cv", commVO);
			model.addAttribute("vo", myBoardVO);
			return "delete";
		}else {
			return "redirect:/list";
		}
	}
	// 수정하기 : Get방식일 경우 리스트로 강제이동
	@GetMapping(value = "/deleteOk")
	public String deleteOkGet(@ModelAttribute CommVO commVO, Model model) {
		return "redirect:/list";
	}
	// 수정하기 : Post방식일때 저장하고 1페이지로 이동
	@PostMapping(value = "/deleteOk")
	public String deleteOkPost(
			@ModelAttribute CommVO commVO, 
			@ModelAttribute MyBoardVO myBoardVO, 
			HttpServletRequest request) {
		
		log.info("넘어온값1 : {}", commVO);
		myBoardVO.setIp(request.getRemoteAddr());
		log.info("넘어온값2 : {}", myBoardVO);
		myBoardService.delete(myBoardVO);
		return "redirect:/list?p=" + commVO.getCurrentPage() + "&s=" + commVO.getSizeOfPage()+"&b="+commVO.getSizeOfBlock();
	}
	
}
