package kr.human.boot.service;

import java.sql.SQLException;
import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import kr.human.boot.dao.MyBoardtDAO;
import kr.human.boot.vo.MyBoardVO;
import kr.human.boot.vo.PagingVO;

@Service("myBoardService")
public class MyBoardServiceImpl implements MyBoardService{

	@Autowired
	private MyBoardtDAO myBoardtDAO;

	// 목록보기
	@Override
	public PagingVO<MyBoardVO> selectList(int currentPage, int sizeOfPage, int sizeOfBlock) {
		PagingVO<MyBoardVO> pv = null;
		try {
			// 전체 개수 구하고
			int totalCount = myBoardtDAO.selectCount();
			// 페이지 계산하고
			pv = new PagingVO<>(totalCount, currentPage, sizeOfPage, sizeOfBlock);
			// 개수가 있다면 글목록을 가져와 넣어준다.
			if(pv.getTotalCount()>0) {
				HashMap<String, Integer> map = new HashMap<>();
				map.put("startNo", pv.getStartNo());
				map.put("endNo", pv.getEndNo());
				pv.setList(myBoardtDAO.selectList(map));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return pv;
	}

	@Override
	public boolean insert(MyBoardVO myBoardVO) {
		boolean result = false;
		if(myBoardVO!=null) {
			try {
				myBoardtDAO.insert(myBoardVO);
				result = true; // 저장이 성공하면 true
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return result;
	}

	@Override
	public MyBoardVO selectByIdx(int idx, boolean isReadCount) {
		MyBoardVO myBoardVO = null;
		try {
			myBoardVO = myBoardtDAO.selectByIdx(idx);
			if(myBoardVO!=null && isReadCount) {
				// 해당 글번호의 글이 존재하면서 조회수가 참이면 조회수를 증가 시킨다.
				myBoardtDAO.incrementReadCount(idx);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return myBoardVO;
	}

	@Override
	public boolean update(MyBoardVO myBoardVO) {
		boolean result = false;
		if(myBoardVO!=null) {
			try {
				// DB에 있는 값의 비번과 입력한 비번이 같을때만 수정한다.
				MyBoardVO dbVO = myBoardtDAO.selectByIdx(myBoardVO.getIdx());
				if(dbVO!=null && dbVO.getPassword().equals(myBoardVO.getPassword())) {
					myBoardtDAO.update(myBoardVO);
					result = true; // 수정이 성공하면 true
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return result;
	}

	@Override
	public boolean delete(MyBoardVO myBoardVO) {
		boolean result = false;
		if(myBoardVO!=null) {
			try {
				// DB에 있는 값의 비번과 입력한 비번이 같을때만 삭제한다.
				MyBoardVO dbVO = myBoardtDAO.selectByIdx(myBoardVO.getIdx());
				if(dbVO!=null && dbVO.getPassword().equals(myBoardVO.getPassword())) {
					myBoardtDAO.delete(myBoardVO.getIdx());
					result = true; // 삭제가 성공하면 true
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return result;	
	}
}
