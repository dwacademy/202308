package kr.human.boot.dao;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import kr.human.boot.vo.MyBoardVO;

@Mapper
public interface MyBoardtDAO {
	int selectCount() throws SQLException;
	MyBoardVO selectByIdx(int idx) throws SQLException;
	List<MyBoardVO> selectList(HashMap<String, Integer> map)  throws SQLException;
	void insert(MyBoardVO myBoardVO)  throws SQLException;
	void update(MyBoardVO myBoardVO)  throws SQLException;
	void delete(int idx) throws SQLException;
	void incrementReadCount(int idx) throws SQLException;
}
