package kr.human.boot.controller;

import java.time.LocalDateTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import kr.human.boot.service.TestService;


@Controller
public class TestController {

	@Autowired
	TestService testService;
	
	@GetMapping("/h2")
	public String index(Model model) {
		model.addAttribute("serverTime", LocalDateTime.now());
		model.addAttribute("dbTimeString", testService.today());
		model.addAttribute("sum", testService.sum(11, 22));
		model.addAttribute("mul", testService.mul(33, 44));
		model.addAttribute("vo", testService.vo(67, 45));
		return "h2";
	}
}
