package kr.human.boot.vo;

import java.util.Date;

import lombok.Data;

@Data
public class TestVO {
	private int num1;
	private int num2;
	private Date today;
	private int sum;
	private int mul;
}
