package kr.human.boot.controller;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import kr.human.boot.service.PersonService;
import kr.human.boot.vo.Person;

@Controller
public class PersonController {
	@Autowired
	PersonService personService;
	
	@GetMapping(value = "/insert1")
	public String insert1() {
		personService.insert(new Person(1, "한사람", 22, new Date()));
		personService.insert(new Person(2, "두사람", 18, new Date()));
		personService.insert(new Person(3, "네사람", 32, new Date()));
		personService.insert(new Person(4, "세사람", 19, new Date()));
		return "redirect:/list1";
	}
	@GetMapping(value = "/list1")
	public String list1(Model model) {
		model.addAttribute("list", personService.selectAll());
		return "list1";
	}
	@GetMapping(value = "/insert2")
	public String insert2() {
		personService.insert(new Person("한사람", 22, new Date()));
		personService.insert(new Person("두사람", 18, new Date()));
		personService.insert(new Person("네사람", 32, new Date()));
		personService.insert(new Person("세사람", 19, new Date()));
		return "redirect:/list2";
	}
	@GetMapping(value = "/list2")
	@ResponseBody
	public List<Person> list2(Model model) {
		return personService.selectAll();
	}
}
