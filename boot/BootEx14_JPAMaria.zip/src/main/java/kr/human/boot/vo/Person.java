package kr.human.boot.vo;

import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Data
public class Person {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int idx;
	private String name;
	private int age;
	private Date regdate; // 변수명에 대문자가 있으면 정확하게 연결이되지 않는다.
						  // 아니면 컬럼명을 애노테이션으로 정확하게 써줘야 한다.
	public Person(String name, int age, Date regdate) {
		super();
		this.name = name;
		this.age = age;
		this.regdate = regdate;
	}
}
