package kr.human.boot.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import kr.human.boot.dao.PersonRepository;
import kr.human.boot.vo.Person;

@Service
public class PersonService {

	@Autowired
	private PersonRepository personRepository;
	
	// 저장
	public void insert(Person person) {
		personRepository.save(person);
	}
	// 모두 읽기
	public List<Person> selectAll(){
		List<Person> list = new ArrayList<>();
		personRepository.findAll().forEach(list::add);
		return list;
	}
}
