create table Person(
	idx int primary key auto_increment,
	name varchar(100) not null,
	age int default 0,
	regDate timestamp default now()
);