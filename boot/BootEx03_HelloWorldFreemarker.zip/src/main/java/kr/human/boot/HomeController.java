package kr.human.boot;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller // View를 사용해서 출력해라!!!
public class HomeController {

	@RequestMapping(value = "/")
	public String home(Model model) {
		model.addAttribute("name","한사람");
		model.addAttribute("age",23);
		return "index";
	}
}
