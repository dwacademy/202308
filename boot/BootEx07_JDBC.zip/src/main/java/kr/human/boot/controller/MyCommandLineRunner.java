package kr.human.boot.controller;

import java.util.Arrays;

import org.springframework.boot.CommandLineRunner;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
// CommandLineRunner는 애플리케이션이 실행될때 자동으로 실행되는 인터페이스이다.
// 구현만 해주면 알아서 실행된다.
@Order(2) // 실행 순서 변경 
@Component
public class MyCommandLineRunner implements CommandLineRunner{

	@Override
	public void run(String... args) throws Exception {
		System.out.println("-".repeat(100));
		System.out.println("CommandLineRunner !!!!!!!!!!!!!!!!!!");		
		System.out.println("http://localhost:8080");		
		System.out.println("-".repeat(100));
		System.out.println(Arrays.toString(args));
		System.out.println("-".repeat(100));
	}

}
