package kr.human.boot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootEx07JdbcApplication {

	public static void main(String[] args) {
		SpringApplication.run(BootEx07JdbcApplication.class, args);
	}

}
