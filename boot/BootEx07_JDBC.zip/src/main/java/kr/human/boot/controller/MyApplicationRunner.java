package kr.human.boot.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.context.ApplicationContext;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
// ApplicationRunner는 애플리케이션이 실행될때 자동으로 실행되는 인터페이스이다.
// 구현만 해주면 알아서 실행된다.
// CommandLineRunner와의 차이는 인수 형식이 다를뿐이다.
@Order(1) // 실행 순서 변경 
@Component
public class MyApplicationRunner implements ApplicationRunner{
	
	@Autowired
	ApplicationContext applicationContext;
	
	@Override
	public void run(ApplicationArguments args) throws Exception {
		System.out.println("-".repeat(100));
		System.out.println("ApplicationRunner !!!!!!!!!!!!!!!!!!");		
		System.out.println("http://localhost:8080");		
		System.out.println("-".repeat(100));
		System.out.println(args);
		System.out.println("-".repeat(100));
		System.out.println("스프링 부트가 자동으로 등록해주는 객체들.....");
		System.out.println("-".repeat(100));
		for(String beanName : applicationContext.getBeanDefinitionNames()) {
			System.out.println(beanName);
		}
		System.out.println("-".repeat(100));

	}

}
