package kr.human.boot.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Date;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import kr.human.boot.vo.TestVO;

@Repository("testDAO")
public class TestDAOImpl implements TestDAO{
	// Boot가 알아서 아래의 2개의 객체를 등록해 준다.
	@Autowired
	private JdbcTemplate jdbcTemplate;
	@Autowired
	private DataSource dataSource;
	
	@Override
	public String selectToday1() {
		// 가장 원시적인 JDBC를 이용한 방법
		String result = "";
		Connection conn = null;
		Statement  stmt = null;
		ResultSet  rs = null;
		
		try {
			conn = dataSource.getConnection();
			conn.setAutoCommit(false);
			//-----------------------------------------------------------------
			stmt = conn.createStatement();
			rs = stmt.executeQuery("select sysdate from dual");
			rs.next();
			result = rs.getString(1);
			//-----------------------------------------------------------------
			conn.commit();
		} catch (SQLException e) {
			try {
				if(conn!=null) conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
		} finally {
			try { if(rs!=null) rs.close(); } catch (SQLException e) {e.printStackTrace(); }
			try { if(stmt!=null) stmt.close(); } catch (SQLException e) {e.printStackTrace(); }
			try { if(conn!=null) conn.close(); } catch (SQLException e) {e.printStackTrace(); }
		}
		return result;
	}
	@Override
	public Date selectToday2() {
		// JdbcTemplate을 이용하면
		return jdbcTemplate.queryForObject("select sysdate from dual", Date.class);
	}
	@Override
	public TestVO selectToday3() {
		// JdbcTemplate을 이용하면
		return jdbcTemplate.queryForObject("select sysdate as today from dual", new TestRowMapper());
	}
	
	
}
