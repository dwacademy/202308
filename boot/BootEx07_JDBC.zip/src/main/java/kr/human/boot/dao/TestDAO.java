package kr.human.boot.dao;

import java.util.Date;
import kr.human.boot.vo.TestVO;

public interface TestDAO {
	String selectToday1();
	Date   selectToday2();
	TestVO selectToday3();
}
