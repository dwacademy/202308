package kr.human.boot.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;
import kr.human.boot.vo.TestVO;

public class TestRowMapper implements RowMapper<TestVO>{

	@Override
	public TestVO mapRow(ResultSet rs, int rowNum) throws SQLException {
		TestVO testVO = new TestVO();
		testVO.setToday(rs.getTimestamp(1));
		return testVO;
	}

}
