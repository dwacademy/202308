package kr.human.app.service;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
@Component
public class MyBean {

	@Scheduled(fixedRate = 10000)
	public void printMessage1() {
		System.out.println("나는 스프링의 스케쥴러에 의해서 자동으로 불려질 겁니다111111111111");
	}
	
	@Scheduled(fixedRate = 5000, initialDelay = 2000)
	public void printMessage2() {
		System.out.println("나는 스프링의 스케쥴러에 의해서 자동으로 불려질 겁니다2222222222222");
	}
	
	@Scheduled(cron = "0/5 * * * * MON-FRI")
	public void printMessage3() {
		System.out.println("나는 스프링의 스케쥴러에 의해서 자동으로 불려질 겁니다333333333333");
	}
}
