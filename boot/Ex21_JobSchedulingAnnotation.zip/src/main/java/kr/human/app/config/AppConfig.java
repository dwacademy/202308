package kr.human.app.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;

@Configuration
@EnableScheduling // 이놈이 스캐쥴을 가능하게 한다.
@ComponentScan(basePackages = {"kr.human.app"})
public class AppConfig {
	/*
	@Bean
	public MyBean bean() {
		return new MyBean();
	}
	*/
}
