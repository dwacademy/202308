package com.tistory.top2blue.vo;

public interface MemberMapping {
	String getName();
	boolean isGender();
}
