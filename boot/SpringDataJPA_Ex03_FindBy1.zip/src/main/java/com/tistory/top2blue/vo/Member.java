package com.tistory.top2blue.vo;

import java.time.LocalDate;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.xml.bind.annotation.XmlRootElement;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@XmlRootElement
@Entity
@Table(name = "Member")
public class Member {
	@Id
	@GeneratedValue
	private Long idx;
	// @Column(unique=true)
	private String userid;
	private String password;
	private String name;
	private int age;
	private boolean gender;
	private LocalDate birthDate;
	
	public Member(String userid, String password, String name, int age, boolean gender, LocalDate birthDate) {
		super();
		this.userid = userid;
		this.password = password;
		this.name = name;
		this.age = age;
		this.gender = gender;
		this.birthDate = birthDate;
	}


}