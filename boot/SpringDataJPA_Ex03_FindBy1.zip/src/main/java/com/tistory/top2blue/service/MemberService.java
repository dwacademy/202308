package com.tistory.top2blue.service;

import java.util.List;

import com.tistory.top2blue.vo.Member;
import com.tistory.top2blue.vo.MemberMapping;

public interface MemberService {
	// 전체 얻기
	List<Member> findAll(); 
	
	// 이름으로 찾기 아래 3개는 모두 같다. 
	List<Member> findByName(String name);
	// 아래 2개는 가독성을 위해 뒤에 Is나 Equals를 추가할 수 있다. 
	List<Member> findByNameIs(String name);
	List<Member> findByNameEquals(String name);
	
	// 다음과 같이 써도 된다.
	List<Member> readByName(String name);
	List<Member> queryByName(String name);
	List<Member> getByName(String name);
	List<Member> searchByName(String name);
	List<Member> streamByName(String name);
	
	int countByName(String name);
	
	// Distinct , First  또는  Top 을 사용하여 중복을 제거하거나 결과 집합을 제한 할 수도 있다.
	MemberMapping findDistinctByName(String name);
	
	List<Member> findFirstByName(String name);
	List<Member> findFirst3ByName(String name);

	List<Member> findTopByName(String name);
	List<Member> findTop2ByName(String name);	
}
