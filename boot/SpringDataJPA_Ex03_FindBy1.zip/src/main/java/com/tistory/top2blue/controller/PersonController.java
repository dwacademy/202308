package com.tistory.top2blue.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.tistory.top2blue.service.MemberService;
import com.tistory.top2blue.vo.Member;
import com.tistory.top2blue.vo.MemberMapping;

import lombok.extern.slf4j.Slf4j;

@Controller
@Slf4j
@RequestMapping(value = "/members")
public class PersonController {
	@Autowired
	private MemberService memberService;
	
	@GetMapping(value = {"/","/list"})
	public String findAll(Model model) throws Exception {
		log.info("컨트롤러 findAll() 호출");
		List<Member> memberList = memberService.findAll();
		log.info("컨트롤러 findAll() 리턴 : {}", memberList);
		model.addAttribute("list", memberList);
		return "member/list";
	}

	@GetMapping(value = {"/findByName"})
	public String findByName(@RequestParam(defaultValue = "한사람") String name, Model model) throws Exception {
		log.info("컨트롤러 findByName({}) 호출", name);
		List<Member> memberList = memberService.findByName(name);
		log.info("컨트롤러 findByName({}) 리턴 : {}", name, memberList);
		model.addAttribute("list", memberList);
		model.addAttribute("count", memberService.countByName(name));
		return "member/list2";
	}

	@GetMapping(value = {"/findByNameIs"})
	public String findByNameIs(@RequestParam(defaultValue = "한사람") String name, Model model) throws Exception {
		log.info("컨트롤러 findByNameIs({}) 호출", name);
		List<Member> memberList = memberService.findByNameIs(name);
		log.info("컨트롤러 findByNameIs({}) 리턴 : {}", name, memberList);
		model.addAttribute("list", memberList);
		model.addAttribute("count", memberService.countByName(name));
		return "member/list2";
	}
	
	@GetMapping(value = {"/findByNameEquals"})
	public String findByNameEquals(@RequestParam(defaultValue = "한사람") String name, Model model) throws Exception {
		log.info("컨트롤러 findByNameEquals({}) 호출", name);
		List<Member> memberList = memberService.findByNameEquals(name);
		log.info("컨트롤러 findByNameEquals({}) 리턴 : {}", name, memberList);
		model.addAttribute("list", memberList);
		model.addAttribute("count", memberService.countByName(name));
		return "member/list2";
	}
	
	@GetMapping(value = {"/readByName"})
	public String readByName(@RequestParam(defaultValue = "한사람") String name, Model model) throws Exception {
		log.info("컨트롤러 readByName({}) 호출", name);
		List<Member> memberList = memberService.readByName(name);
		log.info("컨트롤러 readByName({}) 리턴 : {}", name, memberList);
		model.addAttribute("list", memberList);
		model.addAttribute("count", memberService.countByName(name));
		return "member/list2";
	}
	
	@GetMapping(value = {"/queryByName"})
	public String queryByName(@RequestParam(defaultValue = "한사람") String name, Model model) throws Exception {
		log.info("컨트롤러 queryByName({}) 호출", name);
		List<Member> memberList = memberService.queryByName(name);
		log.info("컨트롤러 queryByName({}) 리턴 : {}", name, memberList);
		model.addAttribute("list", memberList);
		model.addAttribute("count", memberService.countByName(name));
		return "member/list2";
	}
	
	@GetMapping(value = {"/getByName"})
	public String getByName(@RequestParam(defaultValue = "한사람") String name, Model model) throws Exception {
		log.info("컨트롤러 getByName({}) 호출", name);
		List<Member> memberList = memberService.getByName(name);
		log.info("컨트롤러 getByName({}) 리턴 : {}", name, memberList);
		model.addAttribute("list", memberList);
		model.addAttribute("count", memberService.countByName(name));
		return "member/list2";
	}
	
	@GetMapping(value = {"/searchByName"})
	public String searchByName(@RequestParam(defaultValue = "한사람") String name, Model model) throws Exception {
		log.info("컨트롤러 searchByName({}) 호출", name);
		List<Member> memberList = memberService.searchByName(name);
		log.info("컨트롤러 searchByName({}) 리턴 : {}", name, memberList);
		model.addAttribute("list", memberList);
		model.addAttribute("count", memberService.countByName(name));
		return "member/list2";
	}
	
	@GetMapping(value = {"/streamByName"})
	public String streamByName(@RequestParam(defaultValue = "한사람") String name, Model model) throws Exception {
		log.info("컨트롤러 streamByName({}) 호출", name);
		List<Member> memberList = memberService.streamByName(name);
		log.info("컨트롤러 streamByName({}) 리턴 : {}", name, memberList);
		model.addAttribute("list", memberList);
		model.addAttribute("count", memberService.countByName(name));
		return "member/list2";
	}
	
	@GetMapping(value = {"/findDistinctByName"})
	public String findDistinctByName(@RequestParam(defaultValue = "한사람") String name, Model model) throws Exception {
		log.info("컨트롤러 findDistinctByName({}) 호출", name);
		MemberMapping vo = memberService.findDistinctByName(name);
		log.info("컨트롤러 findDistinctByName({}) 리턴 : {}", name, vo);
		model.addAttribute("vo", vo);
		model.addAttribute("count", memberService.countByName(name));
		return "member/list3";
	}
	
	@GetMapping(value = {"/findFirstByName"})
	public String findFirstByName(@RequestParam(defaultValue = "한사람") String name, Model model) throws Exception {
		log.info("컨트롤러 findFirstByName({}) 호출", name);
		List<Member> memberList = memberService.findFirstByName(name);
		log.info("컨트롤러 findFirstByName({}) 리턴 : {}", name, memberList);
		model.addAttribute("list", memberList);
		model.addAttribute("count", memberService.countByName(name));
		return "member/list2";
	}
	
	@GetMapping(value = {"/findFirst3ByName"})
	public String findFirst3ByName(@RequestParam(defaultValue = "한사람") String name, Model model) throws Exception {
		log.info("컨트롤러 findFirst3ByName({}) 호출", name);
		List<Member> memberList = memberService.findFirst3ByName(name);
		log.info("컨트롤러 findFirst3ByName({}) 리턴 : {}", name, memberList);
		model.addAttribute("list", memberList);
		model.addAttribute("count", memberService.countByName(name));
		return "member/list2";
	}
	
	@GetMapping(value = {"/findTopByName"})
	public String findTopByName(@RequestParam(defaultValue = "한사람") String name, Model model) throws Exception {
		log.info("컨트롤러 findTopByName({}) 호출", name);
		List<Member> memberList = memberService.findTopByName(name);
		log.info("컨트롤러 findTopByName({}) 리턴 : {}", name, memberList);
		model.addAttribute("list", memberList);
		model.addAttribute("count", memberService.countByName(name));
		return "member/list2";
	}
	
	@GetMapping(value = {"/findTop2ByName"})
	public String findTop2ByName(@RequestParam(defaultValue = "한사람") String name, Model model) throws Exception {
		log.info("컨트롤러 findTop2ByName({}) 호출", name);
		List<Member> memberList = memberService.findTop2ByName(name);
		log.info("컨트롤러 findTop2ByName({}) 리턴 : {}", name, memberList);
		model.addAttribute("list", memberList);
		model.addAttribute("count", memberService.countByName(name));
		return "member/list2";
	}
	
}
