package com.tistory.top2blue.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.tistory.top2blue.vo.Member;
import com.tistory.top2blue.vo.MemberMapping;

/*

Spring Data JPA 저장소의 파생 쿼리 메서드

간단한 쿼리의 경우 코드에서 해당 메서드 이름을 살펴보는 것만으로 쿼리가 무엇이어야 하는지 쉽게 
도출할 수 있습니다 .

Spring의 파생 쿼리 메서드 구조

파생 메서드 이름에는 첫 번째 By 키워드 로 구분되는 두 가지 주요 부분이 있습니다 .

List<User> findByName(String name)

find 와 같은 첫 번째 부분 은 소개 자이고 ByName 과 같은 나머지 부분 은 criteria 입니다.
Spring Data JPA는 find , read , query , search, stream, count, exists, delete, remove 및  get 을 지원 합니다. 
따라서 queryByName 을 수행할 수 있었고 Spring Data는 동일하게 작동합니다.
Distinct , First  또는  Top 을 사용하여 중복을 제거하거나 결과 집합을 제한 할 수도 있습니다  .

List<User> findTop3ByAge()

조건 부분에는 쿼리의 엔터티별 조건식이 포함됩니다. 엔터티의 속성 이름과 함께 조건 키워드를 
사용할 수 있습니다.
표현식을 And 및 Or 와 연결할 수도 있습니다.

*/
public interface MemberRepository extends CrudRepository<Member, Long> {
	// 이름으로 찾기 아래 3개는 모두 같다. 
	List<Member> findByName(String name);
	// 아래 2개는 가독성을 위해 뒤에 Is나 Equals를 추가할 수 있다. 
	List<Member> findByNameIs(String name);
	List<Member> findByNameEquals(String name);
	
	// 다음과 같이 써도 된다.
	List<Member> readByName(String name);
	List<Member> queryByName(String name);
	List<Member> getByName(String name);
	List<Member> searchByName(String name);
	List<Member> streamByName(String name);

	int countByName(String name);
	boolean existsByName(String name);
	void deleteByName(String name);
	void removeByName(String name);

	
	// Distinct , First  또는  Top 을 사용하여 중복을 제거하거나 결과 집합을 제한 할 수도 있다.
	MemberMapping findDistinctByName(String name);
	List<Member> findFirstByName(String name);
	List<Member> findTopByName(String name);

	List<Member> findFirst3ByName(String name);
	List<Member> findTop2ByName(String name);
}
