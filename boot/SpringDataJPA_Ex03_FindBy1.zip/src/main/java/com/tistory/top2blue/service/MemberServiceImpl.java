package com.tistory.top2blue.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tistory.top2blue.repository.MemberRepository;
import com.tistory.top2blue.vo.Member;
import com.tistory.top2blue.vo.MemberMapping;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service("memberService")
public class MemberServiceImpl implements MemberService {

	@Autowired
	private MemberRepository memberRepository;

	@Override
	public List<Member> findAll() {
		log.info("서비스 findAll() 호출");
		List<Member> list = new ArrayList<>();
		memberRepository.findAll().forEach(list::add);
		log.info("서비스 findAll() 리턴 : {}", list);
		return list;
	}

	@Override
	public List<Member> findByName(String name) {
		log.info("서비스 findByName({}) 호출", name);
		List<Member> list = new ArrayList<>();
		memberRepository.findByName(name).forEach(list::add);
		log.info("서비스 findByName({}) 리턴 : {}", name, list);
		return list;
	}

	@Override
	public List<Member> findByNameIs(String name) {
		log.info("서비스 findByNameIs({}) 호출", name);
		List<Member> list = new ArrayList<>();
		memberRepository.findByNameIs(name).forEach(list::add);
		log.info("서비스 findByNameIs({}) 리턴 : {}", name, list);
		return list;
	}

	@Override
	public List<Member> findByNameEquals(String name) {
		log.info("서비스 findByNameEquals({}) 호출", name);
		List<Member> list = new ArrayList<>();
		memberRepository.findByNameEquals(name).forEach(list::add);
		log.info("서비스 findByNameEquals({}) 리턴 : {}", name, list);
		return list;
	}

	@Override
	public List<Member> readByName(String name) {
		log.info("서비스 readByName({}) 호출", name);
		List<Member> list = new ArrayList<>();
		memberRepository.readByName(name).forEach(list::add);
		log.info("서비스 readByName({}) 리턴 : {}", name, list);
		return list;
	}

	@Override
	public List<Member> queryByName(String name) {
		log.info("서비스 queryByName({}) 호출", name);
		List<Member> list = new ArrayList<>();
		memberRepository.queryByName(name).forEach(list::add);
		log.info("서비스 queryByName({}) 리턴 : {}", name, list);
		return list;
	}

	@Override
	public List<Member> getByName(String name) {
		log.info("서비스 getByName({}) 호출", name);
		List<Member> list = new ArrayList<>();
		memberRepository.getByName(name).forEach(list::add);
		log.info("서비스 getByName({}) 리턴 : {}", name, list);
		return list;
	}

	@Override
	public List<Member> searchByName(String name) {
		log.info("서비스 searchByName({}) 호출", name);
		List<Member> list = new ArrayList<>();
		memberRepository.searchByName(name).forEach(list::add);
		log.info("서비스 searchByName({}) 리턴 : {}", name, list);
		return list;
	}

	@Override
	public List<Member> streamByName(String name) {
		log.info("서비스 streamByName({}) 호출", name);
		List<Member> list = new ArrayList<>();
		memberRepository.streamByName(name).forEach(list::add);
		log.info("서비스 streamByName({}) 리턴 : {}", name, list);
		return list;
	}
	
	@Override
	public int countByName(String name) {
		log.info("서비스 countByName({}) 호출", name);
		int count = memberRepository.countByName(name);
		log.info("서비스 countByName({}) 리턴 : {}", name, count);
		return count;
	}

	@Override
	public MemberMapping findDistinctByName(String name) {
		log.info("서비스 findDistinctByName({}) 호출", name);
		MemberMapping vo = memberRepository.findDistinctByName(name);
		log.info("서비스 findDistinctByName({}) 리턴 : {}", name, vo);
		return vo;
	}

	@Override
	public List<Member> findFirstByName(String name) {
		log.info("서비스 findFirstByName({}) 호출", name);
		List<Member> list = new ArrayList<>();
		memberRepository.findFirstByName(name).forEach(list::add);
		log.info("서비스 findFirstByName({}) 리턴 : {}", name, list);
		return list;
	}

	@Override
	public List<Member> findFirst3ByName(String name) {
		log.info("서비스 findFirst3ByName({}) 호출", name);
		List<Member> list = new ArrayList<>();
		memberRepository.findFirst3ByName(name).forEach(list::add);
		log.info("서비스 findFirst3ByName({}) 리턴 : {}", name, list);
		return list;
	}

	@Override
	public List<Member> findTopByName(String name) {
		log.info("서비스 findTopByName({}) 호출", name);
		List<Member> list = new ArrayList<>();
		memberRepository.findTopByName(name).forEach(list::add);
		log.info("서비스 findTopByName({}) 리턴 : {}", name, list);
		return list;
	}

	@Override
	public List<Member> findTop2ByName(String name) {
		log.info("서비스 findTop2ByName({}) 호출", name);
		List<Member> list = new ArrayList<>();
		memberRepository.findTop2ByName(name).forEach(list::add);
		log.info("서비스 findTop2ByName({}) 리턴 : {}", name, list);
		return list;
	}
}
