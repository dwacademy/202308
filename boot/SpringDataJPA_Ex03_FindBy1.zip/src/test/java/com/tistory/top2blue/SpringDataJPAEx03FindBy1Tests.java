package com.tistory.top2blue;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.tistory.top2blue.repository.MemberRepository;

@SpringBootTest
class SpringDataJPAEx03FindBy1Tests {
	
	@Autowired
	MemberRepository memberRepository;
	
	@Test
	void findByName() {
		System.out.println(memberRepository.findByName("한사람"));
		System.out.println(memberRepository.findByNameIs("한사람"));
		System.out.println(memberRepository.findByNameEquals("한사람"));
		assertEquals(memberRepository.findByNameEquals("한사람").size(), 5);
	}

	@Test
	void findByName2() {
		System.out.println("=".repeat(80));
		System.out.println(memberRepository.readByName("한사람"));
		System.out.println("=".repeat(80));
		System.out.println(memberRepository.queryByName("한사람"));
		System.out.println("=".repeat(80));
		System.out.println(memberRepository.getByName("한사람"));
		System.out.println("=".repeat(80));
		System.out.println(memberRepository.countByName("한사람"));
		System.out.println("=".repeat(80));
		System.out.println(memberRepository.findDistinctByName("한사람"));
		System.out.println("=".repeat(80));
		System.out.println(memberRepository.findFirstByName("한사람"));
		System.out.println("=".repeat(80));
		System.out.println(memberRepository.findFirst3ByName("한사람"));
		System.out.println("=".repeat(80));
		System.out.println(memberRepository.findTopByName("한사람"));
		System.out.println("=".repeat(80));
		System.out.println(memberRepository.findTop2ByName("한사람"));
		System.out.println("=".repeat(80));
	}
	
}
