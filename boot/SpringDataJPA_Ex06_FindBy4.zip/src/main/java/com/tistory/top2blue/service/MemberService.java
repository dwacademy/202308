package com.tistory.top2blue.service;

import java.util.List;

import com.tistory.top2blue.vo.Member;

public interface MemberService {
	// 전체 얻기
	List<Member> findAll(); 
	
	// 시작
	List<Member> findByNameStartingWith(String prefix);
	// 종료
	List<Member> findByNameEndingWith(String suffix);
	// 포함
	List<Member> findByNameContaining(String infix);
	// like조건
	List<Member> findByNameLike(String likePattern);
}
