package com.tistory.top2blue.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.tistory.top2blue.service.MemberService;
import com.tistory.top2blue.vo.Member;

import lombok.extern.slf4j.Slf4j;

@Controller
@Slf4j
@RequestMapping(value = "/members")
public class PersonController {
	@Autowired
	private MemberService memberService;
	
	@GetMapping(value = {"/","/list"})
	public String home(Model model) throws Exception {
		log.info("회원 목록보기");
		List<Member> memberList = memberService.findAll();
		log.info("회원 목록 리턴 : {}", memberList);
		model.addAttribute("list", memberList);
		return "member/list";
	}

	@GetMapping(value = {"/findByNameStartingWith"})
	public String findByNameStartingWith(@RequestParam(defaultValue = "한") String name,Model model) throws Exception {
		log.info("findByNameStartingWith({})", name);
		List<Member> memberList = memberService.findByNameStartingWith(name);
		log.info("findByNameStartingWith({}) : {}", name, memberList);
		model.addAttribute("list", memberList);
		return "member/list";
	}
	
	@GetMapping(value = {"/findByNameEndingWith"})
	public String findByNameEndingWith(@RequestParam(defaultValue = "사내") String name,Model model) throws Exception {
		log.info("findByNameEndingWith({})", name);
		List<Member> memberList = memberService.findByNameEndingWith(name);
		log.info("findByNameEndingWith({}) : {}", name, memberList);
		model.addAttribute("list", memberList);
		return "member/list";
	}
	
	@GetMapping(value = {"/findByNameContaining"})
	public String findByNameContaining(@RequestParam(defaultValue = "인") String name,Model model) throws Exception {
		log.info("findByNameContaining({})", name);
		List<Member> memberList = memberService.findByNameContaining(name);
		log.info("findByNameContaining({}) : {}", name, memberList);
		model.addAttribute("list", memberList);
		return "member/list";
	}
	
	@GetMapping(value = {"/findByNameLike1"})
	public String findByNameLike1(@RequestParam(defaultValue = "__간") String name,Model model) throws Exception {
		log.info("findByNameLike({})", name);
		List<Member> memberList = memberService.findByNameLike(name);
		log.info("findByNameLike({}) : {}", name, memberList);
		model.addAttribute("list", memberList);
		return "member/list";
	}
	
	@GetMapping(value = {"/findByNameLike2"})
	public String findByNameLike2(@RequestParam(defaultValue = "%인%") String name,Model model) throws Exception {
		log.info("findByNameLike({})", name);
		List<Member> memberList = memberService.findByNameLike(name);
		log.info("findByNameLike({}) : {}", name, memberList);
		model.addAttribute("list", memberList);
		return "member/list";
	}
	
}
