package com.tistory.top2blue.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.tistory.top2blue.service.MemberService;
import com.tistory.top2blue.vo.Member;

import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
@RequestMapping(value = "/api")
public class APIController {
	
	@Autowired
	private MemberService memberService;
	
	@GetMapping(value = {"/","/api","/members.xml"}, produces = MediaType.APPLICATION_XML_VALUE)
	public List<Member> home1() throws Exception {
		log.info("목록보기");
		return memberService.findAll();
	}
	@GetMapping(value = {"/members.json"}, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<Member> home2() throws Exception {
		log.info("목록보기");
		return memberService.findAll();
	}
	
}
