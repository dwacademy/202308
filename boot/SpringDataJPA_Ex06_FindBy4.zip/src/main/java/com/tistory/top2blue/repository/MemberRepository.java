package com.tistory.top2blue.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.tistory.top2blue.vo.Member;

/*
findBy~ 메서드 정의하기
-----------------------
유사 조건 키워드
속성 패턴으로 결과를 쿼리해야 하는 경우 몇 가지 옵션이 있습니다.

StartingWith 를 사용하여 값으로 시작하는 이름을 찾을 수 있습니다 .

List<User> findByNameStartingWith(String prefix);
대략 이것은 "WHERE name LIKE 'value%' " 로 번역됩니다 .

값으로 끝나는 이름을 원하는 경우 EndingWith 가 원하는 것입니다.

List<User> findByNameEndingWith(String suffix);
또는 Containing 을 사용하여 값을 포함하는 이름을 찾을 수 있습니다 .

List<User> findByNameContaining(String infix);
위의 모든 조건을 사전 정의된 패턴 표현식이라고 합니다. 
따라서 이러한 메서드가 호출될 때 인수 내에 %  연산자 를 추가할 필요가 없습니다 .

하지만 좀 더 복잡한 일을 한다고 가정해 봅시다. 
이름이 a 로 시작하고 b 를 포함 하고 c  로 끝나는  사용자를 가져와야 한다고 가정해 보겠습니다 .

이를 위해 Like 키워드 와 함께 자체 LIKE를 추가할 수 있습니다 .

List<User> findByNameLike(String likePattern);

그런 다음 메서드를 호출할 때 LIKE 패턴을 전달할 수 있습니다.

String likePattern = "a%b%c";
userRepository.findByNameLike(likePattern);
지금은 이름에 대해 충분합니다. User 에서 다른 값을 시도해 봅시다 .

*/
public interface MemberRepository extends CrudRepository<Member, Long> {
	// 시작
	List<Member> findByNameStartingWith(String prefix);
	// 종료
	List<Member> findByNameEndingWith(String suffix);
	// 포함
	List<Member> findByNameContaining(String infix);
	// like조건
	List<Member> findByNameLike(String likePattern);

}
