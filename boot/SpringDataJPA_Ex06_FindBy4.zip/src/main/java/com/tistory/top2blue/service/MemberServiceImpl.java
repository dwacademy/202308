package com.tistory.top2blue.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tistory.top2blue.repository.MemberRepository;
import com.tistory.top2blue.vo.Member;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service("memberService")
public class MemberServiceImpl implements MemberService {

	@Autowired
	private MemberRepository memberRepository;

	@Override
	public List<Member> findAll() {
		log.info("서비스 findAll() 호출");
		List<Member> list = new ArrayList<>();
		memberRepository.findAll().forEach(list::add);
		log.info("서비스 findAll() 리턴 : {}", list);
		return list;
	}

	@Override
	public List<Member> findByNameStartingWith(String prefix) {
		log.info("서비스 findByNameStartingWith({}) 호출", prefix);
		List<Member> list = new ArrayList<>();
		memberRepository.findByNameStartingWith(prefix).forEach(list::add);
		log.info("서비스 findByNameStartingWith({}) 리턴 : {}",prefix , list);
		return list;
	}

	@Override
	public List<Member> findByNameEndingWith(String suffix) {
		log.info("서비스 findByNameEndingWith({}) 호출", suffix);
		List<Member> list = new ArrayList<>();
		memberRepository.findByNameEndingWith(suffix).forEach(list::add);
		log.info("서비스 findByNameEndingWith({}) 리턴 : {}",suffix , list);
		return list;
	}

	@Override
	public List<Member> findByNameContaining(String infix) {
		log.info("서비스 findByNameContaining({}) 호출", infix);
		List<Member> list = new ArrayList<>();
		memberRepository.findByNameContaining(infix).forEach(list::add);
		log.info("서비스 findByNameContaining({}) 리턴 : {}",infix , list);
		return list;
	}

	@Override
	public List<Member> findByNameLike(String likePattern) {
		log.info("서비스 findByNameLike({}) 호출", likePattern);
		List<Member> list = new ArrayList<>();
		memberRepository.findByNameLike(likePattern).forEach(list::add);
		log.info("서비스 findByNameLike({}) 리턴 : {}", likePattern , list);
		return list;
	}
}
