package com.tistory.top2blue.repository;

import java.util.Collection;
import java.util.Date;
import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.tistory.top2blue.vo.Member;

/*

Spring Data JPA 저장소의 파생 쿼리 메서드

비교 조건 키워드
또한 LessThan 및 LessThanEqual 키워드를 사용하여 
< 및 <= 연산자 를 사용하여 레코드를 주어진 값과 비교할 수 있습니다.

List<Member> findByAgeLessThan(Integereger age);
List<Member> findByAgeLessThanEqual(Integereger age);
반대 상황에서는 GreaterThan 및 GreaterThanEqual 키워드를 사용할 수 있습니다.

List<Member> findByAgeGreaterThan(Integereger age);
List<Member> findByAgeGreaterThanEqual(Integereger age);
또는 Between 을 사용하여 두 연령대 사이의 사용자를 찾을 수 있습니다 .

List<Member> findByAgeBetween(Integereger startAge, Integereger endAge);
또한 In 사용에 대해 일치시킬 연령 컬렉션을 제공할 수 있습니다 .

List<Member> findByAgeIn(Collection<Integereger> ages);
사용자의 생년월일을 알고 있으므로 지정된 날짜 이전 또는 이후에 태어난 사용자를 쿼리할 수 있습니다.

이를 위해  Before 와  After 를 사용합니다.

List<Member> findByBirthDateAfter(ZonedDateTime birthDate);
List<Member> findByBirthDateBefore(ZonedDateTime birthDate);
List<Member> findByBirthDateBetween(LocalDate birthDate);


우선 순위는 Java와 마찬가지로 And then  Or 입니다.
Spring Data JPA는 우리가 추가할 수 있는 표현식의 수에 제한을 두지 않지만 여기서 미친 짓을 해서는 안 됩니다. 
긴 이름은 읽을 수 없고 유지하기 어렵습니다. 복잡한 쿼리 의 경우 대신 @Query 어노테이션을 살펴보세요 .
*/
public interface MemberRepository extends CrudRepository<Member, Long> {
	List<Member> findByAgeLessThan(Integer age);
	List<Member> findByAgeLessThanEqual(Integer age);
	
	List<Member> findByAgeGreaterThan(Integer age);
	List<Member> findByAgeGreaterThanEqual(Integer age);
	
	List<Member> findByAgeBetween(Integer startAge, Integer endAge);
	List<Member> findByAgeGreaterThanEqualAndAgeLessThanEqual(Integer startAge, Integer endAge);
	List<Member> findByAgeLessThanEqualOrAgeGreaterThanEqual(Integer startAge, Integer endAge);
	
	List<Member> findByAgeIn(Collection<Integer> ages);
	List<Member> findByAgeNotIn(Collection<Integer> ages);
	
	List<Member> findByBirthDateAfter(Date birthDate);
	List<Member> findByBirthDateBefore(Date birthDate);
	List<Member> findByBirthDateBetween(Date startDate, Date endDate);
}
