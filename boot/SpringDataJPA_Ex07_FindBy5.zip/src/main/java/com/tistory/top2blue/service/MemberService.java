package com.tistory.top2blue.service;

import java.util.Collection;
import java.util.Date;
import java.util.List;

import com.tistory.top2blue.vo.Member;

public interface MemberService {
	// 전체 얻기
	List<Member> findAll(); 
	
	// <, <=
	List<Member> findByAgeLessThan(Integer age);
	List<Member> findByAgeLessThanEqual(Integer age);
	
	//>, >=
	List<Member> findByAgeGreaterThan(Integer age);
	List<Member> findByAgeGreaterThanEqual(Integer age);
	
	// Between
	List<Member> findByAgeBetween(Integer startAge, Integer endAge);
	List<Member> findByAgeGreaterThanEqualAndAgeLessThanEqual(Integer startAge, Integer endAge);
	List<Member> findByAgeLessThanEqualOrAgeGreaterThanEqual(Integer startAge, Integer endAge);
	
	// IN, Not IN
	List<Member> findByAgeIn(Collection<Integer> ages);
	List<Member> findByAgeNotIn(Collection<Integer> ages);
	
	// Date타입
	List<Member> findByBirthDateAfter(Date birthDate);
	List<Member> findByBirthDateBefore(Date birthDate);
	List<Member> findByBirthDateBetween(Date startDate, Date endDate);
}
