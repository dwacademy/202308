package com.tistory.top2blue.service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tistory.top2blue.repository.MemberRepository;
import com.tistory.top2blue.vo.Member;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service("memberService")
public class MemberServiceImpl implements MemberService {

	@Autowired
	private MemberRepository memberRepository;

	@Override
	public List<Member> findAll() {
		log.info("서비스 findAll() 호출");
		List<Member> list = new ArrayList<>();
		memberRepository.findAll().forEach(list::add);
		log.info("서비스 findAll() 리턴 : {}", list);
		return list;
	}

	@Override
	public List<Member> findByAgeLessThan(Integer age) {
		log.info("서비스 findByAgeLessThan({}) 호출", age);
		List<Member> list = new ArrayList<>();
		memberRepository.findByAgeLessThan(age).forEach(list::add);
		log.info("서비스 findAll({}) 리턴 : {}", age, list);
		return list;
	}

	@Override
	public List<Member> findByAgeLessThanEqual(Integer age) {
		log.info("서비스 findByAgeLessThanEqual({}) 호출", age);
		List<Member> list = new ArrayList<>();
		memberRepository.findByAgeLessThanEqual(age).forEach(list::add);
		log.info("서비스 findByAgeLessThanEqual({}) 리턴 : {}", age, list);
		return list;
	}

	@Override
	public List<Member> findByAgeGreaterThan(Integer age) {
		log.info("서비스 findByAgeGreaterThan({}) 호출", age);
		List<Member> list = new ArrayList<>();
		memberRepository.findByAgeGreaterThan(age).forEach(list::add);
		log.info("서비스 findByAgeGreaterThan({}) 리턴 : {}", age, list);
		return list;
	}

	@Override
	public List<Member> findByAgeGreaterThanEqual(Integer age) {
		log.info("서비스 findByAgeGreaterThanEqual({}) 호출", age);
		List<Member> list = new ArrayList<>();
		memberRepository.findByAgeGreaterThanEqual(age).forEach(list::add);
		log.info("서비스 findByAgeGreaterThanEqual({}) 리턴 : {}", age, list);
		return list;
	}

	@Override
	public List<Member> findByAgeBetween(Integer startAge, Integer endAge) {
		log.info("서비스 findByAgeBetween({},{}) 호출", startAge, endAge);
		List<Member> list = new ArrayList<>();
		memberRepository.findByAgeBetween(startAge, endAge).forEach(list::add);
		log.info("서비스 findByAgeBetween({},{}) 리턴 : {}", startAge, endAge, list);
		return list;
	}

	@Override
	public List<Member> findByAgeGreaterThanEqualAndAgeLessThanEqual(Integer startAge, Integer endAge) {
		log.info("서비스 findByAgeGreaterThanEqualAndAgeLessThanEqual({},{}) 호출", startAge, endAge);
		List<Member> list = new ArrayList<>();
		memberRepository.findByAgeGreaterThanEqualAndAgeLessThanEqual(startAge, endAge).forEach(list::add);
		log.info("서비스 findByAgeGreaterThanEqualAndAgeLessThanEqual({},{}) 리턴 : {}", startAge, endAge, list);
		return list;
	}
	
	@Override
	public List<Member> findByAgeLessThanEqualOrAgeGreaterThanEqual(Integer startAge, Integer endAge) {
		log.info("서비스 findByAgeLessThanEqualOrAgeGreaterThanEqual({},{}) 호출", startAge, endAge);
		List<Member> list = new ArrayList<>();
		memberRepository.findByAgeLessThanEqualOrAgeGreaterThanEqual(startAge, endAge).forEach(list::add);
		log.info("서비스 findByAgeLessThanEqualOrAgeGreaterThanEqual({},{}) 리턴 : {}", startAge, endAge, list);
		return list;
	}

	@Override
	public List<Member> findByAgeIn(Collection<Integer> ages) {
		log.info("서비스 findByAgeIn({}) 호출", ages);
		List<Member> list = new ArrayList<>();
		memberRepository.findByAgeIn(ages).forEach(list::add);
		log.info("서비스 findByAgeIn({}) 리턴 : {}", ages, list);
		return list;
	}

	@Override
	public List<Member> findByAgeNotIn(Collection<Integer> ages) {
		log.info("서비스 findByAgeNotIn({}) 호출", ages);
		List<Member> list = new ArrayList<>();
		memberRepository.findByAgeNotIn(ages).forEach(list::add);
		log.info("서비스 findByAgeNotIn({}) 리턴 : {}", ages, list);
		return list;
	}

	@Override
	public List<Member> findByBirthDateAfter(Date birthDate) {
		log.info("서비스 findByBirthDateAfter({}) 호출", birthDate);
		List<Member> list = new ArrayList<>();
		memberRepository.findByBirthDateAfter(birthDate).forEach(list::add);
		log.info("서비스 findByBirthDateAfter({}) 리턴 : {}", birthDate, list);
		return list;
	}

	@Override
	public List<Member> findByBirthDateBefore(Date birthDate) {
		log.info("서비스 findByBirthDateBefore({}) 호출", birthDate);
		List<Member> list = new ArrayList<>();
		memberRepository.findByBirthDateBefore(birthDate).forEach(list::add);
		log.info("서비스 findByBirthDateBefore({}) 리턴 : {}", birthDate, list);
		return list;
	}

	@Override
	public List<Member> findByBirthDateBetween(Date startDate, Date endDate) {
		log.info("서비스 findByBirthDateBetween({},{}) 호출", startDate, endDate);
		List<Member> list = new ArrayList<>();
		memberRepository.findByBirthDateBetween( startDate, endDate).forEach(list::add);
		log.info("서비스 findByBirthDateBetween({},{}) 리턴 : {}",  startDate, endDate, list);
		return list;
	}

}
