package com.tistory.top2blue.controller;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.tistory.top2blue.service.MemberService;
import com.tistory.top2blue.vo.Member;

import lombok.extern.slf4j.Slf4j;

@Controller
@Slf4j
@RequestMapping(value = "/members")
public class PersonController {
	@Autowired
	private MemberService memberService;
	
	@GetMapping(value = {"/","/list"})
	public String findAll(Model model) throws Exception {
		log.info("컨트롤러 findAll() 호출");
		List<Member> memberList = memberService.findAll();
		log.info("컨트롤러 findAll() 리턴 : {}", memberList);
		model.addAttribute("list", memberList);
		return "member/list";
	}

	@GetMapping(value = {"/findByAgeLessThan"})
	public String findByAgeLessThan(@RequestParam(defaultValue = "20")int age, Model model) throws Exception {
		log.info("컨트롤러 findByAgeLessThan({}) 호출", age);
		List<Member> memberList = memberService.findByAgeLessThan(age);
		log.info("컨트롤러 findByAgeLessThan({}) 리턴 : {}", age, memberList);
		model.addAttribute("list", memberList);
		return "member/list";
	}
	
	@GetMapping(value = {"/findByAgeLessThanEqual"})
	public String findByAgeLessThanEqual(@RequestParam(defaultValue = "20")int age, Model model) throws Exception {
		log.info("컨트롤러 findByAgeLessThan({}) 호출", age);
		List<Member> memberList = memberService.findByAgeLessThanEqual(age);
		log.info("컨트롤러 findByAgeLessThanEqual({}) 리턴 : {}", age, memberList);
		model.addAttribute("list", memberList);
		return "member/list";
	}
	
	@GetMapping(value = {"/findByAgeGreaterThan"})
	public String findByAgeGreaterThan(@RequestParam(defaultValue = "20")int age, Model model) throws Exception {
		log.info("컨트롤러 findByAgeGreaterThan({}) 호출", age);
		List<Member> memberList = memberService.findByAgeGreaterThan(age);
		log.info("컨트롤러 findByAgeGreaterThan({}) 리턴 : {}", age, memberList);
		model.addAttribute("list", memberList);
		return "member/list";
	}
	
	@GetMapping(value = {"/findByAgeGreaterThanEqual"})
	public String findByAgeGreaterThanEqual(@RequestParam(defaultValue = "20")int age, Model model) throws Exception {
		log.info("컨트롤러 findByAgeGreaterThanEqual({}) 호출", age);
		List<Member> memberList = memberService.findByAgeGreaterThanEqual(age);
		log.info("컨트롤러 findByAgeGreaterThanEqual({}) 리턴 : {}", age, memberList);
		model.addAttribute("list", memberList);
		return "member/list";
	}
	
	@GetMapping(value = {"/findByAgeBetween"})
	public String findByAgeBetween(@RequestParam(defaultValue = "20")int startAge,@RequestParam(defaultValue = "25")int endAge, Model model) throws Exception {
		log.info("컨트롤러 findByAgeBetween({},{}) 호출", startAge, endAge);
		List<Member> memberList = memberService.findByAgeBetween(startAge, endAge);
		log.info("컨트롤러 findByAgeBetween({},{}) 리턴 : {}", startAge, endAge, memberList);
		model.addAttribute("list", memberList);
		return "member/list";
	}
	
	@GetMapping(value = {"/findByAgeGreaterThanEqualAndAgeLessThanEqual"})
	public String findByAgeGreaterThanEqualAndAgeLessThanEqual(@RequestParam(defaultValue = "20")int startAge,@RequestParam(defaultValue = "25")int endAge, Model model) throws Exception {
		log.info("컨트롤러 findByAgeGreaterThanEqualAndAgeLessThanEqual({},{}) 호출", startAge, endAge);
		List<Member> memberList = memberService.findByAgeGreaterThanEqualAndAgeLessThanEqual(startAge, endAge);
		log.info("컨트롤러 findByAgeGreaterThanEqualAndAgeLessThanEqual({},{}) 리턴 : {}", startAge, endAge, memberList);
		model.addAttribute("list", memberList);
		return "member/list";
	}
	
	@GetMapping(value = {"/findByAgeLessThanEqualOrAgeGreaterThanEqual"})
	public String findByAgeLessThanEqualOrAgeGreaterThanEqual(@RequestParam(defaultValue = "20")int startAge,@RequestParam(defaultValue = "25")int endAge, Model model) throws Exception {
		log.info("컨트롤러 findByAgeLessThanEqualOrAgeGreaterThanEqual({},{}) 호출", startAge, endAge);
		List<Member> memberList = memberService.findByAgeLessThanEqualOrAgeGreaterThanEqual(startAge, endAge);
		log.info("컨트롤러 findByAgeLessThanEqualOrAgeGreaterThanEqual({},{}) 리턴 : {}", startAge, endAge, memberList);
		model.addAttribute("list", memberList);
		return "member/list";
	}
	
	@GetMapping(value = {"/findByAgeIn"})
	public String findByAgeIn(@RequestParam List<Integer> ages, Model model) throws Exception {
		log.info("컨트롤러 findByAgeIn({}) 호출", ages);
		List<Member> memberList = memberService.findByAgeIn(ages);
		log.info("컨트롤러 findByAgeIn({}) 리턴 : {}", ages, memberList);
		model.addAttribute("list", memberList);
		return "member/list";
	}
	
	@GetMapping(value = {"/findByAgeNotIn"})
	public String findByAgeNotIn(@RequestParam List<Integer> ages, Model model) throws Exception {
		log.info("컨트롤러 findByAgeNotIn({}) 호출", ages);
		List<Member> memberList = memberService.findByAgeNotIn(ages);
		log.info("컨트롤러 findByAgeNotIn({}) 리턴 : {}", ages, memberList);
		model.addAttribute("list", memberList);
		return "member/list";
	}
	
	@GetMapping(value = {"/findByBirthDateAfter"})
	public String findByBirthDateAfter(@RequestParam @DateTimeFormat(pattern = "yyyy-MM-dd")Date birthDate, Model model) throws Exception {
		log.info("컨트롤러 findByBirthDateAfter({}) 호출", birthDate);
		List<Member> memberList = memberService.findByBirthDateAfter(birthDate);
		log.info("컨트롤러 findByBirthDateAfter({}) 리턴 : {}", birthDate, memberList);
		model.addAttribute("list", memberList);
		return "member/list";
	}
	
	@GetMapping(value = {"/findByBirthDateBefore"})
	public String findByBirthDateBefore(@RequestParam @DateTimeFormat(pattern = "yyyy-MM-dd")Date birthDate, Model model) throws Exception {
		log.info("컨트롤러 findByBirthDateBefore({}) 호출", birthDate);
		List<Member> memberList = memberService.findByBirthDateBefore(birthDate);
		log.info("컨트롤러 findByBirthDateBefore({}) 리턴 : {}", birthDate, memberList);
		model.addAttribute("list", memberList);
		return "member/list";
	}
	
	@GetMapping(value = {"/findByBirthDateBetween"})
	public String findByBirthDateBetween(@RequestParam @DateTimeFormat(pattern = "yyyy-MM-dd")Date startDate,@RequestParam @DateTimeFormat(pattern = "yyyy-MM-dd")Date endDate, Model model) throws Exception {
		log.info("컨트롤러 findByBirthDateBetween({}) 호출", startDate, endDate);
		List<Member> memberList = memberService.findByBirthDateBetween(startDate, endDate);
		log.info("컨트롤러 findByBirthDateBetween({}) 리턴 : {}", startDate, endDate);
		model.addAttribute("list", memberList);
		return "member/list";
	}
	
}
