package com.tistory.top2blue;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.tistory.top2blue.repository.MemberRepository;

@SpringBootTest
class SpringDataJPAEx07FindBy5Tests {
	
	@Autowired
	MemberRepository memberRepository;
	
	@Test
	void findByName() {
		
	}	
}
