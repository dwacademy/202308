package kr.human.core.hello.vo;

public interface HelloWorld {
	void sayHello(String name);
}
