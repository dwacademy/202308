package com.tistory.top2blue.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.tistory.top2blue.service.MemberService;
import com.tistory.top2blue.vo.Member;

import lombok.extern.slf4j.Slf4j;

@Controller
@Slf4j
@RequestMapping(value = "/members")
public class PersonController {
	@Autowired
	private MemberService memberService;
	
	@GetMapping(value = {"/","/list"})
	public String home(Model model) throws Exception {
		log.info("회원 목록보기");
		List<Member> memberList = memberService.findAll();
		log.info("회원 목록 리턴 : {}", memberList);
		model.addAttribute("list", memberList);
		return "member/list";
	}

	@GetMapping(value = {"/findByOrderByIdxAsc"})
	public String findByOrderByIdAsc(Model model) throws Exception {
		log.info("findByOrderByIdAsc() 호출");
		List<Member> memberList = memberService.findByOrderByIdxAsc();
		log.info("findByOrderByIdAsc 리턴 : {}", memberList);
		model.addAttribute("list", memberList);
		return "member/list";
	}

	@GetMapping(value = {"/findByOrderByIdxDesc"})
	public String findByOrderByIdDesc(Model model) throws Exception {
		log.info("findByOrderByIdDesc() 호출");
		List<Member> memberList = memberService.findByOrderByIdxDesc();
		log.info("findByOrderByIdDesc 리턴 : {}", memberList);
		model.addAttribute("list", memberList);
		return "member/list";
	}
	
	@GetMapping(value = {"/findByOrderByGenderDescAgeAsc"})
	public String findByOrderByGenderDescAgeAsc(Model model) throws Exception {
		log.info("findFirst2ByGenderOrderByAgeAsc() 호출");
		List<Member> memberList = memberService.findByOrderByGenderDescAgeAsc();
		log.info("findByOrderByGenderDescAgeAsc 리턴 : {}", memberList);
		model.addAttribute("list", memberList);
		return "member/list";
	}
	
	@GetMapping(value = {"/findByOrderByGenderAscAgeDesc"})
	public String findByOrderByGenderAscAgeDesc(Model model) throws Exception {
		log.info("findFirst2ByGenderOrderByAgeDesc() 호출");
		List<Member> memberList = memberService.findByOrderByGenderAscAgeDesc();
		log.info("findByOrderByGenderAscAgeDesc 리턴 : {}", memberList);
		model.addAttribute("list", memberList);
		return "member/list";
	}
	

	
	@GetMapping(value = {"/findTopBy"})
	public String findTopBy(Model model) throws Exception {
		log.info("findTopBy() 호출");
		List<Member> memberList = memberService.findTopBy();
		log.info("findTopBy 리턴 : {}", memberList);
		model.addAttribute("list", memberList);
		return "member/list";
	}
	
	@GetMapping(value = {"/findTop3By"})
	public String findTop3By(Model model) throws Exception {
		log.info("findTop3By() 호출");
		List<Member> memberList = memberService.findTop3By();
		log.info("findTop3By 리턴 : {}", memberList);
		model.addAttribute("list", memberList);
		return "member/list";
	}

	@GetMapping(value = {"/findFirstBy"})
	public String findFirstBy(Model model) throws Exception {
		log.info("findFirstBy() 호출");
		List<Member> memberList = memberService.findFirstBy();
		log.info("findFirstBy 리턴 : {}", memberList);
		model.addAttribute("list", memberList);
		return "member/list";
	}
	
	@GetMapping(value = {"/findFirst5By"})
	public String findFirst5By(Model model) throws Exception {
		log.info("findFirst5By() 호출");
		List<Member> memberList = memberService.findFirst5By();
		log.info("findFirst5By 리턴 : {}", memberList);
		model.addAttribute("list", memberList);
		return "member/list";
	}
	
	@GetMapping(value = {"/findFirst5ByOrderByNameAsc"})
	public String findFirst5ByOrderByNameAsc(Model model) throws Exception {
		log.info("findFirst5ByOrderByNameAsc() 호출");
		List<Member> memberList = memberService.findFirst5ByOrderByNameAsc();
		log.info("findFirst5ByOrderByNameAsc 리턴 : {}", memberList);
		model.addAttribute("list", memberList);
		return "member/list";
	}
	
	@GetMapping(value = {"/findFirst5ByOrderByNameDesc"})
	public String findFirst5ByOrderByNameDesc(Model model) throws Exception {
		log.info("findFirst5ByOrderByNameDesc() 호출");
		List<Member> memberList = memberService.findFirst5ByOrderByNameDesc();
		log.info("findFirst5ByOrderByNameDesc 리턴 : {}", memberList);
		model.addAttribute("list", memberList);
		return "member/list";
	}
	
	@GetMapping(value = {"/findFirst2ByGenderOrderByAgeAsc"})
	public String findFirst2ByGenderOrderByAgeAsc(Model model) throws Exception {
		log.info("findFirst2ByGenderOrderByAgeAsc() 호출");
		List<Member> memberList = memberService.findFirst2ByGenderOrderByAgeAsc(true);
		log.info("findFirst2ByGenderOrderByAgeAsc 리턴 : {}", memberList);
		model.addAttribute("list", memberList);
		return "member/list";
	}
	
	@GetMapping(value = {"/findFirst2ByGenderOrderByAgeDesc"})
	public String findFirst2ByGenderOrderByAgeDesc(Model model) throws Exception {
		log.info("findFirst2ByGenderOrderByAgeDesc() 호출");
		List<Member> memberList = memberService.findFirst2ByGenderOrderByAgeDesc(false);
		log.info("findFirst2ByGenderOrderByAgeDesc 리턴 : {}", memberList);
		model.addAttribute("list", memberList);
		return "member/list";
	}
	
}
