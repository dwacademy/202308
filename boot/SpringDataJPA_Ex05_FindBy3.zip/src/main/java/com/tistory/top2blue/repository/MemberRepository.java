package com.tistory.top2blue.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.tistory.top2blue.vo.Member;

/*
findBy~ 메서드 정의하기
-----------------------
기본적으로 기본키 필드를 기준으로 findById가 생성된다. 필드명이 달라도 된다. 
여기 예는 기본키 필드를 idx로 했다. 잘 작동된다.

findByXX => SQL Where절이라고 생각하자.
findBy뒤에 우리가 정의한 Entity의 이름을 붙이면된다.
Entity의 이름의 첫글자는 대문자로 하며, id를 조건으로 검색한다면 findById(int id) 로 검색하면 된다.
여기서 여러개의 조건을 걸고싶다면...?

And조건
findByIdAndName(int id, String name)으로 And를 사용하여 검색한다.

OR 조건
findByIdOrName(int id, String name)으로 Or을 사용하여 검색한다.

Not은 isNot을 붙인다.

findTopBy
findTopNBy

findFirstBy
findFirstNBy

*/
public interface MemberRepository extends CrudRepository<Member, Long> {
	List<Member> findByOrderByIdxAsc();
	List<Member> findByOrderByIdxDesc();
	
	List<Member> findByOrderByGenderDescAgeAsc();
	List<Member> findByOrderByGenderAscAgeDesc();

	List<Member> findTopBy();
	List<Member> findTop3By();

	List<Member> findFirstBy();
	List<Member> findFirst5By();
	
	List<Member> findFirst5ByOrderByNameAsc();
	List<Member> findFirst5ByOrderByNameDesc();

	List<Member> findFirst2ByGenderOrderByAgeAsc(boolean gender);
	List<Member> findFirst2ByGenderOrderByAgeDesc(boolean gender);

}
