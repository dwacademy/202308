package com.tistory.top2blue.service;

import java.util.List;

import com.tistory.top2blue.vo.Member;

public interface MemberService {
	// 전체 얻기
	List<Member> findAll(); 
	
	List<Member> findByOrderByIdxAsc();
	List<Member> findByOrderByIdxDesc();
	
	List<Member> findByOrderByGenderDescAgeAsc();
	List<Member> findByOrderByGenderAscAgeDesc();
	
	List<Member> findTopBy();
	List<Member> findTop3By();

	List<Member> findFirstBy();
	List<Member> findFirst5By();
	
	List<Member> findFirst5ByOrderByNameAsc();
	List<Member> findFirst5ByOrderByNameDesc();
	
	List<Member> findFirst2ByGenderOrderByAgeAsc(boolean gender);
	List<Member> findFirst2ByGenderOrderByAgeDesc(boolean gender);
}
