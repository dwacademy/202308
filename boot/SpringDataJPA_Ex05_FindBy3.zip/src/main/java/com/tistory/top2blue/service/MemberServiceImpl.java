package com.tistory.top2blue.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tistory.top2blue.repository.MemberRepository;
import com.tistory.top2blue.vo.Member;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service("memberService")
public class MemberServiceImpl implements MemberService {

	@Autowired
	private MemberRepository memberRepository;

	@Override
	public List<Member> findAll() {
		log.info("서비스 findAll() 호출");
		List<Member> list = new ArrayList<>();
		memberRepository.findAll().forEach(list::add);
		log.info("서비스 findAll() 리턴 : {}", list);
		return list;
	}

	@Override
	public List<Member> findByOrderByIdxAsc() {
		log.info("서비스 findByOrderByIdAsc() 호출");
		List<Member> list = memberRepository.findByOrderByIdxAsc();
		log.info("서비스 findByOrderByIdAsc() 리턴 : {}", list);
		return list;
	}

	@Override
	public List<Member> findByOrderByIdxDesc() {
		log.info("서비스 findByOrderByIdDesc() 호출");
		List<Member> list = memberRepository.findByOrderByIdxDesc();
		log.info("서비스 findByOrderByIdDesc() 리턴 : {}", list);
		return list;
	}
	
	@Override
	public List<Member> findByOrderByGenderDescAgeAsc() {
		log.info("서비스 findByOrderByGenderDescAgeAsc() 호출");
		List<Member> list = memberRepository.findByOrderByGenderDescAgeAsc();
		log.info("서비스 findByOrderByGenderDescAgeAsc() 리턴 : {}", list);
		return list;
	}

	@Override
	public List<Member> findByOrderByGenderAscAgeDesc() {
		log.info("서비스 findByOrderByGenderAscAgeDesc() 호출");
		List<Member> list = memberRepository.findByOrderByGenderAscAgeDesc();
		log.info("서비스 findByOrderByGenderAscAgeDesc() 리턴 : {}", list);
		return list;
	}


	@Override
	public List<Member> findTopBy() {
		log.info("서비스 findTopBy() 호출");
		List<Member> list = memberRepository.findTopBy();
		log.info("서비스 findTopBy() 리턴 : {}", list);
		return list;
	}

	@Override
	public List<Member> findTop3By() {
		log.info("서비스 findTop3By() 호출");
		List<Member> list = memberRepository.findTop3By();
		log.info("서비스 findTop3By() 리턴 : {}", list);
		return list;
	}

	@Override
	public List<Member> findFirstBy() {
		log.info("서비스 findFirstBy() 호출");
		List<Member> list = memberRepository.findFirstBy();
		log.info("서비스 findFirstBy() 리턴 : {}", list);
		return list;
	}

	@Override
	public List<Member> findFirst5By() {
		log.info("서비스 findFirst5By() 호출");
		List<Member> list = memberRepository.findFirst5By();
		log.info("서비스 findFirst5By() 리턴 : {}", list);
		return list;
	}

	@Override
	public List<Member> findFirst5ByOrderByNameAsc() {
		log.info("서비스 findFirst5ByOrderByNameAsc() 호출");
		List<Member> list = memberRepository.findFirst5ByOrderByNameAsc();
		log.info("서비스 findFirst5ByOrderByNameAsc() 리턴 : {}", list);
		return list;
	}

	@Override
	public List<Member> findFirst5ByOrderByNameDesc() {
		log.info("서비스 findFirst5ByOrderByNameDesc() 호출");
		List<Member> list = memberRepository.findFirst5ByOrderByNameDesc();
		log.info("서비스 findFirst5ByOrderByNameDesc() 리턴 : {}", list);
		return list;
	}

	@Override
	public List<Member> findFirst2ByGenderOrderByAgeAsc(boolean gender) {
		log.info("서비스 findFirst2ByGenderOrderByAgeAsc() 호출");
		List<Member> list = memberRepository.findFirst2ByGenderOrderByAgeAsc(gender);
		log.info("서비스 findFirst2ByGenderOrderByAgeAsc() 리턴 : {}", list);
		return list;
	}

	@Override
	public List<Member> findFirst2ByGenderOrderByAgeDesc(boolean gender) {
		log.info("서비스 findFirst2ByGenderOrderByAgeDesc() 호출");
		List<Member> list = memberRepository.findFirst2ByGenderOrderByAgeDesc(gender);
		log.info("서비스 findFirst2ByGenderOrderByAgeDesc() 리턴 : {}", list);
		return list;
	}

}
