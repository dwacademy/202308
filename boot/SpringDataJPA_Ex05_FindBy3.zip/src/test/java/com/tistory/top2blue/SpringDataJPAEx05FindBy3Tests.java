package com.tistory.top2blue;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringDataJPAEx05FindBy3Tests {

	@Test
	void contextLoads() {
	}

}
