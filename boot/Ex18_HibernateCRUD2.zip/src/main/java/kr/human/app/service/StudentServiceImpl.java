package kr.human.app.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import kr.human.app.dao.StudentDAO;
import kr.human.app.vo.StudentVO;

@Service("studentService")
public class StudentServiceImpl implements StudentService{

	@Autowired
	private StudentDAO studentDAO;

	@Override
	public void insert(StudentVO studentVO) {
		studentDAO.insert(studentVO);
	}
	@Override
	public List<StudentVO> selectList() {
		return studentDAO.selectList();
	}
	@Override
	public void update(StudentVO studentVO) {
		studentDAO.update(studentVO);
	}
	@Override
	public void delete(int idx) {
		studentDAO.delete(idx);
	}
	@Override
	public StudentVO selectByIdx(int idx) {
		return studentDAO.selectByIdx(idx);
	}
}
