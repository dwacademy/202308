package kr.human.app.main;

import java.util.List;
import java.util.Random;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import kr.human.app.service.StudentService;
import kr.human.app.vo.StudentVO;

public class AppMain {
	public static void main(String[] args) {
		AbstractApplicationContext context = new ClassPathXmlApplicationContext("AppConfig.xml");
		
		StudentService service = context.getBean("studentService", StudentService.class);
		
		// 저장
		service.insert(new StudentVO(0, "한사람", "자바 프로그래머"));
		service.insert(new StudentVO(0, "두사람", "SQL 프로그래머"));
		service.insert(new StudentVO(0, "세사람", "자바 프로그래머"));
		
		// 읽기
		List<StudentVO> list = service.selectList();
		System.out.println("-".repeat(40));
		System.out.println(list.size() + "명!!!");
		for(StudentVO vo : list) {
			System.out.println(vo);
		}
		System.out.println("-".repeat(40));
		
		// 수정
		Random rnd = new Random();
		int idx = rnd.nextInt(10)+1;
		StudentVO studentVO = service.selectByIdx(idx);
		if(studentVO!=null) {
			System.out.println("변경전 " + idx + "번 학생 : " + studentVO);
			studentVO.setSection("특특급 프로그래머");
			service.update(studentVO);
			studentVO = service.selectByIdx(2);
			System.out.println("변경후 " + idx + "번 학생 : " + studentVO);
		}else {
			System.out.println(idx + "번 학생은 없습니다.");
		}
		
		// 삭제
		try {
			for(int i=0;i<3;i++) {
				idx = rnd.nextInt(10)+1;
				service.delete(idx);
				System.out.println(idx + "번 학생 삭제 성공.");
			}
		}catch (Exception e) {
			System.out.println(idx + "번 학생은 없습니다.");
		}
		
		// 읽기
		list = service.selectList();
		System.out.println("-".repeat(40));
		System.out.println(list.size() + "명!!!");
		for(StudentVO vo : list) {
			System.out.println(vo);
		}
		System.out.println("-".repeat(40));
		context.close();
	}
}
