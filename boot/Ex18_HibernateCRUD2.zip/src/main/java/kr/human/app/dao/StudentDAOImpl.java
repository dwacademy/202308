package kr.human.app.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import kr.human.app.vo.StudentVO;

@Repository("studentDAO")
@Transactional // 트랜젝션 처리를 해줘라!!!
public class StudentDAOImpl implements StudentDAO {

	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public void insert(StudentVO studentVO) {
		sessionFactory.openSession().save(studentVO);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<StudentVO> selectList() {
		return sessionFactory.openSession().createCriteria(StudentVO.class).list();
	}

	@Override
	public void update(StudentVO studentVO) {
		// 수동으로 트랜젝션을 한다면 다음과 같이 한다.
		Session session = sessionFactory.openSession();
		try {
			session.beginTransaction();
			// --------------------------------------------------------
			StudentVO vo = session.get(StudentVO.class, studentVO.getIdx());
			vo.setName(studentVO.getName());
			vo.setSection(studentVO.getSection());
			session.update(vo);
			// --------------------------------------------------------
			session.getTransaction().commit();
		} catch (Exception e) {
			session.getTransaction().rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}
	}

	@Override
	public void delete(int idx) {
		// 수동으로 트랜젝션을 한다면 다음과 같이 한다.
		Session session = sessionFactory.openSession();
		try {
			session.beginTransaction();
			// --------------------------------------------------------
			StudentVO vo = session.get(StudentVO.class, idx);
			session.delete(vo);
			// --------------------------------------------------------
			session.getTransaction().commit();
		} catch (Exception e) {
			session.getTransaction().rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}
	}

	@Override
	public StudentVO selectByIdx(int idx) {
		return sessionFactory.openSession().find(StudentVO.class, idx);
	}

}
