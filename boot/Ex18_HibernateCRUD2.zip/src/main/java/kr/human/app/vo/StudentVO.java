package kr.human.app.vo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/*
create table student(
	idx INT primary key auto_increment, 
	name VARCHAR(50) NOT NULL,
	section VARCHAR(50) NOT NULL
);
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name="STUDENT")
public class StudentVO {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int idx;
	@Column(name = "NAME", nullable = false)
	private String name;
	@Column(name = "SECTION", nullable = false)
	private String section;
}
