package com.tistory.top2blue.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tistory.top2blue.repository.MemberRepository;
import com.tistory.top2blue.vo.Member;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service("memberService")
public class MemberServiceImpl implements MemberService {

	@Autowired
	private MemberRepository memberRepository;

	@Override
	public List<Member> findAll() {
		log.info("서비스 findAll() 호출");
		List<Member> list = new ArrayList<>();
		memberRepository.findAll().forEach(list::add);
		log.info("서비스 findAll() 리턴 : {}", list);
		return list;
	}

	@Override
	public List<Member> findByName(String name) {
		log.info("서비스 findByName() 호출");
		List<Member> members = memberRepository.findByName(name);
		log.info("서비스 findByName() 리턴 : {}", members);
		return members;
	}

	@Override
	public List<Member> findByGender(boolean gender) {
		log.info("서비스 findByGender({}) 호출", gender);
		List<Member> members = memberRepository.findByGender(gender);
		log.info("서비스 findByGender({}) 리턴 : {}", gender, members);
		return members;
	}

	@Override
	public List<Member> findByNameIsNot(String name) {
		log.info("서비스 findByNameIsNot({}) 호출", name);
		List<Member> members = memberRepository.findByNameIsNot(name);
		log.info("서비스 findByNameIsNot({}) 리턴 : {}", name, members);
		return members;
	}
	
	@Override
	public List<Member> findByGenderIsNot(boolean gender) {
		log.info("서비스 findByGenderIsNot({}) 호출", gender);
		List<Member> members = memberRepository.findByGenderIsNot(gender);
		log.info("서비스 findByGenderIsNot({}) 리턴 : {}", gender, members);
		return members;
	}

	@Override
	public List<Member> findByGenderTrue() {
		log.info("서비스 findByGenderTrue() 호출");
		List<Member> members = memberRepository.findByGenderTrue();
		log.info("서비스 findByGenderTrue() 리턴 : {}", members);
		return members;
	}

	@Override
	public List<Member> findByGenderFalse() {
		log.info("서비스 findByGenderFalse() 호출");
		List<Member> members = memberRepository.findByGenderFalse();
		log.info("서비스 findByGenderFalse() 리턴 : {}", members);
		return members;
	}
	
	@Override
	public List<Member> findByNameIsNull() {
		log.info("서비스 findByNameIsNull() 호출");
		List<Member> members = memberRepository.findByNameIsNull();
		log.info("서비스 findByNameIsNull() 리턴 : {}", members);
		return members;
	}

	@Override
	public List<Member> findByNameIsNotNull() {
		log.info("서비스 findByNameIsNotNull() 호출");
		List<Member> members = memberRepository.findByNameIsNotNull();
		log.info("서비스 findByNameIsNotNull() 리턴 : {}", members);
		return members;
	}


	@Override
	public List<Member> findByNameAndGender(String name, boolean gender) {
		log.info("서비스 findByNameAndGender({},{}) 호출", name, gender);
		List<Member> members = memberRepository.findByNameAndGender(name, gender);
		log.info("서비스 findByNameAndGender() 리턴 : {}", members);
		return members;
	}

	@Override
	public List<Member> findByNameOrGender(String name, boolean gender) {
		log.info("서비스 findByNameOrGender({},{}) 호출", name, gender);
		List<Member> members = memberRepository.findByNameOrGender(name, gender);
		log.info("서비스 findByNameOrGender() 리턴 : {}", members);
		return members;
	}

	@Override
	public List<Member> findByNameIsNotAndGenderIsNot(String name, boolean gender) {
		log.info("서비스 findByNameIsNotAndGenderIsNot({},{}) 호출", name, gender);
		List<Member> members = memberRepository.findByNameIsNotAndGenderIsNot(name, gender);
		log.info("서비스 findByNameIsNotAndGenderIsNot() 리턴 : {}", members);
		return members;
	}
}
