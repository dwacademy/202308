package com.tistory.top2blue.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.tistory.top2blue.service.MemberService;
import com.tistory.top2blue.vo.Member;

import lombok.extern.slf4j.Slf4j;

@Controller
@Slf4j
@RequestMapping(value = "/members")
public class PersonController {
	@Autowired
	private MemberService memberService;
	
	@GetMapping(value = {"/","/list"})
	public String home(Model model) throws Exception {
		log.info("회원 목록보기");
		List<Member> memberList = memberService.findAll();
		log.info("회원 목록 리턴 : {}", memberList);
		model.addAttribute("list", memberList);
		return "member/list";
	}

	@PostMapping(value = {"/findByName"})
	public String findByName(@RequestParam String name, Model model) {
		log.info("findByName({}) 호출", name);
		List<Member> memberList = memberService.findByName(name);
		log.info("findByName({}) 리턴 : {}", name, memberList);
		model.addAttribute("list", memberList);
		return "member/list";
	}

	@PostMapping(value = {"/findByGender"})
	public String findByGender(@RequestParam boolean gender, Model model) {
		log.info("findByGender({}) 호출", gender);
		List<Member> memberList = memberService.findByGender(gender);
		log.info("findByGender({}) 리턴 : {}", gender, memberList);
		model.addAttribute("list", memberList);
		return "member/list";
	}
	
	@PostMapping(value = {"/findByNameIsNot"})
	public String findByNameIsNot(@RequestParam String name, Model model) {
		log.info("findByNameIsNot({}) 호출", name);
		List<Member> memberList = memberService.findByNameIsNot(name);
		log.info("findByNameIsNot({}) 리턴 : {}", name, memberList);
		model.addAttribute("list", memberList);
		return "member/list";
	}

	@PostMapping(value = {"/findByGenderIsNot"})
	public String findByGenderIsNot(@RequestParam boolean gender, Model model) {
		log.info("findByGenderIsNot({}) 호출", gender);
		List<Member> memberList = memberService.findByGenderIsNot(gender);
		log.info("findByGenderIsNot({}) 리턴 : {}", gender, memberList);
		model.addAttribute("list", memberList);
		return "member/list";
	}

	@GetMapping(value = {"/findByGenderTrue"})
	public String findByGenderTrue(Model model) {
		log.info("findByGenderTrue() 호출");
		List<Member> memberList = memberService.findByGenderTrue();
		log.info("findByGenderTrue() 리턴 : {}", memberList);
		model.addAttribute("list", memberList);
		return "member/list";
	}
	
	
	@GetMapping(value = {"/findByGenderFalse"})
	public String findByGenderFalse(Model model) {
		log.info("findByGenderFalse() 호출");
		List<Member> memberList = memberService.findByGenderFalse();
		log.info("findByGenderFalse() 리턴 : {}", memberList);
		model.addAttribute("list", memberList);
		return "member/list";
	}
	
	@GetMapping(value = {"/findByNameIsNull"})
	public String findByNameIsNull(Model model) {
		log.info("findByNameIsNull() 호출");
		List<Member> memberList = memberService.findByNameIsNull();
		log.info("findByNameIsNull() 리턴 : {}", memberList);
		model.addAttribute("list", memberList);
		return "member/list";
	}
	
	
	@GetMapping(value = {"/findByNameIsNotNull"})
	public String findByNameIsNotNull(Model model) {
		log.info("findByNameIsNotNull() 호출");
		List<Member> memberList = memberService.findByNameIsNotNull();
		log.info("findByNameIsNotNull() 리턴 : {}", memberList);
		model.addAttribute("list", memberList);
		return "member/list";
	}
	
	@PostMapping(value = {"/findByNameAndGender"})
	public String findByNameAndGender(@RequestParam String name, @RequestParam boolean gender, Model model) {
		log.info("findByNameAndGender({},{}) 호출", name, gender);
		List<Member> memberList = memberService.findByNameAndGender(name, gender);
		log.info("findByNameAndGender({},{}) 리턴 : {}", name, gender, memberList);
		model.addAttribute("list", memberList);
		return "member/list";
	}
	
	@PostMapping(value = {"/findByNameOrGender"})
	public String findByNameOrGender(@RequestParam String name, @RequestParam boolean gender, Model model) {
		log.info("findByNameOrGender({},{}) 호출", name, gender);
		List<Member> memberList = memberService.findByNameOrGender(name, gender);
		log.info("findByNameOrGender({},{}) 리턴 : {}", name, gender, memberList);
		model.addAttribute("list", memberList);
		return "member/list";
	}
	
	@PostMapping(value = {"/findByNameIsNotAndGenderIsNot"})
	public String findByNameOrGenderIsNot(@RequestParam String name, @RequestParam boolean gender, Model model) {
		log.info("findByNameIsNotAndGenderIsNot({},{}) 호출", name, gender);
		List<Member> memberList = memberService.findByNameIsNotAndGenderIsNot(name, gender);
		log.info("findByNameIsNotAndGenderIsNot({},{}) 리턴 : {}", name, gender, memberList);
		model.addAttribute("list", memberList);
		return "member/list";
	}
	
}
