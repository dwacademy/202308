package com.tistory.top2blue.service;

import java.util.List;

import com.tistory.top2blue.vo.Member;

public interface MemberService {
	// 전체 얻기
	List<Member> findAll(); 
	
	// 필드값으로 찾기
	List<Member> findByName(String name);
	List<Member> findByGender(boolean gender);
	
	// NOT
	List<Member> findByNameIsNot(String name);
	List<Member> findByGenderIsNot(boolean gender);
	
	// boolean값
	List<Member> findByGenderTrue();
	List<Member> findByGenderFalse();
	
	// null 조건
	List<Member> findByNameIsNull();
	List<Member> findByNameIsNotNull();
	
	// AND/OR 사용하여 찾기
	List<Member> findByNameAndGender(String name, boolean gender);
	List<Member> findByNameOrGender(String name, boolean gender);
	
	// NOT
	List<Member> findByNameIsNotAndGenderIsNot(String name, boolean gender);
}
