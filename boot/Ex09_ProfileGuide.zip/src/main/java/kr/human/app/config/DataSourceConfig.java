package kr.human.app.config;

import javax.sql.DataSource;

public interface DataSourceConfig {
	DataSource getDataSource();
}
