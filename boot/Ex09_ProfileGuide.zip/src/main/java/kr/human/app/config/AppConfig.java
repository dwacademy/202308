package kr.human.app.config;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration // 환경설정 파일이다.
@ComponentScan(basePackages = {"kr.human.app"}) // 자동으로 검색해서 객체를 등록해라
public class AppConfig {

	@Autowired
	public DataSource dataSource;
	
}
