package kr.human.app.main;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class AppMain02 {
	public static void main(String[] args) {
		AbstractApplicationContext context = new ClassPathXmlApplicationContext("AppConfig.xml");
		
		//context.getEnvironment().setActiveProfiles("Development");
		context.getEnvironment().setActiveProfiles("Production");
		context.refresh();
		
		
		context.close();
	}
}
