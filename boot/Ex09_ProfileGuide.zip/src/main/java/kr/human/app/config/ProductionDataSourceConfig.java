package kr.human.app.config;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.context.annotation.PropertySource;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

// 운영용 환경설정
@Profile("production")
@Configuration
@PropertySource(value = {"classpath:application.properties","classpath:jdbc.properties"})
public class ProductionDataSourceConfig implements DataSourceConfig {
	@Value("${o.driver}")
	private String driverClassName;
	@Value("${o.url}")
	private String url;
	@Value("${o.username}")
	private String username;
	@Value("${o.password}")
	private String password;
	
	@Override
	@Bean
	public DataSource getDataSource() {
		System.out.println("운영용 데이터베이스 입니다.......");
		// 여기서는 MariaDB의 데이터 소스를 생성한다.
		DriverManagerDataSource dataSource = new DriverManagerDataSource();
		dataSource.setDriverClassName(driverClassName);
		dataSource.setUrl(url);
		dataSource.setUsername(username);
		dataSource.setPassword(password);
		return dataSource;
	}
}
