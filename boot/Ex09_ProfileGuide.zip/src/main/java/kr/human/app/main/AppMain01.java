package kr.human.app.main;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class AppMain01 {
	public static void main(String[] args) {
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		
		// 운영용 개발 환경
		/*
		context.getEnvironment().setActiveProfiles("production");
		context.scan("kr.human.app");
		context.refresh();
		*/
		// 개발용 개발 환경
		//*
		context.getEnvironment().setActiveProfiles("dev");
		context.scan("kr.human.app");
		context.refresh();
		//*/
		context.close();
	}
}
