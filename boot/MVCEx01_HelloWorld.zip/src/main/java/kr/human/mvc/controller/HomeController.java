package kr.human.mvc.controller;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import lombok.extern.log4j.Log4j2;

@Controller
@Log4j2
public class HomeController {

	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String index(Model model) {
		log.info("컨트롤러에 들어 왔을까요!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
		model.addAttribute("today", 
				LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy년 MM월 dd일(EEEE) hh:mm:ss")));
		return "index";
	}
}
