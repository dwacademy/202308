package kr.human.boot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootEx16Jpah2DbPagingApplication {

	public static void main(String[] args) {
		SpringApplication.run(BootEx16Jpah2DbPagingApplication.class, args);
	}

}
