package kr.human.boot.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import kr.human.boot.dao.PersonRepository;
import kr.human.boot.vo.PagingVO;
import kr.human.boot.vo.Person;

@Service
public class PersonService {

	@Autowired
	private PersonRepository personRepository;

	// long count() - 사용 가능한 엔터티 수를 반환합니다.
	public long selectCount() {
		return personRepository.count();
	}

	// save(S 엔티티) - 주어진 엔티티를 저장합니다.
	public void insert(Person person) {
		if (person != null) {
			person.setRegDate(new Date());
			// save(S 엔티티) - 주어진 엔티티를 저장합니다.
			personRepository.save(person); // 1개 저장이다.
		}
	}

	// Iterable saveAll(Iterable entities) - 주어진 모든 엔티티를 저장합니다.
	public void saveAll(List<Person> list) {
		if (list != null && list.size() > 0) {
			personRepository.saveAll(list);
		}
	}

	// Iterable findAll() - 해당 유형의 모든 인스턴스를 반환합니다.
	public List<Person> selectList1() {
		Iterable<Person> it = personRepository.findAll(); // 기본적으로 저장순서이다.
		List<Person> list = new ArrayList<>();
		it.forEach(list::add);
		return list;
	}

	// Page <T> findAll(Pageable pageable); - 해당 유형의 해당 페이지의 Page 인스턴스를 반환합니다.
	public Page<Person> selectList2(int pageNo, int pageSize, int blockSize) {
		// Pageable pageable = PageRequest.of(pageNo-1, pageSize);
		// Page<Person> page = personRepository.findAll(pageable);
		// return page;
		// 오름차순
		// return personRepository.findAll(PageRequest.of(pageNo-1, pageSize));
		// 역순
		return personRepository.findAll(PageRequest.of(pageNo - 1, pageSize, Sort.by("idx").descending()));
	}

	// Page <T> findAll(Pageable pageable); - 해당 유형의 해당 페이지의 Page 인스턴스를 반환합니다.
	public PagingVO<Person> selectList3(int pageNo, int pageSize, int blockSize) {
		PagingVO<Person> pv = new PagingVO<>((int) personRepository.count(), pageNo, pageSize, blockSize);
		String sortBy = "idx";
		String sortDir = "desc";
		Sort sort = sortDir.equalsIgnoreCase(Sort.Direction.ASC.name()) ? Sort.by(sortBy).ascending()
				: Sort.by(sortBy).descending();
		Iterable<Person> persons = personRepository.findAll(sort);
		List<Person> list = new ArrayList<>();
		persons.forEach(list::add);
		pv.setList(list);
		return pv;
	}

	public PagingVO<Person> selectList4(int pageNo, int pageSize, int blockSize) {
		PagingVO<Person> pv = new PagingVO<>((int) personRepository.count(), pageNo, pageSize, blockSize);
		Pageable pageable = PageRequest.of(pageNo - 1, pageSize, Sort.by("idx").descending());
		Page<Person> page = personRepository.findAll(pageable);
		pv.setList(page.getContent());
		return pv;
	}

}
