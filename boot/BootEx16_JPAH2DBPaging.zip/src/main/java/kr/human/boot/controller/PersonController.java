package kr.human.boot.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import kr.human.boot.service.PersonService;
import kr.human.boot.vo.PagingVO;
import kr.human.boot.vo.Person;
import lombok.extern.slf4j.Slf4j;

@Controller
@Slf4j
public class PersonController {
	@Autowired
	private PersonService personService;
	
	// findAll() 사용
	@GetMapping(value = "/list1")
	public String list1(Model model) {
		List<Person> list1 = personService.selectList1(); // 전체 저장순!!!!
		log.info("목록 : " + list1);
		model.addAttribute("list1", list1);
		model.addAttribute("totalCount", personService.selectCount());
		return "list1";
	}
	
	// 페이징 계산을 JPA에 있는 클래스(Page<T>)에 맡겼다....
	// 페이징된 내용을 얻어보자!!!
	@GetMapping(value = "/list2")
	public String list2(
			@RequestParam(required = false, defaultValue = "1") int pageNo,
			@RequestParam(required = false, defaultValue = "10") int pageSize,
			@RequestParam(required = false, defaultValue = "10") int blockSize,
			Model model) {
		Page<Person> page = personService.selectList2(pageNo, pageSize, blockSize);
		model.addAttribute("page", page);
		int startPage = (pageNo-1)/blockSize * blockSize + 1;
		int endPage = startPage + blockSize -1;
		if(endPage>page.getTotalPages()) endPage = page.getTotalPages();
		model.addAttribute("startPage", startPage);
		model.addAttribute("endPage", endPage);
		model.addAttribute("blockSize", blockSize);
		return "list2";
	}
	
	// 내가 만든 PagingVO를 이용해서 페이징을 하겠다!!!
	// 여기서는 역순으로 전체를 가져와 보겠다.......
	@RequestMapping(value = "/list3")
	public String list3(
			@RequestParam(required = false, defaultValue = "1") int pageNo,
			@RequestParam(required = false, defaultValue = "10") int pageSize,
			@RequestParam(required = false, defaultValue = "10") int blockSize,
			Model model) {
		PagingVO<Person> pv = personService.selectList3(pageNo, pageSize, blockSize);
		model.addAttribute("pv", pv);
		return "list3";
	}
	// 페이징해서 해당 페이지만 가져왔다!!!!
	@RequestMapping(value = "/list4")
	public String list4(
			@RequestParam(required = false, defaultValue = "1") int p,
			@RequestParam(required = false, defaultValue = "10") int s,
			@RequestParam(required = false, defaultValue = "10") int b,
			Model model) {
		PagingVO<Person> pv = personService.selectList4(p, s, b);
		model.addAttribute("pv", pv);
		return "list4";
	}
}
