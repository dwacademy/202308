package kr.human.boot.dao;

import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import kr.human.boot.vo.Person;

@Repository
public interface PersonRepository extends PagingAndSortingRepository<Person, Long>{
	/*
	 public interface PagingAndSortingRepository < T, ID > extends CrudRepository < T, ID >
	 
	 Iterable <T> findAll(Sort sort);
	 Page < T > findAll(Pageable pageable);
	 */
}
