-- 테이블 정의
CREATE TABLE IF NOT EXISTS person(
	idx int PRIMARY KEY auto_increment,
	name varchar(100) NOT NULL,
	age  int DEFAULT 0,
	gender int check gender in (0,1),
	reg_date timestamp DEFAULT now()
);
