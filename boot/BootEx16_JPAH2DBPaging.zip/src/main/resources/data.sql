-- 데이터 추가 명령
insert into person (name, age,gender,reg_date) values ('한사람',34,1,now());
insert into person (name, age,gender,reg_date) values ('두사람',22,0,now());
insert into person (name, age,gender,reg_date) values ('세사람',18,0,now());
insert into person (name, age,gender,reg_date) values ('네사람',21,1,now());
insert into person (name, age,gender,reg_date) values ('오사람',18,1,now());
-- insert into person (name, age,gender,reg_date) values ('육사람',44,0,now());
-- insert into person (name, age,gender,reg_date) values ('칠사람',61,1,now());
-- insert into person (name, age,gender,reg_date) values ('팔사람',53,0,now());
-- insert into person (name, age,gender,reg_date) values ('구사람',48,1,now());
-- insert into person (name, age,gender,reg_date) values ('십사람',29,0,now());
