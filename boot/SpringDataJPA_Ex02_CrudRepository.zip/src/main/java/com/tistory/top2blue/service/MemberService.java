package com.tistory.top2blue.service;

import java.util.List;

import com.tistory.top2blue.vo.Member;

public interface MemberService {
	// 전체 얻기
	List<Member> findAll(); 
	
	// id리스트로 얻기
	List<Member> findAllById(List<Long> list); 
	
	// id 존재 여부 확인 하기
	boolean existsById(long id);
	
	// id로 1개 얻기
	Member findById(long id);

	// 1개 저장하기
	Member save(Member member);
	
	// 여러개 저장하기
	List<Member> saveAll(List<Member> members);
	
	// 개수 얻기
	long count();
	
	// 지정 회원 지우기
	boolean delete(Member member);

	// 지정 회원 지우기
	boolean deleteById(long id);
	
	// 여러 아이디 한번에 지우기
	boolean deleteAllById(List<Long> ids);

	// 여러 아이디 한번에 지우기
	boolean deleteAll(List<Member> entities);
	
	// 모두 지우기
	boolean deleteAll();

}
