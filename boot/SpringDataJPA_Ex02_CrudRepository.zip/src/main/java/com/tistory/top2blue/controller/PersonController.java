package com.tistory.top2blue.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.tistory.top2blue.service.MemberService;
import com.tistory.top2blue.vo.Member;

import lombok.extern.slf4j.Slf4j;

@Controller
@Slf4j
@RequestMapping(value = "/members")
public class PersonController {
	@Autowired
	private MemberService memberService;
	
	@GetMapping(value = {"/","/list"})
	public String home(Model model) throws Exception {
		log.info("회원 목록보기");
		List<Member> memberList = memberService.findAll();
		log.info("회원 목록 : {}", memberList);
		model.addAttribute("list", memberList);
		return "member/list";
	}

	@GetMapping(value = {"/findAllById"})
	public String findAllById(Model model) throws Exception {
		log.info("findAllById 호출");
		List<Member> memberList = memberService.findAllById(Arrays.asList(1L,3L,5L));
		log.info("findAllById 리턴 회원 목록 : {}", memberList);
		model.addAttribute("list", memberList);
		return "member/list";
	}
	
	@GetMapping(value = "/existsById")
	@ResponseBody
	public boolean existsById(@RequestParam(defaultValue = "0") long id) {
		log.info("컨트롤러 existsById({}) 호출", id);
		boolean existsById = memberService.existsById(id);
		log.info("컨트롤러 existsById({}) 리턴 : {}", id, existsById);
		return existsById;
	}
	
	@GetMapping(value = "/findById")
	@ResponseBody
	public Member findById(@RequestParam(defaultValue = "0") long id) {
		log.info("컨트롤러 findById({}) 호출", id);
		Member member = memberService.findById(id);
		log.info("컨트롤러 findById({}) 리턴 : {}", id, member);
		return member;
	}

	@GetMapping(value = "/save")
	@ResponseBody
	public Member save(@ModelAttribute Member member) {
		log.info("컨트롤러 save({}) 호출", member);
		Member returnMember = memberService.save(member);
		log.info("컨트롤러 save({}) 리턴 : {}", member, returnMember);
		return returnMember;
	}
	
	@GetMapping(value = "/saveAll")
	public String saveAll() {
		List<Member> list = Arrays.asList(
				new Member("admin","admin","한사람", 22, false),
				new Member("root","root","두사람", 37, true)
				);
		log.info("컨트롤러 saveAll({}) 호출", list);
		List<Member> members = memberService.saveAll(list);
		log.info("컨트롤러 saveAll({}) 리턴 : {}", list, members);
		return "redirect:/members/";
	}
	
	@GetMapping(value = "/count")
	@ResponseBody
	public long count() {
		log.info("컨트롤러 count() 호출");
		long count = memberService.count();
		log.info("컨트롤러 count() 리턴 : {}",count);
		return count;
	}
	
	@GetMapping(value = "/delete")
	@ResponseBody 
	public boolean delete(@ModelAttribute Member member) {
		log.info("컨트롤러 delete({}) 호출", member);
		boolean result = memberService.delete(member);  // id만 맞으면 삭제됨
		log.info("컨트롤러 delete({}) 리턴 : {}", member, result);
		return result;
	}
	
	@GetMapping(value = "/deleteById")
	@ResponseBody 
	public boolean deleteById(@RequestParam(defaultValue = "-1")long id) {
		log.info("컨트롤러 deleteById({}) 호출", id);
		boolean result = memberService.deleteById(id);
		log.info("컨트롤러 deleteById({}) 리턴 : {}", id, result);
		return result;
	}
	
	@GetMapping(value = "/deleteAllById")
	@ResponseBody 
	public boolean deleteAllById(@RequestParam List<Long> ids) {
		log.info("컨트롤러 deleteAllById({}) 호출", ids);
		boolean result = memberService.deleteAllById(ids);
		log.info("컨트롤러 deleteAllById({}) 리턴 : {}", ids, result);
		return result;
	}
	
	@GetMapping(value = "/deleteAll")
	@ResponseBody 
	public boolean deleteAll(@RequestParam List<Long> ids) {
		log.info("컨트롤러 deleteAll({}) 호출", ids);
		List<Member> list = new ArrayList<>();
		for(Long i : ids) {
			Member m = new Member();
			m.setId(i);
			list.add(m);
		}
		boolean result = memberService.deleteAll(list);
		log.info("컨트롤러 deleteAll({}) 리턴 : {}", ids, result);
		return result;
	}
	
	@GetMapping(value = "/deleteAll2")
	@ResponseBody 
	public boolean deleteAll() {
		log.info("컨트롤러 deleteAll() 호출");
		boolean result = memberService.deleteAll();
		log.info("컨트롤러 deleteAll() 리턴 : {}",  result);
		return result;
	}
	
}
