package com.tistory.top2blue.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tistory.top2blue.repository.MemberRepository;
import com.tistory.top2blue.vo.Member;

import lombok.extern.slf4j.Slf4j;


//@SuppressWarnings({ "unchecked", "rawtypes" })
@Slf4j
@Service("memberService")
public class MemberServiceImpl implements MemberService {

	@Autowired
	private MemberRepository memberRepository;

	@Override
	public List<Member> findAll() {
		log.info("서비스 findAll() 호출");
		List<Member> list = new ArrayList<>();
		memberRepository.findAll().forEach(list::add);
		log.info("서비스 findAll() 리턴 : {}", list);
		return list;
	}

	@Override
	public List<Member> findAllById(List<Long> idList) {
		log.info("서비스 findAllById() 호출");
		List<Member> list = new ArrayList<>();
		memberRepository.findAllById(idList).forEach(list::add);
		log.info("서비스 findAllById() 리턴 : {}", list);
		return list;
	}
	
	@Override
	public boolean existsById(long id) {
		log.info("서비스 existsById({}) 호출", id);
		boolean existsById = memberRepository.existsById(id);
		log.info("서비스 existsById({}) 리턴 : {}", id, existsById);
		return existsById;
	}

	@Override
	public Member findById(long id) {
		Member member = null;
		log.info("서비스 findById({}) 호출", id);
		Optional<Member> optional = memberRepository.findById(id);
		if(optional.isPresent()) {
			member = optional.get();
		}
		log.info("서비스 findById({}) 리턴 : {}", id, member);
		return member;
	}

	@Override
	public Member save(Member member) {
		Member returnMember = null; 
		log.info("서비스 save({}) 호출", member);
		try {
			returnMember = memberRepository.save(member);
		}catch (Exception e) {
			e.printStackTrace();
		}
		log.info("서비스 save({}) 리턴 : {}", member, returnMember);
		return returnMember;
	}

	@Override
	public List<Member> saveAll(List<Member> members) {
		List<Member> returnMembers = null; 
		log.info("서비스 saveAll({}) 호출", members);
		try {
			Iterable<Member> it = memberRepository.saveAll(members);
			returnMembers = new ArrayList<>(); 
			it.forEach(returnMembers::add);
		}catch (Exception e) {
			e.printStackTrace();
		}
		log.info("서비스 saveAll({}) 리턴 : {}", members, returnMembers);
		return returnMembers;
	}

	@Override
	public long count() {
		long count = 0;
		log.info("서비스 count() 호출");
		try {
			count = memberRepository.count();
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		log.info("서비스 count() 리턴 : {}", count);
		return count;
	}

	@Override
	public boolean delete(Member member) {
		boolean result = false;
		log.info("서비스 delete({}) 호출" , member);
		try {
			memberRepository.delete(member);  // id만 맞으면 삭제됨
			result = true;
		}catch (Exception e) {
			result = false;
		}
		log.info("서비스 delete({}) 리턴 : {}", member, result);
		return result;
	}

	@Override
	public boolean deleteById(long id) {
		boolean result = false;
		log.info("서비스 deleteById({}) 호출" , id);
		try {
			memberRepository.deleteById(id);
			result = true;
		}catch (Exception e) {
			result = false;
		}
		log.info("서비스 delete({}) 리턴 : {}", id, result);
		return result;
	}

	@Override
	public boolean deleteAllById(List<Long> ids) {
		boolean result = false;
		log.info("서비스 deleteAllById({}) 호출" , ids);
		try {
			memberRepository.deleteAllById(ids);
			result = true;
		}catch (Exception e) {
			result = false;
		}
		log.info("서비스 deleteAllById({}) 리턴 : {}", ids, result);
		return result;
	}

	@Override
	public boolean deleteAll(List<Member> members) {
		boolean result = false;
		log.info("서비스 deleteAll({}) 호출" , members);
		try {
			memberRepository.deleteAll(members);
			result = true;
		}catch (Exception e) {
			result = false;
		}
		log.info("서비스 deleteAll({}) 리턴 : {}", members, result);
		return result;
	}

	@Override
	public boolean deleteAll() {
		boolean result = false;
		log.info("서비스 deleteAll() 호출");
		try {
			memberRepository.deleteAll();
			result = true;
		}catch (Exception e) {
			result = false;
		}
		log.info("서비스 deleteAll() 리턴 : {}", result);
		return result;
	}
}
