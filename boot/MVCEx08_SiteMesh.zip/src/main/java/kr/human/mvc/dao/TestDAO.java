package kr.human.mvc.dao;

import java.sql.SQLException;
import java.util.HashMap;

import kr.human.mvc.vo.TestVO;

public interface TestDAO {
	String selectToday() throws SQLException;
	TestVO selectVO(HashMap<String, Integer> map)  throws SQLException;
	HashMap<String, Object> selectMap(HashMap<String, Integer> map)  throws SQLException;
}
